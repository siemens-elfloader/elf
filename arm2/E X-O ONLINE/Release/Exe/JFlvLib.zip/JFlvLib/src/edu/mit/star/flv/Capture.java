
package edu.mit.star.flv;

import java.io.*;

public interface Capture
{

    public abstract BufferedImage newFrame();

    public abstract void writeFrame(BufferedImage image, int i) throws IOException;
    
 }
