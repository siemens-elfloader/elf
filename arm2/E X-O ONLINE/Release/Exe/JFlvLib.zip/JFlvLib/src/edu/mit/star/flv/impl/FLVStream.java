
package edu.mit.star.flv.impl;

import edu.mit.star.flv.*;
import java.io.*;

public class FLVStream
{
    
    static final byte VIDEO = 1;
    static final byte AUDIO = 4;
    static final byte FLV_1 = 1;
    
    DataOutputStream os;
    byte type;
    int compression;
    boolean headerAndMetaDataFlag;
    
    public FLVStream(OutputStream os, byte type,int compression) throws IOException
    {
        this.os = new DataOutputStream(os);
        this.type=type;
        this.compression=compression;
    }

    public void writeImage(BufferedImage image, int timestamp) throws IOException
    {
        if(!headerAndMetaDataFlag)
        {
            writeHeader(type);
            writeMetaData(image.getWidth(),image.getHeight());
            headerAndMetaDataFlag=true;
         }
        FLVTag tag = new FLVTag(image, timestamp,compression);
        tag.write(os);
    }

    private void writeHeader(byte type) throws IOException
    {
        os.write("FLV".getBytes());
        os.write8((byte)1);
        os.write8(type);
        os.writeInt(9);
        os.writeInt(0);
     }
    
    private void writeMetaData(int width,int height) throws IOException
    {
        os.write8((byte)18);
        os.write24(77);
        os.write(new byte [7]);
        os.write8((byte)2);
        os.writeShort(10);
        os.write("onMetaData".getBytes());
        os.write8((byte)8);
        os.writeInt(3);
        os.writeShort(12);
        os.write("videocodecid".getBytes());
        os.write8((byte)0);
        os.writeDouble(3);
        os.writeShort(5);
        os.write("width".getBytes());
        os.write8((byte)0);
        os.writeDouble((double)width);
        os.writeShort(6);
        os.write("height".getBytes());
        os.write8((byte)0);
        os.writeDouble((double)height);
        os.write24(9);
        os.writeInt(0);
     }
    
 }
