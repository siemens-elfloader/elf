
package edu.mit.star.flv.impl;

import edu.mit.star.flv.*;
import java.io.*;

class FLVTag
{
    
    static final byte AUDIO = 8;
    static final byte VIDEO = 9;
    static final byte SCRIPT = 18;
    
    byte tagType;
    int dataSize_24;
    int timeStamp;
    final int StreamID_24 = 0;
    DataWritter data;
    
    public FLVTag(BufferedImage image, int timestamp,int compression)
    {
        timeStamp = 0;
        tagType = 9;
        timeStamp = timestamp;
        data = new VideoData(image,compression);
    }

    public void write(DataOutputStream os) throws IOException
    {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(0x100000);
        data.write(new DataOutputStream(bos));
        dataSize_24 = bos.size();
        os.writeByte(tagType);
        os.write24(dataSize_24);
        os.write24(timeStamp & 0xffffff);
        os.write8((byte)(timeStamp >> 24 & 0xff));
        os.write24(0);
        os.write(bos.toByteArray());
        os.writeInt(dataSize_24 + 11);
    }

 }
