
package edu.mit.star.flv.impl;

import java.io.*;

public interface DataWritter
{

    public abstract void write(DataOutputStream dataoutputstream) throws IOException;
    
 }
