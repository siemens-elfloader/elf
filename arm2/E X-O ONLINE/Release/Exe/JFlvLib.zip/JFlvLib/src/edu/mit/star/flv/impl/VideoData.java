
package edu.mit.star.flv.impl;

import edu.mit.star.flv.*;
import java.io.*;

class VideoData implements DataWritter
{
    
    static final byte KEYFRAME = 16;
    static final byte INTERFRAME = 32;
    static final byte DISPOSABLEINTERFRAME = 48;
    static final byte GENERATEDKEYFRAME = 64;
    static final byte INFOCOMMAND = 80;
    static final byte JPEG_CODEC = 1;
    static final byte H263_CODEC = 2;
    static final byte SCREENVIDEO_CODEC = 3;
    static final byte On2VP6_CODEC = 4;
    static final byte On2VP6_Alpha_CODEC = 5;
    static final byte SCREENVIDEO2_CODEC = 6;
    static final byte AVC = 7;
    
    byte FrameAndCodec;
    DataWritter videoData;
    
    public VideoData(BufferedImage image,int compression)
    {
        FrameAndCodec = 19;
        videoData = new ScreenVideoData(image, compression);
    }

    public void write(DataOutputStream dos) throws IOException
    {
        dos.write8(FrameAndCodec);
        videoData.write(dos);
        dos.flush();
    }
    
 }
