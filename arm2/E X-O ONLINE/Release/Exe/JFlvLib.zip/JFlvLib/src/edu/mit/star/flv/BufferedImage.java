
package edu.mit.star.flv;

import javax.microedition.lcdui.*;

public class BufferedImage
{
     
     private int width;
     private int height;
     private int rgb[];
     private Image image;
     
     public BufferedImage(int width,int height)
     {
         this.width=width;
         this.height=height;
         rgb=new int [width*height];
      }
     
     public int getWidth()
     {
         return width;
      }
     
     public int getHeight()
     {
          return height;
      }
     
     public Graphics getGraphics()
     {
         image=Image.createImage(width,height);
         Graphics graphics=image.getGraphics();
         graphics.drawRGB(rgb,0,width,0,0,width,height,true);
         return graphics;
      }
     
     public void flush()
     {
         if(image!=null)
         {
             image.getRGB(rgb,0,width,0,0,width,height);
             image=null;
          }
      }
     
     public int getPixel(int x,int y)
     {
         try
         {
            return rgb[width*y+x];
          }
         catch(ArrayIndexOutOfBoundsException e) { }
         return 0;
      }
     
 }
