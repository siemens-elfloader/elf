
package edu.mit.star.flv.impl;

import edu.mit.star.flv.*;
import java.io.*;

public class Capturer implements Capture
{
    
    FLVStream worker;
    int width;
    int height;
    
    public Capturer(OutputStream os, int width,int height,int compression) throws IOException
    {
        if(width % 16 != 0)
         width+=16-(width % 16);
        if(height % 16 != 0)
         height+=16-(height % 16);
        if(compression<1 || compression>9)
         compression=6;
        worker = new FLVStream(os, (byte)1,compression);
        this.width=width;
        this.height=height;
    }

    public BufferedImage newFrame()
    {
        return new BufferedImage(width,height);
    }

    public void writeFrame(BufferedImage image, int timestamp) throws IOException
    {
        worker.writeImage(image, timestamp);
     }

 }
