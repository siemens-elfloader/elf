
package edu.mit.star.flv;

import edu.mit.star.flv.impl.Capturer;
import java.io.*;

public class CaptureFactory
{

    public CaptureFactory()
    {
    }

    public static Capturer getCapturer(OutputStream os, int width,int height,int compression) throws IOException
    {
        return new Capturer(os, width,height,compression);
    }
    
 }
