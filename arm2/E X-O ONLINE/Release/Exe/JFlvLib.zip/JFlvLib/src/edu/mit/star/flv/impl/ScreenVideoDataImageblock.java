
package edu.mit.star.flv.impl;

import java.io.*;
import net.sf.zipme.*;

class ScreenVideoDataImageblock implements DataWritter
{
    
    int dataSize;
    byte data[];
    
    public ScreenVideoDataImageblock(byte uncompressed[],int compression)
    {
        Deflater compressor = new Deflater(compression);
        compressor.setInput(uncompressed);
        compressor.finish();
        byte output[] = new byte[uncompressed.length];
        dataSize = compressor.deflate(output);
        data = new byte[dataSize];
        System.arraycopy(output, 0, data, 0, dataSize);
    }

    public void write(DataOutputStream dos) throws IOException
    {
        dos.writeShort(dataSize);
        dos.write(data);
    }
    
 }
