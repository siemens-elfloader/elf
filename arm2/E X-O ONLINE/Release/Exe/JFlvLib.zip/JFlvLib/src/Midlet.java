
import javax.microedition.midlet.*;
import javax.microedition.io.file.*;
import javax.microedition.io.*;
import java.io.*;
import javax.microedition.lcdui.*;
import edu.mit.star.flv.*;
import j2me.image.codec.gif.*;

public class Midlet extends MIDlet
{
      
      public Midlet()
      {
       }
       
      public  void startApp()
      {
           createFlvFile("fs/flv/test.flv");
           //convertGif2Flv("fs/Animation/test.gif");
           destroyApp(true);
       }
      
      public void pauseApp()
      {
       }
       
      public void destroyApp(boolean flag)
      {
          if(flag)
           notifyDestroyed();
       }
      
      private void createFlvFile(String s)
      {
           try
           {
               System.out.println("File: "+s);
               FileConnection fileConnection=(FileConnection)Connector.open("file:///"+s);
               if(fileConnection.exists())
                fileConnection.delete();
               fileConnection.create();
               OutputStream out = fileConnection.openOutputStream();
               Capture c = CaptureFactory.getCapturer(out, 128, 96,5);
               int i=5000;
               for(int time = 0; time < i;)
               {
                   BufferedImage image = c.newFrame();
                   Graphics graphics=image.getGraphics();
                   graphics.setColor(0x00ff00);
                   graphics.fillRect(0,0,image.getWidth(),image.getHeight());
                   graphics.setColor(0x000000);
                   graphics.drawArc(0, 0, (image.getWidth() * time) / i, (image.getHeight() * time) / i,0,360);
                   image.flush();
                   c.writeFrame(image, time);
                   time += 250;
                   System.out.println((new StringBuffer("Generating ")).append(time).append(" ms frame.").toString());
               }
               out.close();
               fileConnection.close();
               System.out.println("ok.");
            }
           catch(IOException exception)
           {
               exception.printStackTrace();
            }
       }
      
      private void convertGif2Flv(String s)
      {
           try
           {
               System.out.println("File: "+s);
               GifDecoder decoder=createGifDecoder(s);
               FileConnection fileConnection=(FileConnection)Connector.open("file:///"+s.substring(0,s.length()-3)+"flv");
               if(fileConnection.exists())
                fileConnection.delete();
               fileConnection.create();
               OutputStream out=fileConnection.openOutputStream();
               Capture capture = CaptureFactory.getCapturer(out,decoder.getFrame(0).getWidth(),decoder.getFrame(0).getHeight(),6);
               int time=0;
               for(int i=0;i<decoder.getFrameCount();i++)
               {
                   BufferedImage image = capture.newFrame();
                   Graphics graphics=image.getGraphics();
                   graphics.setColor(0x000000);
                   graphics.fillRect(0,0,image.getWidth(),image.getHeight());
                   graphics.drawImage(decoder.getFrame(i),(image.getWidth()-decoder.getFrame(i).getWidth())/2,(image.getHeight()-decoder.getFrame(i).getHeight())/2,20);
                   image.flush();
                   capture.writeFrame(image, time);
                   int gifFrameDelay=decoder.getDelay(i);
                   if(gifFrameDelay<25)
                    gifFrameDelay=25;
                   time+=gifFrameDelay;
                   System.out.println((new StringBuffer("Generating ")).append(time).append(" ms frame.").toString());
                }
               out.close();
               fileConnection.close();
               System.out.println("ok.");
            }
           catch(IOException exception)
           {
               exception.printStackTrace();
            }
       }
      
      private GifDecoder createGifDecoder(String s) throws IOException
      {
          FileConnection fileConnection=(FileConnection)Connector.open("file:///"+s);
          InputStream in=fileConnection.openInputStream();
          GifDecoder decoder=new GifDecoder();
          decoder.read(in);
          in.close();
          fileConnection.close();
          return decoder;
       }
      
 }
