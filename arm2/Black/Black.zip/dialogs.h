void DoEditcontrol(int type, char *deftext, char *def2);

