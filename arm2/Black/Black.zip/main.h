void writemap(char *fname);
int strcmp_nocase(const char *s1,const char *s2);
void writeinit(int digit, int init);
void changeSize(int xx, int yy);

