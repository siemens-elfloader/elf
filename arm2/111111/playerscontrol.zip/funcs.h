

void SendCmd(int player,int cmd);
void PlayPause();
void Stop();
void Prev();
void Next();
void Start(int player);
void Close();
void VolUP();
void VolDOWN();
void Mute();
int HeadsetDisconnect();
int HeadsetConnect();
void TmrSec();
void GetAccesory();
void StartCloseTimer();
void StopCloseTimer();
void CloseTimer();
void Lock();
