#define CMD_NEXT 1 //short
#define CMD_PREV 2 //short
#define CMD_PLAY_PAUSE 3 //short
#define CMD_VOLUP 4 //short
#define CMD_VOLDOWN 5 //short
#define CMD_MUTE 6 //short
#define CMD_STOP 7 //short
#define CMD_KILL 25 //integer
#define IPC_IVO "IVOPLAY"
#define ipc_my_name "IVOPLAY_PLUGIN"
