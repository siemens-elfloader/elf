#include "../inc/swilib.h"
#include "../inc/pnglist.h"
#include "rect_patcher.h"
#include "RANDOM.H"
#include "load_enemy.h"
//enemy_hp=enemy_t_hp=20

//============configuration
char me_img[]="4:\\game\\me.png";
char enemy_img[]="4:\\game\\enemy.png";
char left_img[]="4:\\game\\left.png";
char right_img[]="4:\\game\\right.png";
char center_img[]="4:\\game\\center.png";
char shield_img[]="4:\\game\\shield.png";
char gun_img[]="4:\\game\\gun.png";
char hit_img[]="4:\\game\\hit.png";
extern const int font;
extern const int screen_w;
extern const int screen_h;
int fight_x=16;
int fight_y=50;
////
int my_pos_x;
int my_pos_x_a;
int my_pos_x_d;
///
int enemy_pos_x;
int enemy_pos_x_a;
int enemy_pos_x_d;
///
int my_pos_y;
int enemy_pos_y;
int chose_opt;
//int hp_line_my;
//int hp_line_enemy;
int my_move=1;
int my_move_a;
int my_move_d;
int movem_d;
int movee_a;
int movem_a;
int movee_d;
int hit_me;
int hit_enemy;
int results;
int hit_m;
int shooting;
int shoot;
int shoot_x;
int shoot_y;
int victory_status;
//===========configuration
//==============my character
extern int my_hp;
extern int my_t_hp;
extern int my_level;
//=============my character
//==============enemy character
int enemy_number;
int enemy_hp;
int enemy_t_hp;
int enemy_power;
//=============enemy character

typedef struct
{
  GUI gui;
  WSHDR *ws;
}BATTLE_GUI;

void Calculate_my_hp(int enemy_number)
{
  if(hit_m)
  {
  switch(enemy_number)
  {
  case 1:
    hit_me=Random()%4+1;
    my_hp=my_hp-hit_me;
    break;
  case 2:
    hit_me=Random()%7+1;
    my_hp=my_hp-hit_me;
    break;
  }
  }
}

void moving(void);

void calculate_moves()
{
  hit_me=0;
  hit_enemy=0;
  int i=Random()%6+1;
  int j;
  if ((i==1||i==4)) 
  {
    j=1;
    enemy_pos_x_a=fight_x;
  }
  else
    if ((i==2||i==5)) 
    {
      j=3;
      enemy_pos_x_a=fight_x+80;
    }
  else 
  {
    j=2;
    enemy_pos_x_a=fight_x+40;
  }
  if(my_move_d==1) my_pos_x_d=fight_x;
  if(my_move_d==2) my_pos_x_d=fight_x+40;
  if(my_move_d==3) my_pos_x_d=fight_x+80;
  if(my_move_d==j)
    hit_m=1;
  else
    hit_m=0;
  //  Calculate_my_hp(enemy_number);
  i=Random()%6+1;
  if ((i==1||i==4)) 
  {
    j=1;
    enemy_pos_x_d=fight_x;
  }
  else
    if ((i==2||i==5)) 
    {
      j=3;
      enemy_pos_x_d=fight_x+80;
    }
  else 
  {
    j=2;
    enemy_pos_x_d=fight_x+40;
  }
  if(my_move_a==1) my_pos_x_a=fight_x;
  if(my_move_a==2) my_pos_x_a=fight_x+40;
  if(my_move_a==3) my_pos_x_a=fight_x+80;
  if(my_move_a==j)
  {
    hit_enemy=Random()%4+1;
   // enemy_hp=enemy_hp-hit_enemy;
  }
  chose_opt=0;
  movem_d=0;
  movee_a=0;
  movem_a=0;
  movee_d=0;
  moving();
}

GBSTMR mytmr;
char result_txt[64];

void winnings_check()
{
  shooting=0;
  Calculate_my_hp(enemy_number);
  enemy_hp=enemy_hp-hit_enemy;
  if(my_hp<=0)
  {
    results=1;
    victory_status=0;
    sprintf(result_txt, "You lose");
    DirectRedrawGUI();
  }
  else
  if(enemy_hp<=0) 
  {
    results=1;
    victory_status=1;
    sprintf(result_txt, "You win");
    DirectRedrawGUI();
  }
  else
  {
    chose_opt=1;
    DirectRedrawGUI();
  }
}

void moving()
{
    if(((shooting!=0)&&(shooting<5))||((shooting!=0)&&(shooting!=5)&&(shooting<10)))
    {
      shooting++;
      shoot=1;
    }
    else
      shoot=0;
    if((movem_d==0)||(movee_a==0))
    {
      if(my_pos_x>my_pos_x_d) my_pos_x=my_pos_x-2;
      else
      if(my_pos_x<my_pos_x_d) my_pos_x=my_pos_x+2;
      else
      movem_d=1;
      if(enemy_pos_x>enemy_pos_x_a) enemy_pos_x=enemy_pos_x-2;
      else
      if(enemy_pos_x<enemy_pos_x_a) enemy_pos_x=enemy_pos_x+2;
      else
      movee_a=1;
    }
    if((movem_d==1)&&(movee_a==1)&&(shooting==0))
    {
      shoot_x=enemy_pos_x+17;
      shoot_y=enemy_pos_y+22;
      shooting=1;
    }
     if((movem_d==1)&&(movee_a==1)&&(shooting==5))
     {
      if(my_pos_x>my_pos_x_a) my_pos_x=my_pos_x-2;
      else
      if(my_pos_x<my_pos_x_a) my_pos_x=my_pos_x+2;
      else
 //     if(my_pos_x==my_pos_x_a)
      movem_a=1;
      if(enemy_pos_x>enemy_pos_x_d) enemy_pos_x=enemy_pos_x-2;
      else
      if(enemy_pos_x<enemy_pos_x_d) enemy_pos_x=enemy_pos_x+2;
      else
  //    if(enemy_pos_x==enemy_pos_x_d)
      movee_d=1;
     }
     if(((movem_a==1)&&(movee_d==1))&&(shooting==5))
       {
          shoot_x=my_pos_x+4;
           shoot_y=enemy_pos_y+22;
          shooting=6;
        }
    
  const char black[]={0,0,0,100};
  DrawRoundedFrame(0,0,screen_w,screen_h,0,0,0,black,black);
  WSHDR *ws=AllocWS(64);
  wsprintf(ws,"(c)Evilfox - combats 0.01");
  DrawString(ws,0,0,Get_WS_width(ws,font)+2,GetFontYSIZE(font),font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
  FreeWS(ws);
  DrawRectangle(14,48,118,132,0,GetPaletteAdrByColorIndex(1),GetPaletteAdrByColorIndex(3));
  DrawRectangle(fight_x,fight_y,116,130,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(0));
  DrawRectangle(fight_x+20,fight_y+20,fight_x+39,fight_y+25,0,GetPaletteAdrByColorIndex(1),GetPaletteAdrByColorIndex(3));
  DrawRectangle(fight_x+20,fight_y+54,fight_x+39,fight_y+59,0,GetPaletteAdrByColorIndex(1),GetPaletteAdrByColorIndex(3));
  DrawRectangle(fight_x+60,fight_y+20,fight_x+79,fight_y+25,0,GetPaletteAdrByColorIndex(1),GetPaletteAdrByColorIndex(3));
  DrawRectangle(fight_x+60,fight_y+54,fight_x+79,fight_y+59,0,GetPaletteAdrByColorIndex(1),GetPaletteAdrByColorIndex(3));
  DrawImg(my_pos_x,my_pos_y,(int)me_img);
  DrawImg(enemy_pos_x,enemy_pos_y,(int)enemy_img);
  
  DrawRectangle(4,42,6+enemy_t_hp,47,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(0));
  DrawRectangle(5,43,5+enemy_hp,46,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(4));
  
  DrawRectangle(4,162,6+my_t_hp,167,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(0));
  DrawRectangle(5,163,5+my_hp,166,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(4));
  if(shoot)
  {
    DrawRectangle(shoot_x,shoot_y,shoot_x+1,shoot_y+30,0,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(2));
    if((my_pos_x==enemy_pos_x)&&(movem_a==0)&&(movee_d==0))
      DrawImg(shoot_x-8,shoot_y+27,(int)hit_img);
    if((my_pos_x==enemy_pos_x)&&(movem_a==1)&&(movee_d==1))
      DrawImg(shoot_x-8,shoot_y-6,(int)hit_img);
  }
  if((movem_d==0)||(movee_a==0)||(movem_a==0)||(movee_d==0)||(shooting!=10))
    GBS_StartTimerProc(&mytmr, 10, moving);
  else
  {
    winnings_check();
  }
}

static void method0(BATTLE_GUI *data)
{
  if(chose_opt)
  {
  const char black[]={0,0,0,100};
  DrawRoundedFrame(0,0,screen_w,screen_h,0,0,0,black,black);
  WSHDR *ws=AllocWS(64);
  wsprintf(ws,"(c)Evilfox - combats 0.01");
  DrawString(ws,0,0,Get_WS_width(ws,font)+2,GetFontYSIZE(font),font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
  DrawRectangle(14,48,118,132,0,GetPaletteAdrByColorIndex(1),GetPaletteAdrByColorIndex(3));
  DrawRectangle(fight_x,fight_y,116,130,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(0));
  DrawRectangle(fight_x+20,fight_y+20,fight_x+39,fight_y+25,0,GetPaletteAdrByColorIndex(1),GetPaletteAdrByColorIndex(3));
  DrawRectangle(fight_x+20,fight_y+54,fight_x+39,fight_y+59,0,GetPaletteAdrByColorIndex(1),GetPaletteAdrByColorIndex(3));
  DrawRectangle(fight_x+60,fight_y+20,fight_x+79,fight_y+25,0,GetPaletteAdrByColorIndex(1),GetPaletteAdrByColorIndex(3));
  DrawRectangle(fight_x+60,fight_y+54,fight_x+79,fight_y+59,0,GetPaletteAdrByColorIndex(1),GetPaletteAdrByColorIndex(3));
  DrawImg(my_pos_x,my_pos_y,(int)me_img);
  DrawImg(enemy_pos_x,enemy_pos_y,(int)enemy_img);
  
  wsprintf(ws, "Enemy");
  DrawString(ws,4,38-(GetFontYSIZE(font)*2),4+Get_WS_width(ws,font)+2,38-GetFontYSIZE(font),font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
  if(hit_enemy)
    wsprintf(ws,"hp: %d/%d (-%d)", enemy_hp, enemy_t_hp, hit_enemy);
  else
    wsprintf(ws,"hp: %d/%d", enemy_hp, enemy_t_hp);
  DrawString(ws,4,40-GetFontYSIZE(font),4+Get_WS_width(ws,font)+2,40,font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
  DrawRectangle(4,42,enemy_t_hp+6,47,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(0));
  DrawRectangle(5,43,enemy_hp+5,46,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(4));
  
  wsprintf(ws, "Player");
  DrawString(ws,4,158-(GetFontYSIZE(font)*2),4+Get_WS_width(ws,font)+2,158-GetFontYSIZE(font),font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
  if(hit_me)
    wsprintf(ws,"hp: %d/%d (-%d)", my_hp, my_t_hp, hit_me);
  else
    wsprintf(ws,"hp: %d/%d", my_hp, my_t_hp);
  DrawString(ws,4,160-GetFontYSIZE(font),4+Get_WS_width(ws,font)+2,160,font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
  DrawRectangle(4,162,my_t_hp+6,167,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(0));
  DrawRectangle(5,163,my_hp+5,166,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(4));
  
  if(chose_opt==1)
  {
    wsprintf(ws,"Next Turn");
    DrawString(ws,45,78,45+Get_WS_width(ws,font)+2,78+GetFontYSIZE(font),font,0,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(0));
  }
  
  if(chose_opt==2)
  {
    DrawImg(40,80,(int)shield_img);
    if(my_move==1)
    DrawImg(60,80,(int)left_img);
    if(my_move==2)
      DrawImg(60,80,(int)center_img);
    if(my_move==3)
      DrawImg(60,80,(int)right_img);
  }
  
  if(chose_opt==3)
  {
    DrawImg(40,80,(int)gun_img);
  //  wsprintf(ws,"Attack");
  //  DrawString(ws,52,69,52+Get_WS_width(ws,font)+2,69+GetFontYSIZE(font),font,0,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
    if(my_move==1)
    DrawImg(60,80,(int)left_img);
    if(my_move==2)
      DrawImg(60,80,(int)center_img);
    if(my_move==3)
      DrawImg(60,80,(int)right_img);
  }
  FreeWS(ws);
  }
  if(results)
  {
    const char black[]={0,0,0,100};
    DrawRoundedFrame(0,0,screen_w,screen_h,0,0,0,black,black);
    WSHDR *ws=AllocWS(64);
    wsprintf(ws,"(c)Evilfox - combats 0.01");
    DrawString(ws,0,0,Get_WS_width(ws,font)+2,GetFontYSIZE(font),font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
    wsprintf(ws, result_txt);
    DrawString(ws,30,78,30+Get_WS_width(ws,3)+2,87+GetFontYSIZE(3),3,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
    FreeWS(ws);
  }
}

static void method1(BATTLE_GUI *data,void *(*malloc_adr)(int))
{
  Randomize();
  data->ws=AllocWS(50);
  data->gui.state=1;
  DirectRedrawGUI();
}

static void method2(BATTLE_GUI *data,void (*mfree_adr)(void *))
{
  GBS_DelTimer(&mytmr);
  data->gui.state=0;
//  mfree(data->icons);
  FreeWS(data->ws);
}

static void method3(BATTLE_GUI *data,void *(*malloc_adr)(int),void (*mfree_adr)(void *))//fokus
{
  DisableIDLETMR();
  data->gui.state=2;
}

static void method4(BATTLE_GUI *data,void (*mfree_adr)(void *))//unfokus
{
  if (data->gui.state!=2)
    return;
  data->gui.state=1;
}

static int method5(BATTLE_GUI *data,GUI_MSG *msg)
{
  int m=msg->gbsmsg->msg;
  int key=msg->gbsmsg->submess;
  if (m==LONG_PRESS)
  {
    if (key=='#')
    { 
      return (1);
    }
  }
  if (m==KEY_DOWN)
  {
    if ((key==0x04)&&(!results))
    { 
      return (1);
    }
    if(key==ENTER_BUTTON)
    {
      if(results)
      {
      //  my_hp=20;
        CalculateResults(enemy_number, victory_status);
        results=0;
        return (1);
      }
      if(chose_opt==1)
      {
        chose_opt=2;
      }
      else
      if(chose_opt==2)
      {
        my_move_d=my_move;
        chose_opt=3;
      }
      else
      if(chose_opt==3)
      {
        my_move_a=my_move;
        chose_opt=2;
        calculate_moves();
      }
    }
    if(key==LEFT_BUTTON)
    {
      my_move--;
      if(my_move==0) my_move++;
    }
    if(key==RIGHT_BUTTON)
    {
      my_move++;
      if(my_move==4) my_move--;
    }
  }
  DirectRedrawGUI();
  return(0);
}

static int method8(void){return(0);}

static int method9(void){return(0);}

extern void kill_data(void *p, void (*func_p)(void *));
static const void * const gui_methods[11]={
  (void *)method0,  //Redraw
  (void *)method1,  //Create
  (void *)method2,  //Close
  (void *)method3,  //Focus
  (void *)method4,  //Unfocus
  (void *)method5,  //OnKey
  0,
  (void *)kill_data, //method7, //Destroy
  (void *)method8,
  (void *)method9,
  0
};

void ref()
{
  DirectRedrawGUI();
}

int CreateBattle_GUI(int hp)
{
  hit_me=0;
  hit_enemy=0;
  GBS_StartTimerProc(&mytmr, 200, ref);
  LoadEnemySettings(hp);
  enemy_number=hp;
  //calculate_lines();
  chose_opt=2;
  my_pos_y=fight_y+60;
  my_pos_x=fight_x+20;
  enemy_pos_x=fight_x+60;
  enemy_pos_y=fight_y;
  static const RECT Canvas={0,0,0,0};
  BATTLE_GUI *battle_gui=malloc(sizeof(BATTLE_GUI));
  zeromem(battle_gui,sizeof(BATTLE_GUI));
  patch_rect((RECT*)&Canvas,0,0,ScreenW()-1,ScreenH()-1);
  battle_gui->gui.canvas=(void *)(&Canvas);
  battle_gui->gui.methods=(void *)gui_methods;
  battle_gui->gui.item_ll.data_mfree=(void (*)(void *))mfree_adr();
  return CreateGUI(battle_gui);
}
