#ifndef _SELECT_SCREEN_H_
  #define _SELECT_SCREEN_H_


int CreateBattle_GUI(int hp);










#endif

