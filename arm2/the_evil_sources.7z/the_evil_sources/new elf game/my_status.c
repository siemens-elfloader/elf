#include "../inc/swilib.h"
#include "../inc/pnglist.h"
#include "rect_patcher.h"

extern const int font;
extern const int screen_w;
extern const int screen_h;
//=============my definition
extern int my_hp;
extern int my_t_hp;
extern int my_level;
extern int my_xp;
extern int next_xp_lvl;
extern int my_gold;
//==============end

typedef struct
{
  GUI gui;
  WSHDR *ws;
}STATUS_GUI;

static void method0(STATUS_GUI *data)
{
    const char black[]={0,0,0,100};
    DrawRoundedFrame(0,0,screen_w,screen_h,0,0,0,black,black);
    WSHDR *ws=AllocWS(64);
    wsprintf(ws,"(c)Evilfox - combats 0.01");
    DrawString(ws,0,0,Get_WS_width(ws,font)+2,GetFontYSIZE(font),font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
    wsprintf(ws,"MY STATUS");
    DrawString(ws,32,40,32+Get_WS_width(ws,font)+2,40+GetFontYSIZE(font),font,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
    wsprintf(ws,"HP: %d/%d", my_hp, my_t_hp);
    DrawString(ws,3,60,3+Get_WS_width(ws,font)+2,60+GetFontYSIZE(font),font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
    wsprintf(ws,"Level: %d", my_level);
    DrawString(ws,3,62+GetFontYSIZE(font),3+Get_WS_width(ws,font)+2,62+(GetFontYSIZE(font)*2),font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
    wsprintf(ws,"XP: %d/%d", my_xp, next_xp_lvl);
    DrawString(ws,3,64+(GetFontYSIZE(font)*2),3+Get_WS_width(ws,font)+2,64+(GetFontYSIZE(font)*3),font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
    wsprintf(ws,"Damage: 1-4");
    DrawString(ws,3,66+(GetFontYSIZE(font)*3),3+Get_WS_width(ws,font)+2,64+(GetFontYSIZE(font)*4),font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
    wsprintf(ws,"Gold: %d", my_gold);
    DrawString(ws,3,68+(GetFontYSIZE(font)*4),3+Get_WS_width(ws,font)+2,68+(GetFontYSIZE(font)*5),font,0,GetPaletteAdrByColorIndex(4),GetPaletteAdrByColorIndex(23));
    wsprintf(ws,"BACK");
    DrawString(ws,131-Get_WS_width(ws,font),171-GetFontYSIZE(font),131,171,font,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
    
    FreeWS(ws);
}

static void method1(STATUS_GUI *data,void *(*malloc_adr)(int))
{
  data->ws=AllocWS(50);
  data->gui.state=1;
  DrawRectangle(0,0,240,320,0,
                GetPaletteAdrByColorIndex(1),
                GetPaletteAdrByColorIndex(1)); 
}

static void method2(STATUS_GUI *data,void (*mfree_adr)(void *))
{
  data->gui.state=0;
//  mfree(data->icons);
  FreeWS(data->ws);
}

static void method3(STATUS_GUI *data,void *(*malloc_adr)(int),void (*mfree_adr)(void *))//fokus
{
  DisableIDLETMR();
  data->gui.state=2;
}

static void method4(STATUS_GUI *data,void (*mfree_adr)(void *))//unfokus
{
  if (data->gui.state!=2)
    return;
  data->gui.state=1;
}

static int method5(STATUS_GUI *data,GUI_MSG *msg)
{
  int m=msg->gbsmsg->msg;
  int key=msg->gbsmsg->submess;
  /*if (m==LONG_PRESS)
  {
    if (key=='#')
    { 
      return (1);
    }
  }*/
  if (m==KEY_DOWN)
  {
    if (key==0x04)
    { 
      return (1);
    }
  }
  DirectRedrawGUI();
  return(0);
}

static int method8(void){return(0);}

static int method9(void){return(0);}

extern void kill_data(void *p, void (*func_p)(void *));
static const void * const gui_methods[11]={
  (void *)method0,  //Redraw
  (void *)method1,  //Create
  (void *)method2,  //Close
  (void *)method3,  //Focus
  (void *)method4,  //Unfocus
  (void *)method5,  //OnKey
  0,
  (void *)kill_data, //method7, //Destroy
  (void *)method8,
  (void *)method9,
  0
};

int MyStatus_GUI()
{
  static const RECT Canvas={0,0,0,0};
  STATUS_GUI *status_gui=malloc(sizeof(STATUS_GUI));
  zeromem(status_gui,sizeof(STATUS_GUI));
  patch_rect((RECT*)&Canvas,0,0,ScreenW()-1,ScreenH()-1);
  status_gui->gui.canvas=(void *)(&Canvas);
  status_gui->gui.methods=(void *)gui_methods;
  status_gui->gui.item_ll.data_mfree=(void (*)(void *))mfree_adr();
  return CreateGUI(status_gui);
}
