#include "../inc/swilib.h"
#include "../inc/pnglist.h"

extern int enemy_hp;
extern int enemy_t_hp;
extern int enemy_power;

//==============my character
extern int my_hp;
extern int my_t_hp;
extern int my_level;
extern int my_xp;
extern int next_xp_lvl;
extern int my_gold;
//=============my character

void LoadEnemySettings(int enemy)
{
  switch(enemy)
  {
  case 1:
    enemy_hp=enemy_t_hp=20;
    enemy_power=4;
    DirectRedrawGUI();
    break;
  case 2:
    enemy_hp=enemy_t_hp=40;
    enemy_power=7;
    DirectRedrawGUI();
    break;
  }
}

void XP_calculate()
{
  if(my_xp>next_xp_lvl)
  {
    my_level++;
    my_hp=my_t_hp=14+6*my_level;
    next_xp_lvl=my_level*my_level*my_level*10;
  }
}

void CalculateResults(int enemy, int status)
{
  if(status==0) my_hp=my_t_hp;
  if(status==1)
  {
    switch(enemy)
    {
    case 1:
      my_xp=my_xp+15;
      my_gold=my_gold+3;
      XP_calculate();
      break;
    case 2:
      my_xp=my_xp+50;
      my_gold=my_gold+10;
      XP_calculate();
      break;
    }
  }
}

