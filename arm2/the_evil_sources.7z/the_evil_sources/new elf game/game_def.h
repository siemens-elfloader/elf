#ifdef ELKA
#pragma swi_number=0x8237
__swi __arm char *RamIconBar();
const int screen_w=240;
const int screen_h=320;
#else

#endif
