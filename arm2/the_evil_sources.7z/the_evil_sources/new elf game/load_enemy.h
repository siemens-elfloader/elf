void LoadEnemySettings(int enemy);
void CalculateResults(int enemy, int status);
