#include "..\inc\swilib.h"
#include "..\inc\xtask_ipc.h"
#include "init.h"
#include "conf_loader.h"


extern unsigned long  strtoul (const char *nptr,char **endptr,int base);

CSM_DESC icsmd;
int MAINCSM_ID;
extern const int use_add_m;
//============================config definitions
int not_close;
extern const int UPPER;
extern const char path[128];
extern char LinkCounters[10];

char MLINK1[128];
char MLINK2[128];
char MLINK3[128];
char MLINK4[128];
char MLINK5[128];
char MLINK6[128];
char MLINK7[128];
char MLINK8[128];
char MLINK9[128];
char MLINKER[10];
char ONELINK1[128];
char ONELINK2[128];
char ONELINK3[128];
char ONELINK4[128];
char ONELINK5[128];
char ONELINK6[128];
char ONELINK7[128];
char ONELINK8[128];
char ONELINK9[128];
char ONELINKER[10];
//==========================
char TWOLINK1[128];
char TWOLINK2[128];
char TWOLINK3[128];
char TWOLINK4[128];
char TWOLINK5[128];
char TWOLINK6[128];
char TWOLINK7[128];
char TWOLINK8[128];
char TWOLINK9[128];
char TWOLINKER[10];
//==========================
char THREELINK1[128];
char THREELINK2[128];
char THREELINK3[128];
char THREELINK4[128];
char THREELINK5[128];
char THREELINK6[128];
char THREELINK7[128];
char THREELINK8[128];
char THREELINK9[128];
char THREELINKER[10];
//==========================
char FOURLINK1[128];
char FOURLINK2[128];
char FOURLINK3[128];
char FOURLINK4[128];
char FOURLINK5[128];
char FOURLINK6[128];
char FOURLINK7[128];
char FOURLINK8[128];
char FOURLINK9[128];
char FOURLINKER[10];
//==========================
char FIVELINK1[128];
char FIVELINK2[128];
char FIVELINK3[128];
char FIVELINK4[128];
char FIVELINK5[128];
char FIVELINK6[128];
char FIVELINK7[128];
char FIVELINK8[128];
char FIVELINK9[128];
char FIVELINKER[10];
//==========================
char SIXLINK1[128];
char SIXLINK2[128];
char SIXLINK3[128];
char SIXLINK4[128];
char SIXLINK5[128];
char SIXLINK6[128];
char SIXLINK7[128];
char SIXLINK8[128];
char SIXLINK9[128];
char SIXLINKER[10];
//==========================
char SEVENLINK1[128];
char SEVENLINK2[128];
char SEVENLINK3[128];
char SEVENLINK4[128];
char SEVENLINK5[128];
char SEVENLINK6[128];
char SEVENLINK7[128];
char SEVENLINK8[128];
char SEVENLINK9[128];
char SEVENLINKER[10];
//==========================
char EIGHTLINK1[128];
char EIGHTLINK2[128];
char EIGHTLINK3[128];
char EIGHTLINK4[128];
char EIGHTLINK5[128];
char EIGHTLINK6[128];
char EIGHTLINK7[128];
char EIGHTLINK8[128];
char EIGHTLINK9[128];
char EIGHTLINKER[10];
//==========================
char NINELINK1[128];
char NINELINK2[128];
char NINELINK3[128];
char NINELINK4[128];
char NINELINK5[128];
char NINELINK6[128];
char NINELINK7[128];
char NINELINK8[128];
char NINELINK9[128];
char NINELINKER[10];
//==========================
char ADDLINK1[128];
char ADDLINK2[128];
char ADDLINK3[128];
char ADDLINK4[128];
char ADDLINK5[128];
char ADDLINK6[128];
char ADDLINKER[10];
//============================config definitions

/*//============================img paths
char anime_bg[128];
char bg[128];
char cursor[128];
char main_addi[128];
char main_list[128];
char add_list[128];
char add_bg[128];
char one_bg[128];
char two_bg[128];
char three_bg[128];
char four_bg[128];
char five_bg[128];
char six_bg[128];
char seven_bg[128];
char eight_bg[128];
char nine_bg[128];
char one_list[128];
char two_list[128];
char three_list[128];
char four_list[128];
char five_list[128];
char six_list[128];
char seven_list[128];
char eight_list[128];
char nine_list[128];
//============================img paths*/
extern IMGHDR *anime_bg,*bg,*cursor,*add_list,*add_bg,*main_addi,*main_list,*one_bg,*two_bg,*three_bg,*four_bg,*five_bg,*six_bg,*seven_bg,*eight_bg,*nine_bg,*one_list,*two_list,*three_list,*four_list,*five_list,*six_list,*seven_list,*eight_list,*nine_list;

int (*old_icsm_onMessage)(CSM_RAM*,GBS_MSG*);
void (*old_icsm_onClose)(CSM_RAM*);

unsigned short maincsm_name_body[140];
const int minus11=-11;
extern const int animate_bg;

typedef struct
{
  CSM_RAM csm;
  int gui_id;
}MAIN_CSM;

typedef struct
{
  GUI gui;
  WSHDR *ws1;
  WSHDR *ws2;
  int i1;
}MAIN_GUI;

int start_y;
int y;
int cursor_h=15;
int sub_x;
int start_anim;
int main_add;
int y_b;
int y_d;
int y2;
int sub_on;
int subbed;
int sub_pos;
int main_pos;
int sub_menu_c;
int sub_y;
int wap_browser();
int my_stuff();
int develop();
IMGHDR screen={0,0,8,""};

//==============
int addon;
int y_add;
int y_d_add;
int y_b_add;
int animate_to_add;
int add_pos;
int dont_do;
//==============addon

GBSTMR anime;
int inam;
int show_all;
int anime_y;

void animating()
{
  inam=1;
  show_all=1;
  if((anime_y!=0)&&(UPPER))
  {
    show_all=0;
    anime_y=anime_y+2;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating);
  }
  else
  if((anime_y!=294)&&(!UPPER))
  {
    show_all=0;
    anime_y=anime_y-2;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating);
  }
  else
  if((y_b!=26)&&(UPPER)) 
  {
    y=y+9; y_d=y_d+9; y_b=y_b+9;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating);
  }
  else
  if((y_b!=159)&&(!UPPER)) 
  {
    y=y-9; y_d=y_d-9; y_b=y_b-9;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating);
  }
  else
    if((main_add<=90)&&(use_add_m))
    {
      main_add=main_add+3;
      DirectRedrawGUI();
      GBS_StartTimerProc(&anime, 3, animating);
    }
  else
  {
    inam=0;
    DirectRedrawGUI();
  }
}

void animating_addon1()
{
  inam=1;
  if((y_b_add!=26)&&(UPPER)) 
  {
    y_add=y_add+9; y_d_add=y_d_add+9; y_b_add=y_b_add+9;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating_addon1);
  }
  else
    if((y_b_add!=204)&&(!UPPER)) 
  {
    y_add=y_add-9; y_d_add=y_d_add-9; y_b_add=y_b_add-9;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating_addon1);
  }
  else
  {
    inam=0;
    DirectRedrawGUI();
  }
}

void animating_addon2()
{
  inam=1;
  show_all=1;
  if((y_b_add!=(-100))&&(UPPER)) 
  {
    y_add=y_add-9; y_d_add=y_d_add-9; y_b_add=y_b_add-9;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating_addon2);
  }
  else
  if((y_b_add!=(294))&&(!UPPER)) 
  {
    y_add=y_add+9; y_d_add=y_d_add+9; y_b_add=y_b_add+9;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating_addon2);
  }
  else
  {
    if((!animate_to_add)&&(anime_y!=(-26))&&(UPPER)&&(!animate_bg))
    {
      show_all=0;
      anime_y=anime_y-2;
      DirectRedrawGUI();
      GBS_StartTimerProc(&anime, 3, animating_addon2);
    }
    else
    if((!animate_to_add)&&(anime_y!=320)&&(!UPPER)&&(!animate_bg))
    {
      show_all=0;
      anime_y=anime_y+2;
      DirectRedrawGUI();
      GBS_StartTimerProc(&anime, 3, animating_addon2);
    } 
    else
    if(!animate_to_add) 
      CloseCSM(MAINCSM_ID);
    else
    {
      if(!dont_do) y=y-126;
      if(UPPER)
      {
      y_b=(-100);
      y_d=(-100);
      }
      else
      {
      y_b=(294);
      y_d=(294);
      }
      dont_do=0; 
      main_add=43;
      animate_to_add=0;
      addon=0;
      animating();
    }
  }
}

void animating2()
{
  dont_do=1;
  inam=1;
  show_all=1;
  if((main_add>73)&&(use_add_m))
  {
    main_add=main_add-3;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating2);
  }
  else
  if((y_b!=(-100))&&(UPPER)) 
  {
    y=y-9; y_d=y_d-9; y_b=y_b-9;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating2);
  }
  else
  if((y_b!=294)&&(!UPPER)) 
  {
    y=y+9; y_d=y_d+9; y_b=y_b+9;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating2);
  }
  else
  if((!animate_to_add)&&(anime_y!=(-26))&&(UPPER)&&(!animate_bg))
  {
    show_all=0;
    anime_y=anime_y-2;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating2);
  }
  else
  if((!animate_to_add)&&(anime_y!=320)&&(!UPPER)&&(!animate_bg))
  {
    show_all=0;
    anime_y=anime_y+2;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating2);
  }  
  else
  {
    if((animate_to_add)&&(UPPER)) {addon=1; y_add=(-100); animating_addon1();}
    else
    if((animate_to_add)&&(!UPPER)) {addon=1; y_add=(294); animating_addon1();}
    else
    CloseCSM(MAINCSM_ID);
  }
}

void animating3()
{
  inam=1;
  if((sub_x<109)&&(start_anim))
  {
    sub_x=sub_x+9;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating3);
  }
  else
  if(sub_x>75)
  {
    start_anim=0;
    sub_x=sub_x-9;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating3);
  }
  else
  {
    sub_x=75;
    inam=0;
    DirectRedrawGUI();
  }
}

void animating4()
{
  inam=1;
  if((sub_x<109)&&(!start_anim))
  {
    sub_x=sub_x+9;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating4);
  }
  else
  if(sub_x>18)
  {
    start_anim=1;
    sub_x=sub_x-9;
    DirectRedrawGUI();
    GBS_StartTimerProc(&anime, 3, animating4);
  }
  else
  {
    inam=0;
    start_anim=0;
    sub_on=0;
    DirectRedrawGUI();
  }
}

int tentimes;
int plus;

void animating7()
{
  inam=1;
  tentimes--;
  if(plus) y2++; else y2--;
  DirectRedrawGUI();
  if(tentimes) GBS_StartTimerProc(&anime, 3, animating7);
  else
    inam=0;
}

void animating8()
{
  inam=1;
  tentimes--;
  if(plus) y++; else y--;
  DirectRedrawGUI();
  if(tentimes) GBS_StartTimerProc(&anime, 3, animating8);
  else
    inam=0;
}

void DrwImg2(IMGHDR *img, int x, int y, char *pen, char *brush)
{
  RECT rc;
  DRWOBJ drwobj;
  StoreXYWHtoRECT(&rc,x,y,img->w,img->h);
  SetPropTo_Obj5(&drwobj,&rc,0,img);
  SetColor(&drwobj,pen,brush);
  DrawObject(&drwobj);
}

void DoScreen()
{
    int ScrH=ScreenH();
    int ScrW=ScreenW();
    char *ms=RamScreenBuffer();
    screen.w=ScrW;
    screen.h=ScrH;
    screen.bitmap=malloc(ScrW*ScrH*2);
    memcpy(screen.bitmap, ms, ScrW*ScrH*2);
}


/*
void ClockDraw()
{
    WSHDR *ws=AllocWS(64);
    TTime time;
    GetDateTime(NULL, &time);
    wsprintf(ws, "%02d:%02d:%02d", time.hour, time.min, time.sec);  
    void *canvasdata = BuildCanvas();
    DrawCanvas(canvasdata,126-Get_WS_width(ws,11),162,130,162+GetFontYSIZE(11)+3,1);
    DrawString(ws,128-Get_WS_width(ws,11),162,130,162+GetFontYSIZE(11)+3,11,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
    FreeWS(ws);
}
*/
GBSTMR min_ref;

void refresher()
{
  DirectRedrawGUI();
}
//================addon new
static DrwImage(int x, int y, IMGHDR *img, char *pen, char *brush)
{
  RECT rc;
  DRWOBJ drwobj;
  StoreXYWHtoRECT(&rc,x,y,img->w,img->h);
  SetPropTo_Obj5(&drwobj,&rc,0,img);
  SetColor(&drwobj,pen,brush);
  DrawObject(&drwobj);
}
//===================end addon

/*void OnRedraw(MAIN_GUI *data) // OnRedraw
{
  GBS_DelTimer(&min_ref);
  DrwImg2(&screen, 0, 0, NULL, NULL);
  if(!addon)
  {
  if(!start_anim)
  {
  DrawImg(main_add,y_b-1,(int)main_addi);
  DrawImg(0,y_b-1,(int)bg);
  DrawImg(0,y,(int)cursor);
  DrawImg(1,y_d-1,(int)main_list);
  DrawImg(0,0,(int)anime_bg);
  }
  if(sub_on)
  {
    switch(main_pos)
    {
    case 1:
      DrawImg(sub_x,y+3,(int)one_bg);
      DrawImg(sub_x,y2,(int)cursor);
      DrawImg(sub_x,y+3,(int)one_list);
      break;
    case 2:
      DrawImg(sub_x,y+3,(int)two_bg);
      DrawImg(sub_x,y2,(int)cursor);
      DrawImg(sub_x,y+3,(int)two_list);
      break;
    case 3:
      DrawImg(sub_x,y+3,(int)three_bg);
      DrawImg(sub_x,y2,(int)cursor);
      DrawImg(sub_x,y+3,(int)three_list);
      break;
    case 4:
      DrawImg(sub_x,y+3,(int)four_bg);
      DrawImg(sub_x,y2,(int)cursor);
      DrawImg(sub_x,y+3,(int)four_list);
      break;
    case 5:
      DrawImg(sub_x,y+3,(int)five_bg);
      DrawImg(sub_x,y2,(int)cursor);
      DrawImg(sub_x,y+3,(int)five_list);
      break;
    case 6:
      DrawImg(sub_x,y+3,(int)six_bg);
      DrawImg(sub_x,y2,(int)cursor);
      DrawImg(sub_x,y+3,(int)six_list);
      break;
    case 7:
      DrawImg(sub_x,y+3,(int)seven_bg);
      DrawImg(sub_x,y2,(int)cursor);
      DrawImg(sub_x,y+3,(int)seven_list);
      break;
    case 8:
      DrawImg(sub_x,y+3,(int)eight_bg);
      DrawImg(sub_x,y2,(int)cursor);
      DrawImg(sub_x,y+3,(int)eight_list);
      break;
    case 9:
      DrawImg(sub_x,y+3,(int)nine_bg);
      DrawImg(sub_x,y2,(int)cursor);
      DrawImg(sub_x,y+3,(int)nine_list);
      break;
    }
  }
  if(start_anim)
  {
  DrawImg(main_add,y_b-1,(int)main_addi);
  DrawImg(0,y_b-1,(int)bg);
  DrawImg(0,y,(int)cursor);
  DrawImg(1,y_d-1,(int)main_list);
  DrawImg(0,0,(int)anime_bg);
  }
  }
  else
  {
    DrawImg(32,y_b_add-1,(int)add_bg);
    DrawImg(32,y_add,(int)cursor);
    DrawImg(32,y_d_add-1,(int)add_list);
    DrawImg(0,0,(int)anime_bg);
  }
//  ClockDraw();
  GBS_StartTimerProc(&min_ref, 216, refresher);
}*/

void OnRedraw(MAIN_GUI *data) // OnRedraw
{
  GBS_DelTimer(&min_ref);
  DrwImg2(&screen, 0, 0, NULL, NULL);
  if(!addon)
  {
  if(!start_anim)
  {
    if(show_all)
    {
  DrwImage(main_add,y_b-1,main_addi, 0, 0);
  DrwImage(0,y_b-1,bg, 0, 0);
  DrwImage(0,y,cursor, 0, 0);
  DrwImage(1,y_d-1,main_list, 0, 0); //anima_bg_y
    }
  if(UPPER)
  DrwImage(0,anime_y,anime_bg, 0, 0);
  else
  DrwImage(0,anime_y,anime_bg, 0, 0);
  }
  if(sub_on)
  {
    switch(main_pos)
    {
    case 1:
      DrwImage(sub_x,y+3,one_bg, 0, 0);
      DrwImage(sub_x,y2,cursor, 0, 0);
      DrwImage(sub_x,y+3,one_list, 0, 0);
      break;
    case 2:
      DrwImage(sub_x,y+3,two_bg, 0, 0);
      DrwImage(sub_x,y2,cursor, 0, 0);
      DrwImage(sub_x,y+3,two_list, 0, 0);
      break;
    case 3:
      DrwImage(sub_x,y+3,three_bg, 0, 0);
      DrwImage(sub_x,y2,cursor, 0, 0);
      DrwImage(sub_x,y+3,three_list, 0, 0);
      break;
    case 4:
      DrwImage(sub_x,y+3,four_bg, 0, 0);
      DrwImage(sub_x,y2,cursor, 0, 0);
      DrwImage(sub_x,y+3,four_list, 0, 0);
      break;
    case 5:
      DrwImage(sub_x,y+3,five_bg, 0, 0);
      DrwImage(sub_x,y2,cursor, 0, 0);
      DrwImage(sub_x,y+3,five_list, 0, 0);
      break;
    case 6:
      DrwImage(sub_x,y+3,six_bg, 0, 0);
      DrwImage(sub_x,y2,cursor, 0, 0);
      DrwImage(sub_x,y+3,six_list, 0, 0);
      break;
    case 7:
      DrwImage(sub_x,y+3,seven_bg, 0, 0);
      DrwImage(sub_x,y2,cursor, 0, 0);
      DrwImage(sub_x,y+3,seven_list, 0, 0);
      break;
    case 8:
      DrwImage(sub_x,y+3,eight_bg, 0, 0);
      DrwImage(sub_x,y2,cursor, 0, 0);
      DrwImage(sub_x,y+3,eight_list, 0, 0);
      break;
    case 9:
      DrwImage(sub_x,y+3,nine_bg, 0, 0);
      DrwImage(sub_x,y2,cursor, 0, 0);
      DrwImage(sub_x,y+3,nine_list, 0, 0);
      break;
    }
  }
  if(start_anim)
  {
    if(show_all)
    {
  DrwImage(main_add,y_b-1,main_addi, 0, 0);
  DrwImage(0,y_b-1,bg, 0, 0);
  DrwImage(0,y,cursor, 0, 0);
  DrwImage(1,y_d-1,main_list, 0, 0);
    }
  if(UPPER)
  DrwImage(0,anime_y,anime_bg, 0, 0);
  else
  DrwImage(0,anime_y,anime_bg, 0, 0);
  }
  }
  else
  {
    if(show_all)
    {
    DrwImage(32,y_b_add-1,add_bg, 0, 0);
    DrwImage(32,y_add,cursor, 0, 0);
    DrwImage(32,y_d_add-1,add_list, 0, 0);
    }
    if(UPPER)
    DrwImage(0,anime_y,anime_bg, 0, 0);
    else
    DrwImage(0,anime_y,anime_bg, 0, 0);
  }
//  ClockDraw();
  GBS_StartTimerProc(&min_ref, 216, refresher);
}

void onCreate(MAIN_GUI *data, void *(*malloc_adr)(int)) //Create
{
  data->gui.state=1;
}

void onClose(MAIN_GUI *data, void (*mfree_adr)(void *)) //Close
{
//  show_all=0;
  mfree(screen.bitmap);
  if(not_close)
  {
    char* ramIconBar = RamIconBar();
    *ramIconBar = 1;
  }
  MAINCSM_ID=0;
  data->gui.state=0;
}

void onFocus(MAIN_GUI *data, void *(*malloc_adr)(int), void (*mfree_adr)(void *))//Focus
{
  data->gui.state=2;
}

void onUnfocus(MAIN_GUI *data, void (*mfree_adr)(void *)) //Unfocus
{
//  char* ramIconBar = RamIconBar();
//  *ramIconBar = 1;
  
  CloseCSM(MAINCSM_ID);
  if (data->gui.state!=2) return;
  data->gui.state=1;
}

GBSTMR mytmr;
void to_do()
{
  develop();
}

const char ipc_my_name[]="StartMenu";
const char ipc_xtask_name[]=IPC_XTASK_NAME;
IPC_REQ gipc;


void Run(char *links, int Flag)
{
  switch(Flag)
  {
  case 49:
    {
      WSHDR *elfname=AllocWS(256);
      wsprintf(elfname,links);
      ExecuteFile(elfname,NULL,NULL);
      FreeWS(elfname);
    }
    break;
  case 50:
    {
      typedef void (*voidfunc)(); 
      unsigned int addr=strtoul( links, 0, 16 );
      voidfunc pp=(voidfunc)addr;
      SUBPROC((void*)pp);
    }
    break;
  case 51:
    {
      unsigned int* addr = (unsigned int*)links;
      if (addr)
      {
        typedef void (*voidfunc)();          
        voidfunc pp=(voidfunc)*(addr+4);
        SUBPROC((void*)pp);
      }
    }
    break;
  case 52:
    if(links[0]=='X')
    {
      gipc.name_to=ipc_xtask_name;
      gipc.name_from=ipc_my_name;
      gipc.data=0;
      GBS_SendMessage(MMI_CEPID,MSG_IPC,IPC_XTASK_OFFE,&gipc);
    }
    break;
  }
}

void Engade()
{
  char* ramIconBar = RamIconBar();
  *ramIconBar = 1;
  not_close=0;
  if(addon)
  {
    switch(add_pos)
    {
    case 1:
      Run(ADDLINK1, ADDLINKER[add_pos]);
      break;
    case 2:
      Run(ADDLINK2, ADDLINKER[add_pos]);
      break;
    case 3:
      Run(ADDLINK3, ADDLINKER[add_pos]);
      break;
    case 4:
      Run(ADDLINK4, ADDLINKER[add_pos]);
      break;
    case 5:
      Run(ADDLINK5, ADDLINKER[add_pos]);
      break;
    case 6:
      Run(ADDLINK6, ADDLINKER[add_pos]);
      break;
    }
  }
  else
  switch(main_pos)
  {
  case 1:
    if(!sub_on) Run(MLINK1, MLINKER[main_pos]);
    else
    {
      switch(sub_pos)
      {
      case 1:
        Run(ONELINK1, ONELINKER[sub_pos]);
        break;
      case 2:
        Run(ONELINK2, ONELINKER[sub_pos]);
        break;
      case 3:
        Run(ONELINK3, ONELINKER[sub_pos]);
        break;
      case 4:
        Run(ONELINK4, ONELINKER[sub_pos]);
        break;
      case 5:
        Run(ONELINK5, ONELINKER[sub_pos]);
        break;
      case 6:
        Run(ONELINK6, ONELINKER[sub_pos]);
        break;
      case 7:
        Run(ONELINK7, ONELINKER[sub_pos]);
        break;
      case 8:
        Run(ONELINK8, ONELINKER[sub_pos]);
        break;
      case 9:
        Run(ONELINK9, ONELINKER[sub_pos]);
        break;
      }
    }
    break;
  case 2:
    if(!sub_on) Run(MLINK2, MLINKER[main_pos]);
    else
    {
      switch(sub_pos)
      {
      case 1:
        Run(TWOLINK1, TWOLINKER[sub_pos]);
        break;
      case 2:
        Run(TWOLINK2, TWOLINKER[sub_pos]);
        break;
      case 3:
        Run(TWOLINK3, TWOLINKER[sub_pos]);
        break;
      case 4:
        Run(TWOLINK4, TWOLINKER[sub_pos]);
        break;
      case 5:
        Run(TWOLINK5, TWOLINKER[sub_pos]);
        break;
      case 6:
        Run(TWOLINK6, TWOLINKER[sub_pos]);
        break;
      case 7:
        Run(TWOLINK7, TWOLINKER[sub_pos]);
        break;
      case 8:
        Run(TWOLINK8, TWOLINKER[sub_pos]);
        break;
      case 9:
        Run(TWOLINK9, TWOLINKER[sub_pos]);
        break;
      }
    }
    break;
  case 3:
    if(!sub_on) Run(MLINK3, MLINKER[main_pos]);
    else
    {
      switch(sub_pos)
      {
      case 1:
        Run(THREELINK1, THREELINKER[sub_pos]);
        break;
      case 2:
        Run(THREELINK2, THREELINKER[sub_pos]);
        break;
      case 3:
        Run(THREELINK3, THREELINKER[sub_pos]);
        break;
      case 4:
        Run(THREELINK4, THREELINKER[sub_pos]);
        break;
      case 5:
        Run(THREELINK5, THREELINKER[sub_pos]);
        break;
      case 6:
        Run(THREELINK6, THREELINKER[sub_pos]);
        break;
      case 7:
        Run(THREELINK7, THREELINKER[sub_pos]);
        break;
      case 8:
        Run(THREELINK8, THREELINKER[sub_pos]);
        break;
      case 9:
        Run(THREELINK9, THREELINKER[sub_pos]);
        break;
      }
    }
    break;
  case 4:
    if(!sub_on) Run(MLINK4, MLINKER[main_pos]);
    else
    {
      switch(sub_pos)
      {
      case 1:
        Run(FOURLINK1, FOURLINKER[sub_pos]);
        break;
      case 2:
        Run(FOURLINK2, FOURLINKER[sub_pos]);
        break;
      case 3:
        Run(FOURLINK3, FOURLINKER[sub_pos]);
        break;
      case 4:
        Run(FOURLINK4, FOURLINKER[sub_pos]);
        break;
      case 5:
        Run(FOURLINK5, FOURLINKER[sub_pos]);
        break;
      case 6:
        Run(FOURLINK6, FOURLINKER[sub_pos]);
        break;
      case 7:
        Run(FOURLINK7, FOURLINKER[sub_pos]);
        break;
      case 8:
        Run(FOURLINK8, FOURLINKER[sub_pos]);
        break;
      case 9:
        Run(FOURLINK9, FOURLINKER[sub_pos]);
        break;
      }
    }
    break;
  case 5:
    if(!sub_on) Run(MLINK5, MLINKER[main_pos]);
    else
    {
      switch(sub_pos)
      {
      case 1:
        Run(FIVELINK1, FIVELINKER[sub_pos]);
        break;
      case 2:
        Run(FIVELINK2, FIVELINKER[sub_pos]);
        break;
      case 3:
        Run(FIVELINK3, FIVELINKER[sub_pos]);
        break;
      case 4:
        Run(FIVELINK4, FIVELINKER[sub_pos]);
        break;
      case 5:
        Run(FIVELINK5, FIVELINKER[sub_pos]);
        break;
      case 6:
        Run(FIVELINK6, FIVELINKER[sub_pos]);
        break;
      case 7:
        Run(FIVELINK7, FIVELINKER[sub_pos]);
        break;
      case 8:
        Run(FIVELINK8, FIVELINKER[sub_pos]);
        break;
      case 9:
        Run(FIVELINK9, FIVELINKER[sub_pos]);
        break;
      }
    }
    break;
  case 6:
    if(!sub_on) Run(MLINK6, MLINKER[main_pos]);
    else
    {
      switch(sub_pos)
      {
      case 1:
        Run(SIXLINK1, SIXLINKER[sub_pos]);
        break;
      case 2:
        Run(SIXLINK2, SIXLINKER[sub_pos]);
        break;
      case 3:
        Run(SIXLINK3, SIXLINKER[sub_pos]);
        break;
      case 4:
        Run(SIXLINK4, SIXLINKER[sub_pos]);
        break;
      case 5:
        Run(SIXLINK5, SIXLINKER[sub_pos]);
        break;
      case 6:
        Run(SIXLINK6, SIXLINKER[sub_pos]);
        break;
      case 7:
        Run(SIXLINK7, SIXLINKER[sub_pos]);
        break;
      case 8:
        Run(SIXLINK8, SIXLINKER[sub_pos]);
        break;
      case 9:
        Run(SIXLINK9, SIXLINKER[sub_pos]);
        break;
      }
    }
    break;
  case 7:
    if(!sub_on) Run(MLINK7, MLINKER[main_pos]);
    else
    {
      switch(sub_pos)
      {
      case 1:
        Run(SEVENLINK1, SEVENLINKER[sub_pos]);
        break;
      case 2:
        Run(SEVENLINK2, SEVENLINKER[sub_pos]);
        break;
      case 3:
        Run(SEVENLINK3, SEVENLINKER[sub_pos]);
        break;
      case 4:
        Run(SEVENLINK4, SEVENLINKER[sub_pos]);
        break;
      case 5:
        Run(SEVENLINK5, SEVENLINKER[sub_pos]);
        break;
      case 6:
        Run(SEVENLINK6, SEVENLINKER[sub_pos]);
        break;
      case 7:
        Run(SEVENLINK7, SEVENLINKER[sub_pos]);
        break;
      case 8:
        Run(SEVENLINK8, SEVENLINKER[sub_pos]);
        break;
      case 9:
        Run(SEVENLINK9, SEVENLINKER[sub_pos]);
        break;
      }
    }
    break;
  case 8:
    if(!sub_on) Run(MLINK8, MLINKER[main_pos]);
    else
    {
      switch(sub_pos)
      {
      case 1:
        Run(EIGHTLINK1, EIGHTLINKER[sub_pos]);
        break;
      case 2:
        Run(EIGHTLINK2, EIGHTLINKER[sub_pos]);
        break;
      case 3:
        Run(EIGHTLINK3, EIGHTLINKER[sub_pos]);
        break;
      case 4:
        Run(EIGHTLINK4, EIGHTLINKER[sub_pos]);
        break;
      case 5:
        Run(EIGHTLINK5, EIGHTLINKER[sub_pos]);
        break;
      case 6:
        Run(EIGHTLINK6, EIGHTLINKER[sub_pos]);
        break;
      case 7:
        Run(EIGHTLINK7, EIGHTLINKER[sub_pos]);
        break;
      case 8:
        Run(EIGHTLINK8, EIGHTLINKER[sub_pos]);
        break;
      case 9:
        Run(EIGHTLINK9, EIGHTLINKER[sub_pos]);
        break;
      }
    }
    break;
  case 9:
    if(!sub_on) Run(MLINK9, MLINKER[main_pos]);
    else
    {
      switch(sub_pos)
      {
      case 1:
        Run(NINELINK1, NINELINKER[sub_pos]);
        break;
      case 2:
        Run(NINELINK2, NINELINKER[sub_pos]);
        break;
      case 3:
        Run(NINELINK3, NINELINKER[sub_pos]);
        break;
      case 4:
        Run(NINELINK4, NINELINKER[sub_pos]);
        break;
      case 5:
        Run(NINELINK5, NINELINKER[sub_pos]);
        break;
      case 6:
        Run(NINELINK6, NINELINKER[sub_pos]);
        break;
      case 7:
        Run(NINELINK7, NINELINKER[sub_pos]);
        break;
      case 8:
        Run(NINELINK8, NINELINKER[sub_pos]);
        break;
      case 9:
        Run(NINELINK9, NINELINKER[sub_pos]);
        break;
      }
    }
    break;
  }
}

//extern const int use_anim;
//int use_anim=1;

int OnKey(MAIN_GUI *data, GUI_MSG *msg) //OnKey
{ 
  if (((msg->gbsmsg->msg==KEY_DOWN)||(msg->gbsmsg->msg==LONG_PRESS))&&(inam==0)&&(addon==1))
  {
    switch(msg->gbsmsg->submess)
    {
    case RIGHT_SOFT:
      animate_to_add=0;
//      if(use_anim)
      animating_addon2();
/*      else
         {
           if(UPPER)
           {
             y_add=y_add-126; y_d_add=y_d_add-126; y_b_add=(-100); CloseCSM(MAINCSM_ID);
           }
           else
           {
             y_add=y_add+126; y_d_add=y_d_add+126; y_b_add=(294); CloseCSM(MAINCSM_ID);
           }
         }*/
      break;
    case LEFT_BUTTON:
 //     if(use_anim)
      animating_addon2();
 /*     else
         {
           if(UPPER)
           {
             y_add=y_add-126; y_d_add=y_d_add-126; y_b_add=(-100); 
             if(!dont_do) y=y-126; y_b=(-100); y_d=(-100); dont_do=0;  main_add=43; animate_to_add=0; addon=0;
             y_b=26; y=y+126; y_d=y_d+126; 
           }
           else
           {
             y_add=y_add+126; y_d_add=y_d_add+126; y_b_add=(294);
             if(!dont_do) y=y-126; y_b=(294); y_d=(294); dont_do=0;  main_add=43; animate_to_add=0; addon=0;
             y_b=159; y=y-126; y_d=y_d-126; 
           }
         }*/
      break;
    case LEFT_SOFT:
    case ENTER_BUTTON:
      Engade();
      return(1);
    case UP_BUTTON:
      add_pos--;
      if(add_pos==0) {y_add=y_add+(5*cursor_h); add_pos=6;}
      else y_add=y_add-cursor_h;
      DirectRedrawGUI();
      break;
    case DOWN_BUTTON:
      add_pos++;
      if(add_pos==7) {y_add=y_add-(5*cursor_h); add_pos=1;}
      else y_add=y_add+cursor_h;
      DirectRedrawGUI();
      break;
    }
  }
  if (((msg->gbsmsg->msg==KEY_DOWN)||(msg->gbsmsg->msg==LONG_PRESS))&&(inam==0)&&(addon==0))
  {
 //   DirectRedrawGUI();  
    switch(msg->gbsmsg->submess)
    {
    case RIGHT_SOFT: 
      if(sub_on)
 //       if(use_anim)
        animating4();
      else
 //       if(use_anim)
        animating2();
 /*       else
         {
           if(UPPER)
           {
             y=y-126; y_d=y_d-126; y_b=(-100); CloseCSM(MAINCSM_ID);
           }
           else
           {
             y=y+126; y_d=y_d+126; y_b=294; CloseCSM(MAINCSM_ID);
           }
         }*/
      break;
    case RIGHT_BUTTON:
      if(!sub_on)
      {
        animate_to_add=1;
        add_pos=1;
  //      if(use_anim)
        animating2();
  /*      else
         {
           if(UPPER)
           {
             y=y-126; y_d=y_d-126; y_b=(-100); addon=1; y_add=(-100);
             y_add=y_add+126; y_d_add=y_d_add+126; y_b_add=26;
           }
           else
           {
             y=y+126; y_d=y_d+126; y_b=294; addon=1; y_add=(294);
             y_add=y_add-126; y_d_add=y_d_add-126; y_b_add=204;
           }
         }*/
      }
      break;
    case DOWN_BUTTON:
      {
        if(sub_on)
        {
          sub_pos++;
          y2=y2+cursor_h;
          if(y2>(sub_y-4+y)) 
          {
            sub_pos=1;
            y2=y+4;
          }
/*          else
          {
            y2=y2-10;
            tentimes=10;
            plus=1;
            animating7();
          }*/
        }
        else
        {
          main_pos++;
          y=y+cursor_h;
          if(y>(start_y+8+(8*cursor_h))) //114
          {
            y=start_y;
            main_pos=1;
          }
 /*         else
          {
            y=y-10;
            tentimes=10;
            plus=1;
            animating8();
          }*/
        }
        DirectRedrawGUI();
      }
        break;
     case UP_BUTTON:
       {
          if(sub_on)
          {
            sub_pos--;
            y2=y2-cursor_h;
            if(y2<y-1) 
            {
              sub_pos=sub_menu_c;
              y2=y+sub_y-11;
              
            }
            DirectRedrawGUI();
/*            else
            {
              y2=y2+10;
              plus=0;
              tentimes=10;
              animating7();
            }*/
          }
          else
          {
            main_pos--;
            y=y-cursor_h;
            if(y<start_y-4) 
            {
              y=start_y+(8*cursor_h);  //109
              main_pos=9;
              
            }
            DirectRedrawGUI();
  /*          else
            {
              y=y+10;
              plus=0;
              tentimes=10;
              animating8();
            }*/
          }
        }
        break;
    case LEFT_SOFT:
    case ENTER_BUTTON:
      {
        if(sub_on)
        {
          Engade();
          sub_on=0;
          return(1);
        }
        else
        {
/*          if((main_pos==3)||(main_pos==5)||(main_pos==6)||(main_pos==7)||(main_pos==8)||(main_pos==9))
          {
            Engade();
            return(1);
          }*/
          if(LinkCounters[main_pos-1]=='0') {Engade(); return(1);}
          else
          {
            sub_menu_c=LinkCounters[main_pos-1];
            sub_menu_c=sub_menu_c-48;
/*          sub_menu_c=8;
          if(main_pos==6) sub_menu_c=8;
          if(main_pos==4) sub_menu_c=2;
          if(main_pos==2) sub_menu_c=6;*/
            sub_y=sub_menu_c*cursor_h;
            y2=y+4;
            sub_on=1;
            sub_pos=1;
            start_anim=1;
            sub_x=18;
      //      if(use_anim)
            animating3();
          }
        }
      }
      break;
    }
  }
  return(0);
}

int method8(void){return(0);}

int method9(void){return(0);}

extern void kill_data(void *p,void (*func_p)(void *));
void ElfKiller(void)
{
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}

const void * const gui_methods[11]={
  (void *)OnRedraw,	//Redraw
  (void *)onCreate,	//Create
  (void *)onClose,	//Close
  (void *)onFocus,	//Focus
  (void *)onUnfocus,	//Unfocus
  (void *)OnKey,	//OnKey
  0,
  (void *)kill_data,	//Destroy
  (void *)method8,
  (void *)method9,
  0
};

const RECT Canvas={0,0,0,0};


#pragma inline
void patch_rect(const RECT*rcc,int x,int y, int x2, int y2)
{
  RECT *rc=(RECT *)rcc;
  rc->x=x;
  rc->y=y;
  rc->x2=x2;
  rc->y2=y2;
}

void maincsm_oncreate(CSM_RAM *data)
{
  MAIN_GUI *main_gui=malloc(sizeof(MAIN_GUI));
  MAIN_CSM*csm=(MAIN_CSM*)data;
  zeromem(main_gui,sizeof(MAIN_GUI));
  main_gui->gui.canvas=(void *)(&Canvas);
  main_gui->gui.methods=(void *)gui_methods;
  main_gui->gui.item_ll.data_mfree=(void (*)(void *))mfree_adr();
  patch_rect((RECT*)&Canvas,0,YDISP,ScreenW()-1,ScreenH()-1);
  csm->csm.state=0;
  csm->csm.unk1=0;
  csm->gui_id=CreateGUI(main_gui);
  char* ramIconBar = RamIconBar();
  *ramIconBar = 0;
}

void maincsm_onclose(CSM_RAM *csm)
{
  //SUBPROC((void *)ElfKiller);
}

int maincsm_onmessage(CSM_RAM *data, GBS_MSG *msg)
{
  MAIN_CSM *csm=(MAIN_CSM*)data;
   if ((msg->msg==MSG_GUI_DESTROYED)&&((int)msg->data0==csm->gui_id))
  {
    csm->csm.state=-3;
  } 
  return(1); 
}

const struct
{
  CSM_DESC maincsm;
  WSHDR maincsm_name;
}MAINCSM =
{
  {
  maincsm_onmessage,
  maincsm_oncreate,
#ifdef NEWSGOLD
  0,
  0,
  0,
  0,
#endif
  maincsm_onclose,
  sizeof(MAIN_CSM),
  1,
  &minus11
  },
  {
    maincsm_name_body,
    NAMECSM_MAGIC1,
    NAMECSM_MAGIC2,
    0x0,
    139
  }
};

void UpdateCSMname(void)
{
  wsprintf((WSHDR *)(&MAINCSM.maincsm_name),"Fox menu");
}


void MyIDLECSM_onClose(CSM_RAM *data)
{
  extern void seqkill(void *data, void(*next_in_seq)(CSM_RAM *), void *data_to_kill, void *seqkiller);
  extern void *ELF_BEGIN;
  seqkill(data,old_icsm_onClose,&ELF_BEGIN,SEQKILLER_ADR());
}

#pragma inline=forced
int toupper(int c)
{
  if ((c>='a')&&(c<='z')) c+='A'-'a';
  return(c);
}
#pragma inline
int strcmp_nocase(const char *s1,const char *s2)
{
  int i;
  int c;
  while(!(i=(c=toupper(*s1++))-toupper(*s2++))) if (!c) break;
  return(i);
}

int MyIDLECSM_onMessage(CSM_RAM* data, GBS_MSG* msg)
{
  int csm_result;
  csm_result=old_icsm_onMessage(data,msg);
  
  void *icsm=FindCSMbyID(CSM_root()->idle_id);
  if ((IsGuiOnTop(((int *)icsm)[DISPLACE_OF_IDLEGUI_ID/4]))&&(!IsScreenSaver()))
  {

  }
  if(msg->msg == MSG_RECONFIGURE_REQ) 
  {
    extern const char *successed_config_filename;
    if (strcmp_nocase(successed_config_filename,(char *)msg->data0)==0)
    {
      ShowMSG(1,(int)"FoxMenu0.3 config updated!");
      InitConfig();
      sub_pos=1;
      main_pos=1;
      dont_do=0;
      inam=0;
      if(UPPER)
      {
        start_y=26;
        y=26;
      }
      else
      {
        start_y=159; //294
         y=174;
      }
    }
  }
  return (csm_result);
}  

extern const int CALL_BUTTON;
/*
int my_keyhook(int key, int m)
{
  void *icsm=FindCSMbyID(CSM_root()->idle_id);
  if ((IsGuiOnTop(((int *)icsm)[DISPLACE_OF_IDLEGUI_ID/4]))&&IsUnlocked()&&(m==KEY_DOWN)&&(!IsScreenSaver()))
     if (key==CALL_BUTTON) 
       {
         sub_on=0;
         DoScreen();
         LockSched();
         char dummy[sizeof(MAIN_CSM)];
         UpdateCSMname();
         MAINCSM_ID=CreateCSM(&MAINCSM.maincsm,dummy,2);
         UnlockSched();
         if(UPPER)
         {
           if(!animate_bg) anime_y=(-26); else anime_y=0;
         if(!dont_do) y=y-126;
         y_b=(-100);
         y_d=(-100);
         y_b_add=(-100);
         y_d_add=(-100);
         y_add=(-100);
         }
         else
         {
           if(!animate_bg) anime_y=320; else anime_y=294;
         if(!dont_do) y=y+120;
         y_b=(294);
         y_d=(294);
         y_b_add=(294);
         y_d_add=(294);
         y_add=(294);
         }
         dont_do=0; 
         main_add=43;
         animate_to_add=0;
         addon=0;
         add_pos=1;
         not_close=1;
         animating();
       }
  
  return 0;
}
*/

void Execute()
{
         sub_on=0;
         DoScreen();
         LockSched();
         char dummy[sizeof(MAIN_CSM)];
         UpdateCSMname();
         MAINCSM_ID=CreateCSM(&MAINCSM.maincsm,dummy,2);
         UnlockSched();
         if(UPPER)
         {
           if(!animate_bg) anime_y=(-26); else anime_y=0;
         if(!dont_do) y=y-126;
         y_b=(-100);
         y_d=(-100);
         y_b_add=(-100);
         y_d_add=(-100);
         y_add=(-100);
         }
         else
         {
           if(!animate_bg) anime_y=320; else anime_y=294;
         if(!dont_do) y=y+120;
         y_b=(294);
         y_d=(294);
         y_b_add=(294);
         y_d_add=(294);
         y_add=(294);
         }
         dont_do=0; 
         main_add=43;
         animate_to_add=0;
         addon=0;
         add_pos=1;
         not_close=1;
         animating();
}

int mode_enter;
int mode;

int my_keyhook(int submsg, int msg)
{
  if (submsg!=CALL_BUTTON) return(0);
  if((submsg==CALL_BUTTON)&&(IsIdleUiOnTop())&&(IsUnlocked())) Execute();
  switch(msg)
  {
  case KEY_DOWN:
    if (mode_enter==2)
    {
      GBS_SendMessage(MMI_CEPID,KEY_UP,CALL_BUTTON);
      return (0);
    }
    mode_enter=0;
    return (2);
  case KEY_UP:
    if (mode==1)mode=0;
    if (mode_enter==0)
    {
      mode_enter=2;
      GBS_SendMessage(MMI_CEPID,KEY_DOWN,CALL_BUTTON);
      return (2);
    }
    if (mode_enter==2)
    {
      mode_enter=0;
      return (0);
    }
    mode_enter=0;
    return (2);      
  case LONG_PRESS:
    mode_enter=1;
    if(mode==0)
    {
      if (IsUnlocked()&&(!MAINCSM_ID)&&(!IsIdleUiOnTop())) Execute();
    }
    mode=1;
    break;
  }
return(2); 
}

int main(void)
{
  LockSched();
  CSM_RAM *icsm=FindCSMbyID(CSM_root()->idle_id);
  memcpy(&icsmd,icsm->constr,sizeof(icsmd));
  old_icsm_onMessage=icsmd.onMessage;
  icsmd.onMessage=MyIDLECSM_onMessage;
  old_icsm_onClose=icsmd.onClose;
  icsmd.onClose=MyIDLECSM_onClose;  
  icsm->constr=&icsmd;  
  
  AddKeybMsgHook((void *)my_keyhook);

  UnlockSched();
  sub_pos=1;
  main_pos=1;
  InitConfig();
  InitFiles();
  if(UPPER)
  {
   start_y=26;
   y=26;
  }
  else
  {
   start_y=159; //159
   y=174;
  }
  inam=0;
//  if((UPPER)&&(set_undo)) {y=y-40; y_d=y_d-40; y_b=y_b-40; y_add=y_add-40; y_d_add=y_d_add-40; y_b_add=y_b_add-40; set_undo=0;}
//  else if(set_undo) {y=y+40; y_d=y_d+40; y_b=y_b+40; y_add=y_add+40; y_d_add=y_d_add+40; y_b_add=y_b_add+40; set_undo=0;}
  return 0;
}
