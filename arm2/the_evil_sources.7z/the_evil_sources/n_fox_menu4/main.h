void SearchIcon(WSHDR *ramed, int w, int show, int main_icon, int mainx, int mainy);
