#include "..\inc\swilib.h"

extern const char path[128];
char temp[128];
char LinkCounters[10];

/*
void InitUnderlinks_count()
{
  int f;
  int fsize;
  FSTATS stat;
  unsigned int ul;
  sprintf(temp, "%slinkcounters.fx", path);
  GetFileStats(temp,&stat,&ul);
  if(stat.size>0)
  {
    f=fopen(temp,A_ReadOnly+A_BIN,P_READ,&ul);
    fsize=stat.size;
    char *p=malloc(fsize);
    p[fread(f,p,fsize,&ul)];
    fclose(f,&ul);
    strcpy(LinkCounters, p);
    LinkCounters[fsize]='\0';
    mfree(p);
  }
}
*/

void InitCount(int number, char *linker, char *temp)
{
  int f;
  int fsize;
  FSTATS stat;
  unsigned int ul;
//  sprintf(temp, "%s%s.fx", path, file);
  GetFileStats(temp,&stat,&ul);
  if(stat.size>0)
  {
    f=fopen(temp,A_ReadOnly+A_BIN,P_READ,&ul);
    fsize=stat.size;
    char *p=malloc(fsize);
    p[fread(f,p,fsize,&ul)];
    fclose(f,&ul);

    char buffer[5];
    sprintf(buffer,"[%d]s", number);
//    char p2[]="||";
    char *s1;
    if((s1=strstr(p,buffer))>0)
    {
      s1+=strlen(buffer);
//      if(strstr(s1,p2)>0)
//      {
        linker[number-1]=s1[7];
//      }
    }
    else
      linker[number-1]=0x30;
    mfree(p);
  } 
}

void InitUnderlinks_count()
{
  char q[128];
  sprintf(q, "%smain.fx", path);
  InitCount(1, LinkCounters, q);
  InitCount(2, LinkCounters, q);
  InitCount(3, LinkCounters, q);
  InitCount(4, LinkCounters, q);
  InitCount(5, LinkCounters, q);
  InitCount(6, LinkCounters, q);
  InitCount(7, LinkCounters, q);
  InitCount(8, LinkCounters, q);
  InitCount(9, LinkCounters, q);
//  ShowMSG(1,(int)LinkCounters);
}

/*//=================initing img paths
extern char anime_bg[128];
extern char bg[128];
extern char cursor[128];
extern char add_list[128];
extern char add_bg[128];
extern char main_addi[128];
extern char main_list[128];
extern char one_bg[128];
extern char two_bg[128];
extern char three_bg[128];
extern char four_bg[128];
extern char five_bg[128];
extern char six_bg[128];
extern char seven_bg[128];
extern char eight_bg[128];
extern char nine_bg[128];
extern char one_list[128];
extern char two_list[128];
extern char three_list[128];
extern char four_list[128];
extern char five_list[128];
extern char six_list[128];
extern char seven_list[128];
extern char eight_list[128];
extern char nine_list[128];
//=================initing img paths*/
//================new init
IMGHDR *anime_bg,*bg,*cursor,*add_list,*add_bg,*main_addi,*main_list,*one_bg,*two_bg,*three_bg,*four_bg,*five_bg,*six_bg,*seven_bg,*eight_bg,*nine_bg,*one_list,*two_list,*three_list,*four_list,*five_list,*six_list,*seven_list,*eight_list,*nine_list;
//=======================

//=================main links
extern char MLINK1[128];
extern char MLINK2[128];
extern char MLINK3[128];
extern char MLINK4[128];
extern char MLINK5[128];
extern char MLINK6[128];
extern char MLINK7[128];
extern char MLINK8[128];
extern char MLINK9[128];
extern char MLINKER[10];
//==========================
extern char ONELINK1[128];
extern char ONELINK2[128];
extern char ONELINK3[128];
extern char ONELINK4[128];
extern char ONELINK5[128];
extern char ONELINK6[128];
extern char ONELINK7[128];
extern char ONELINK8[128];
extern char ONELINK9[128];
extern char ONELINKER[10];
//==========================
extern char TWOLINK1[128];
extern char TWOLINK2[128];
extern char TWOLINK3[128];
extern char TWOLINK4[128];
extern char TWOLINK5[128];
extern char TWOLINK6[128];
extern char TWOLINK7[128];
extern char TWOLINK8[128];
extern char TWOLINK9[128];
extern char TWOLINKER[10];
//==========================
extern char THREELINK1[128];
extern char THREELINK2[128];
extern char THREELINK3[128];
extern char THREELINK4[128];
extern char THREELINK5[128];
extern char THREELINK6[128];
extern char THREELINK7[128];
extern char THREELINK8[128];
extern char THREELINK9[128];
extern char THREELINKER[10];
//==========================
extern char FOURLINK1[128];
extern char FOURLINK2[128];
extern char FOURLINK3[128];
extern char FOURLINK4[128];
extern char FOURLINK5[128];
extern char FOURLINK6[128];
extern char FOURLINK7[128];
extern char FOURLINK8[128];
extern char FOURLINK9[128];
extern char FOURLINKER[10];
//==========================
extern char FIVELINK1[128];
extern char FIVELINK2[128];
extern char FIVELINK3[128];
extern char FIVELINK4[128];
extern char FIVELINK5[128];
extern char FIVELINK6[128];
extern char FIVELINK7[128];
extern char FIVELINK8[128];
extern char FIVELINK9[128];
extern char FIVELINKER[10];
//==========================
extern char SIXLINK1[128];
extern char SIXLINK2[128];
extern char SIXLINK3[128];
extern char SIXLINK4[128];
extern char SIXLINK5[128];
extern char SIXLINK6[128];
extern char SIXLINK7[128];
extern char SIXLINK8[128];
extern char SIXLINK9[128];
extern char SIXLINKER[10];
//==========================
extern char SEVENLINK1[128];
extern char SEVENLINK2[128];
extern char SEVENLINK3[128];
extern char SEVENLINK4[128];
extern char SEVENLINK5[128];
extern char SEVENLINK6[128];
extern char SEVENLINK7[128];
extern char SEVENLINK8[128];
extern char SEVENLINK9[128];
extern char SEVENLINKER[10];
//==========================
extern char EIGHTLINK1[128];
extern char EIGHTLINK2[128];
extern char EIGHTLINK3[128];
extern char EIGHTLINK4[128];
extern char EIGHTLINK5[128];
extern char EIGHTLINK6[128];
extern char EIGHTLINK7[128];
extern char EIGHTLINK8[128];
extern char EIGHTLINK9[128];
extern char EIGHTLINKER[10];
//==========================
extern char NINELINK1[128];
extern char NINELINK2[128];
extern char NINELINK3[128];
extern char NINELINK4[128];
extern char NINELINK5[128];
extern char NINELINK6[128];
extern char NINELINK7[128];
extern char NINELINK8[128];
extern char NINELINK9[128];
extern char NINELINKER[10];
//=================main links
//===========================
extern char ADDLINK1[128];
extern char ADDLINK2[128];
extern char ADDLINK3[128];
extern char ADDLINK4[128];
extern char ADDLINK5[128];
extern char ADDLINK6[128];
extern char ADDLINKER[10];
//================addon links
/* //================================old img load
void InitImgPaths()
{
  sprintf(anime_bg, "%simg\\anime_bg.png", path);
  sprintf(bg, "%simg\\bg.png", path);
  sprintf(cursor, "%simg\\cursor.png", path);
  sprintf(main_addi, "%simg\\main_add.png", path);
  sprintf(main_list, "%simg\\main_list.png", path);
  sprintf(add_list, "%simg\\add_list.png", path);
  sprintf(add_bg, "%simg\\add_bg.png", path);
  sprintf(one_bg, "%simg\\1st_bg.png", path);
  sprintf(one_list, "%simg\\1st_list.png", path);
  sprintf(two_bg, "%simg\\2nd_bg.png", path);
  sprintf(two_list, "%simg\\2nd_list.png", path);
  sprintf(three_bg, "%simg\\3rd_bg.png", path);
  sprintf(three_list, "%simg\\3rd_list.png", path);
  sprintf(four_bg, "%simg\\4th_bg.png", path);
  sprintf(four_list, "%simg\\4th_list.png", path);
  sprintf(five_bg, "%simg\\5th_bg.png", path);
  sprintf(five_list, "%simg\\5th_list.png", path);
  sprintf(six_bg, "%simg\\6th_bg.png", path);
  sprintf(six_list, "%simg\\6th_list.png", path);
  sprintf(seven_bg, "%simg\\7th_bg.png", path);
  sprintf(seven_list, "%simg\\7th_list.png", path);
  sprintf(eight_bg, "%simg\\8th_bg.png", path);
  sprintf(eight_list, "%simg\\8th_list.png", path);
  sprintf(nine_bg, "%simg\\9th_bg.png", path);
  sprintf(nine_list, "%simg\\9th_list.png", path);
}
*/
//=========================new img load
void InitImgPaths()
{
  char z[128];
  sprintf(z, "%simg\\anime_bg.png", path);
  anime_bg=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\bg.png", path);
  bg=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\cursor.png", path);
  cursor=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\main_add.png", path);
  main_addi=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\main_list.png", path);
  main_list=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\add_list.png", path);
  add_list=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\add_bg.png", path);
  add_bg=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\1st_bg.png", path);
  one_bg=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\1st_list.png", path);
  one_list=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\2nd_bg.png", path);
  two_bg=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\2nd_list.png", path);
  two_list=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\3rd_bg.png", path);
  three_bg=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\3rd_list.png", path);
  three_list=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\4th_bg.png", path);
  four_bg=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\4th_list.png", path);
  four_list=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\5th_bg.png", path);
  five_bg=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\5th_list.png", path);
  five_list=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\6th_bg.png", path);
  six_bg=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\6th_list.png", path);
  six_list=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\7th_bg.png", path);
  seven_bg=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\7th_list.png", path);
  seven_list=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\8th_bg.png", path);
  eight_bg=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\8th_list.png", path);
  eight_list=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\9th_bg.png", path);
  nine_bg=CreateIMGHDRFromPngFile(z, 2); 
  sprintf(z, "%simg\\9th_list.png", path);
  nine_list=CreateIMGHDRFromPngFile(z, 2); 
}

void InitLink(char *link, int number, char *linker, char *file)
{
  int f;
  int fsize;
  FSTATS stat;
  unsigned int ul;
  sprintf(temp, "%s%s.fx", path, file);
  GetFileStats(temp,&stat,&ul);
  if(stat.size>0)
  {
    f=fopen(temp,A_ReadOnly+A_BIN,P_READ,&ul);
    fsize=stat.size;
    char *p=malloc(fsize);
    p[fread(f,p,fsize,&ul)];
    fclose(f,&ul);

    char buffer[5];
    sprintf(buffer,"[%d][", number);
    char p2[]="||";
    char *s1,*s2;
    int len;
    if((s1=strstr(p,buffer))>0)
    {
      s1+=strlen(buffer);
      if((s2=strstr(s1,p2))>0)
      {
        len=s2-s1-2;
        strncpy(link,s1+2,len);
        link[len]='\0';
        linker[number]=s1[0];
        mfree(p);
      }
    }
  } 
}

void LoadUnderlinks1()
{
  int count=LinkCounters[0]-48;
  strcpy(ONELINKER, "0000000000");
  if(count>=1) InitLink(ONELINK1, 1, ONELINKER, "one");
  if(count>=2) InitLink(ONELINK2, 2, ONELINKER, "one");
  if(count>=3) InitLink(ONELINK3, 3, ONELINKER, "one");
  if(count>=4) InitLink(ONELINK4, 4, ONELINKER, "one");
  if(count>=5) InitLink(ONELINK5, 5, ONELINKER, "one");
  if(count>=6) InitLink(ONELINK6, 6, ONELINKER, "one");
  if(count>=7) InitLink(ONELINK7, 7, ONELINKER, "one");
  if(count>=8) InitLink(ONELINK8, 8, ONELINKER, "one");
  if(count>=9) InitLink(ONELINK9, 9, ONELINKER, "one");
}

void LoadUnderlinks2()
{
  int count=LinkCounters[1]-48;
  strcpy(TWOLINKER, "0000000000");
  if(count>=1) InitLink(TWOLINK1, 1, TWOLINKER, "two");
  if(count>=2) InitLink(TWOLINK2, 2, TWOLINKER, "two");
  if(count>=3) InitLink(TWOLINK3, 3, TWOLINKER, "two");
  if(count>=4) InitLink(TWOLINK4, 4, TWOLINKER, "two");
  if(count>=5) InitLink(TWOLINK5, 5, TWOLINKER, "two");
  if(count>=6) InitLink(TWOLINK6, 6, TWOLINKER, "two");
  if(count>=7) InitLink(TWOLINK7, 7, TWOLINKER, "two");
  if(count>=8) InitLink(TWOLINK8, 8, TWOLINKER, "two");
  if(count>=9) InitLink(TWOLINK9, 9, TWOLINKER, "two");
}

void LoadUnderlinks3()
{
  int count=LinkCounters[2]-48;
  strcpy(THREELINKER, "0000000000");
  if(count>=1) InitLink(THREELINK1, 1, THREELINKER, "three");
  if(count>=2) InitLink(THREELINK2, 2, THREELINKER, "three");
  if(count>=3) InitLink(THREELINK3, 3, THREELINKER, "three");
  if(count>=4) InitLink(THREELINK4, 4, THREELINKER, "three");
  if(count>=5) InitLink(THREELINK5, 5, THREELINKER, "three");
  if(count>=6) InitLink(THREELINK6, 6, THREELINKER, "three");
  if(count>=7) InitLink(THREELINK7, 7, THREELINKER, "three");
  if(count>=8) InitLink(THREELINK8, 8, THREELINKER, "three");
  if(count>=9) InitLink(THREELINK9, 9, THREELINKER, "three");
}

void LoadUnderlinks4()
{
  int count=LinkCounters[3]-48;
  strcpy(FOURLINKER, "0000000000");
  if(count>=1) InitLink(FOURLINK1, 1, FOURLINKER, "four");
  if(count>=2) InitLink(FOURLINK2, 2, FOURLINKER, "four");
  if(count>=3) InitLink(FOURLINK3, 3, FOURLINKER, "four");
  if(count>=4) InitLink(FOURLINK4, 4, FOURLINKER, "four");
  if(count>=5) InitLink(FOURLINK5, 5, FOURLINKER, "four");
  if(count>=6) InitLink(FOURLINK6, 6, FOURLINKER, "four");
  if(count>=7) InitLink(FOURLINK7, 7, FOURLINKER, "four");
  if(count>=8) InitLink(FOURLINK8, 8, FOURLINKER, "four");
  if(count>=9) InitLink(FOURLINK9, 9, FOURLINKER, "four");
}

void LoadUnderlinks5()
{
  int count=LinkCounters[4]-48;
  strcpy(FIVELINKER, "0000000000");
  if(count>=1) InitLink(FIVELINK1, 1, FIVELINKER, "five");
  if(count>=2) InitLink(FIVELINK2, 2, FIVELINKER, "five");
  if(count>=3) InitLink(FIVELINK3, 3, FIVELINKER, "five");
  if(count>=4) InitLink(FIVELINK4, 4, FIVELINKER, "five");
  if(count>=5) InitLink(FIVELINK5, 5, FIVELINKER, "five");
  if(count>=6) InitLink(FIVELINK6, 6, FIVELINKER, "five");
  if(count>=7) InitLink(FIVELINK7, 7, FIVELINKER, "five");
  if(count>=8) InitLink(FIVELINK8, 8, FIVELINKER, "five");
  if(count>=9) InitLink(FIVELINK9, 9, FIVELINKER, "five");
}

void LoadUnderlinks6()
{
  int count=LinkCounters[5]-48;
  strcpy(SIXLINKER, "0000000000");
  if(count>=1) InitLink(SIXLINK1, 1, SIXLINKER, "six");
  if(count>=2) InitLink(SIXLINK2, 2, SIXLINKER, "six");
  if(count>=3) InitLink(SIXLINK3, 3, SIXLINKER, "six");
  if(count>=4) InitLink(SIXLINK4, 4, SIXLINKER, "six");
  if(count>=5) InitLink(SIXLINK5, 5, SIXLINKER, "six");
  if(count>=6) InitLink(SIXLINK6, 6, SIXLINKER, "six");
  if(count>=7) InitLink(SIXLINK7, 7, SIXLINKER, "six");
  if(count>=8) InitLink(SIXLINK8, 8, SIXLINKER, "six");
  if(count>=9) InitLink(SIXLINK9, 9, SIXLINKER, "six");
}

void LoadUnderlinks7()
{
  int count=LinkCounters[6]-48;
  strcpy(SEVENLINKER, "0000000000");
  if(count>=1) InitLink(SEVENLINK1, 1, SEVENLINKER, "seven");
  if(count>=2) InitLink(SEVENLINK2, 2, SEVENLINKER, "seven");
  if(count>=3) InitLink(SEVENLINK3, 3, SEVENLINKER, "seven");
  if(count>=4) InitLink(SEVENLINK4, 4, SEVENLINKER, "seven");
  if(count>=5) InitLink(SEVENLINK5, 5, SEVENLINKER, "seven");
  if(count>=6) InitLink(SEVENLINK6, 6, SEVENLINKER, "seven");
  if(count>=7) InitLink(SEVENLINK7, 7, SEVENLINKER, "seven");
  if(count>=8) InitLink(SEVENLINK8, 8, SEVENLINKER, "seven");
  if(count>=9) InitLink(SEVENLINK9, 9, SEVENLINKER, "seven");
}

void LoadUnderlinks8()
{
  int count=LinkCounters[7]-48;
  strcpy(EIGHTLINKER, "0000000000");
  if(count>=1) InitLink(EIGHTLINK1, 1, EIGHTLINKER, "eight");
  if(count>=2) InitLink(EIGHTLINK2, 2, EIGHTLINKER, "eight");
  if(count>=3) InitLink(EIGHTLINK3, 3, EIGHTLINKER, "eight");
  if(count>=4) InitLink(EIGHTLINK4, 4, EIGHTLINKER, "eight");
  if(count>=5) InitLink(EIGHTLINK5, 5, EIGHTLINKER, "eight");
  if(count>=6) InitLink(EIGHTLINK6, 6, EIGHTLINKER, "eight");
  if(count>=7) InitLink(EIGHTLINK7, 7, EIGHTLINKER, "eight");
  if(count>=8) InitLink(EIGHTLINK8, 8, EIGHTLINKER, "eight");
  if(count>=9) InitLink(EIGHTLINK9, 9, EIGHTLINKER, "eight");
}

void LoadUnderlinks9()
{
  int count=LinkCounters[8]-48;
  strcpy(NINELINKER, "0000000000");
  if(count>=1) InitLink(NINELINK1, 1, NINELINKER, "nine");
  if(count>=2) InitLink(NINELINK2, 2, NINELINKER, "nine");
  if(count>=3) InitLink(NINELINK3, 3, NINELINKER, "nine");
  if(count>=4) InitLink(NINELINK4, 4, NINELINKER, "nine");
  if(count>=5) InitLink(NINELINK5, 5, NINELINKER, "nine");
  if(count>=6) InitLink(NINELINK6, 6, NINELINKER, "nine");
  if(count>=7) InitLink(NINELINK7, 7, NINELINKER, "nine");
  if(count>=8) InitLink(NINELINK8, 8, NINELINKER, "nine");
  if(count>=9) InitLink(NINELINK9, 9, NINELINKER, "nine");
}

void LoadAddon()
{
  strcpy(ADDLINKER, "0000000");
  InitLink(ADDLINK1, 1, ADDLINKER, "add");
  InitLink(ADDLINK2, 2, ADDLINKER, "add");
  InitLink(ADDLINK3, 3, ADDLINKER, "add");
  InitLink(ADDLINK4, 4, ADDLINKER, "add");
  InitLink(ADDLINK5, 5, ADDLINKER, "add");
  InitLink(ADDLINK6, 6, ADDLINKER, "add");
}

void InitFiles()
{
  InitUnderlinks_count();
  InitImgPaths();
  strcpy(MLINKER, "0000000000");
  if(LinkCounters[0]=='0') InitLink(MLINK1, 1, MLINKER, "main"); else LoadUnderlinks1();
  if(LinkCounters[1]=='0') InitLink(MLINK2, 2, MLINKER, "main"); else LoadUnderlinks2();
  if(LinkCounters[2]=='0') InitLink(MLINK3, 3, MLINKER, "main"); else LoadUnderlinks3();
  if(LinkCounters[3]=='0') InitLink(MLINK4, 4, MLINKER, "main"); else LoadUnderlinks4();
  if(LinkCounters[4]=='0') InitLink(MLINK5, 5, MLINKER, "main"); else LoadUnderlinks5();
  if(LinkCounters[5]=='0') InitLink(MLINK6, 6, MLINKER, "main"); else LoadUnderlinks6();
  if(LinkCounters[6]=='0') InitLink(MLINK7, 7, MLINKER, "main"); else LoadUnderlinks7();
  if(LinkCounters[7]=='0') InitLink(MLINK8, 8, MLINKER, "main"); else LoadUnderlinks8();
  if(LinkCounters[8]=='0') InitLink(MLINK9, 9, MLINKER, "main"); else LoadUnderlinks9();
  LoadAddon();
//  ShowMSG(1,(int)"FoxMENU 0.3 (c)Evilfox");
}
