#ifndef _IDLELINKS_H_
  #define _IDLELINKS_H_

extern const unsigned int x1,x2,y1,y2,x3,y3,x4,y4,x5,y5,x6,y6,x7,x8,x9,x10,x11,x12,x13,x14,x15,y7,y8,y9,y10,y11,y12,y13,y14,y15;
extern const char pic1[128],pic2[128],pic3[128],pic4[128],pic5[128],pic6[128],pic7[128],pic8[128],pic9[128],pic10[128],pic11[128],pic12[128],pic13[128],pic14[128],pic15[128],
                  file1[128],file2[128],file3[128],file4[128],file5[128],file6[128],file7[128],file8[128],file9[128],file10[128],file11[128],file12[128],file13[128],file14[128],file15[128];

extern const char chpic[128];
extern const int vybor,count,type1,type2,type3,type4,type5,type6,type7,type8,type9,type10,type11,type12,type13,type14,type15;

extern const char cl[4],frcol[4];

extern const unsigned int CALL_BTN;
extern const int active;
extern const unsigned int KBD_STATE;

#endif
