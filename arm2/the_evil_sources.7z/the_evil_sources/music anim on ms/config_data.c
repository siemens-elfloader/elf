#include "..\inc\cfg_items.h"
//������������
__root const CFG_HDR cfghdr0={CFG_CBOX,"Enable hello message",0,2};
__root const int ENA_HELLO_MSG=1;
__root const CFG_CBOX_ITEM cfgcbox0[2]={"No","Yes"};

__root const CFG_HDR cfghdr0a = {CFG_STR_WIN1251, "menu file path", 0, 127};
__root const char path[128] = "4:\\Zbin\\music_anim\\";

__root const CFG_HDR cfghdr1={CFG_COORDINATES,"position",0,0};
__root const unsigned int IDLEICON_X=0; //2
__root const unsigned int IDLEICON_Y=27;  //62

__root const CFG_HDR cfghdr2 = {CFG_UINT, "speed (1/10sec)", 0, 50};
__root const unsigned int speed = 1;
