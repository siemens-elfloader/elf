#include "..\inc\swilib.h"
#include "conf_loader.h"

extern const char path[128];
IMGHDR *first,*second,*third,*four,*five,*six,*seven,*eight,*nine,*ten,*eleven,*tvelwe;

void InitImgPaths()
{
  char z[128];
  sprintf(z, "%s01.png", path);
  first=CreateIMGHDRFromPngFile(z, 2);
  sprintf(z, "%s02.png", path);
  second=CreateIMGHDRFromPngFile(z, 2);
  sprintf(z, "%s03.png", path);
  third=CreateIMGHDRFromPngFile(z, 2);
  sprintf(z, "%s04.png", path);
  four=CreateIMGHDRFromPngFile(z, 2);
  sprintf(z, "%s05.png", path);
  five=CreateIMGHDRFromPngFile(z, 2);
  sprintf(z, "%s06.png", path);
  six=CreateIMGHDRFromPngFile(z, 2);
  sprintf(z, "%s07.png", path);
  seven=CreateIMGHDRFromPngFile(z, 2);
  sprintf(z, "%s08.png", path);
  eight=CreateIMGHDRFromPngFile(z, 2);
  sprintf(z, "%s09.png", path);
  nine=CreateIMGHDRFromPngFile(z, 2);
  sprintf(z, "%s10.png", path);
  ten=CreateIMGHDRFromPngFile(z, 2);
  sprintf(z, "%s11.png", path);
  eleven=CreateIMGHDRFromPngFile(z, 2);
  sprintf(z, "%s12.png", path);
  tvelwe=CreateIMGHDRFromPngFile(z, 2);
}

#pragma swi_number=0x1F8
__swi __arm unsigned int _GetPlayStatus(void);


GBSTMR musictmr;
extern const unsigned int IDLEICON_X;
extern const unsigned int IDLEICON_Y;
extern const unsigned int speed;
int set;
int picto=1;
int setos;

static DrwImage(int x, int y, IMGHDR *img, char *pen, char *brush)
{
  RECT rc;
  DRWOBJ drwobj;
  StoreXYWHtoRECT(&rc,x,y,img->w,img->h);
  SetPropTo_Obj5(&drwobj,&rc,0,img);
  SetColor(&drwobj,pen,brush);
  DrawObject(&drwobj);
}

void DrawIT()
{
  if(picto==1) DrwImage(IDLEICON_X,IDLEICON_Y, first,0,0);
  if(picto==2) DrwImage(IDLEICON_X,IDLEICON_Y, second,0,0);
  if(picto==3) DrwImage(IDLEICON_X,IDLEICON_Y, third,0,0);
  if(picto==4) DrwImage(IDLEICON_X,IDLEICON_Y, four,0,0);
  if(picto==5) DrwImage(IDLEICON_X,IDLEICON_Y, five,0,0);
  if(picto==6) DrwImage(IDLEICON_X,IDLEICON_Y, six,0,0);
  if(picto==7) DrwImage(IDLEICON_X,IDLEICON_Y, seven,0,0);
  if(picto==8) DrwImage(IDLEICON_X,IDLEICON_Y, eight,0,0);
  if(picto==9) DrwImage(IDLEICON_X,IDLEICON_Y, nine,0,0);
  if(picto==10) DrwImage(IDLEICON_X,IDLEICON_Y, ten,0,0);
  if(picto==11) DrwImage(IDLEICON_X,IDLEICON_Y, eleven,0,0);
  if(picto==12) DrwImage(IDLEICON_X,IDLEICON_Y, tvelwe,0,0);
}
void checko()
{
  setos=1;
  if((IsIdleUiOnTop())&&(_GetPlayStatus()==2))
  {
    void *canvasdata = BuildCanvas();
 //   DrawCanvas(canvasdata,IDLEICON_X-Get_WS_width(ws,11),IDLEICON_Y,130,162+GetFontYSIZE(11)+3,1);
    DrawCanvas(canvasdata,IDLEICON_X,IDLEICON_Y,IDLEICON_X+90,IDLEICON_Y+35,1);
//    DrawImg(IDLEICON_X, IDLEICON_Y, picto);
    DrawIT();
    picto++;
    set=1;
    if (picto==13) picto=1; 
    GBS_StartTimerProc(&musictmr, speed*22, checko);
  }
  else
  if((set)&&(IsIdleUiOnTop())) {void *canvasdata = BuildCanvas(); DrawCanvas(canvasdata,IDLEICON_X,IDLEICON_Y,IDLEICON_X+90,IDLEICON_Y+35,1); set=0; GBS_StartTimerProc(&musictmr, speed*22, checko);}
  else set=0;
}


const int minus11=-11;

typedef struct
{
  CSM_RAM csm;
}MAIN_CSM;

CSM_RAM *under_idle;

extern void kill_data(void *p, void (*func_p)(void *));

#pragma inline=forced

int toupper(int c)
{
  if ((c>='a')&&(c<='z')) c+='A'-'a';
  return(c);
}

int strcmp_nocase(const char *s1,const char *s2)
{
  int i;
  int c;
  while(!(i=(c=toupper(*s1++))-toupper(*s2++))) if (!c) break;
  return(i);
}

//int picto;
//extern const unsigned int start_picto;

int maincsm_onmessage(CSM_RAM* data,GBS_MSG* msg)
{
  if(msg->msg == MSG_RECONFIGURE_REQ) 
  {
    extern const char *successed_config_filename;
    if (strcmp_nocase(successed_config_filename,(char *)msg->data0)==0)
    {
      ShowMSG(1,(int)"music anim config updated!");
      InitConfig();
      InitImgPaths();
//      picto=start_picto;
    }
  }
  if((IsIdleUiOnTop())&&(!setos))
  {
    checko();
  }
  else
    setos=0;
  return (1);  
}

static void maincsm_oncreate(CSM_RAM *data)
{

}

static void Killer(void)
{
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}


static void maincsm_onclose(CSM_RAM *csm)
{
  GBS_DelTimer(&musictmr);
  SUBPROC((void *)Killer);
}

static unsigned short maincsm_name_body[140];

static const struct
{
  CSM_DESC maincsm;
  WSHDR maincsm_name;
}MAINCSM =
{
  {
  maincsm_onmessage,
  maincsm_oncreate,
#ifdef NEWSGOLD
  0,
  0,
  0,
  0,
#endif
  maincsm_onclose,
  sizeof(MAIN_CSM),
  1,
  &minus11
  },
  {
    maincsm_name_body,
    NAMECSM_MAGIC1,
    NAMECSM_MAGIC2,
    0x0,
    139
  }
};

static void UpdateCSMname(void)
{
  wsprintf((WSHDR *)(&MAINCSM.maincsm_name),"MusicAnim (c)Evilfox");
}



void Engade()
{
  InitImgPaths();
  checko();
}

int main()
{
  if(ScreenW()<200)
  {
    ShowMSG(1,(int)"wrong display");
  }
  else
  {
  InitConfig();
  CSM_RAM *save_cmpc;
  char dummy[sizeof(MAIN_CSM)];
  UpdateCSMname();  
  LockSched();
  save_cmpc=CSM_root()->csm_q->current_msg_processing_csm;
  CSM_root()->csm_q->current_msg_processing_csm=CSM_root()->csm_q->csm.first;
  CreateCSM(&MAINCSM.maincsm,dummy,0);
  CSM_root()->csm_q->current_msg_processing_csm=save_cmpc;
  
  
  UnlockSched();
  extern const int ENA_HELLO_MSG;
  if (ENA_HELLO_MSG) ShowMSG(1,(int)"Music anim on ms"); 
//  picto=start_picto;
  
  Engade();
  }
  return 0;
}
