#ifndef _MANAGE_CL_H_
  #define _MANAGE_CL_H_

int CreateManageCLMenu(void);
int CreateAddContactGrpDialog(CLIST *cl_sel);
int CreatePrivateStatusMenu(void);
void SetPrivateStatus(int status);

#endif
