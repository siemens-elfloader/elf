void SendXtask(char *sended);

