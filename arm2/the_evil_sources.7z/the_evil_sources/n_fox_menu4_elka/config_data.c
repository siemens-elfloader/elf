#include "..\inc\cfg_items.h"
//������������
__root const CFG_HDR cfghdr0 = {CFG_STR_WIN1251, "menu file path", 0, 127};
__root const char path[128] = "4:\\Zbin\\fox_menu\\";

__root const CFG_HDR cfghdr1={CFG_UINT,"Activation key",0,99};
__root const int CALL_BUTTON=1;
