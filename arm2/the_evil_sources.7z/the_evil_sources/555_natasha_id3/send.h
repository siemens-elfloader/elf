void send_message(char *sended);

