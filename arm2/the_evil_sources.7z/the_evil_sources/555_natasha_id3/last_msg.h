void lastmsg_menu(EDCHAT_STRUCT *ed_struct);



