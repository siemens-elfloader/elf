#include "..\inc\swilib.h"

const char ipc_my_name[]="SENDER";
const char ipc_send_name[]="RECIEVER";

IPC_REQ tmr_gipc2;

void main()
{
  tmr_gipc2.name_to=ipc_send_name;
  tmr_gipc2.name_from=ipc_my_name;
  tmr_gipc2.data="HELLO WORLD";
  GBS_SendMessage(MMI_CEPID,MSG_IPC,50,&tmr_gipc2);
}
