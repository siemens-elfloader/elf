#include "..\inc\swilib.h"
//#include "..\inc\cfg_items.h"
//#include "conf_loader.h"
//#include "IdleLinks.h"

int x=18;
int y=18;

extern unsigned long  strtoul (const char *nptr,char **endptr,int base);

CSM_DESC icsmd;
int MAINCSM_ID;;

int (*old_icsm_onMessage)(CSM_RAM*,GBS_MSG*);
void (*old_icsm_onClose)(CSM_RAM*);

unsigned short maincsm_name_body[140];
const int minus11=-11;

typedef struct
{
  CSM_RAM csm;
  int gui_id;
}MAIN_CSM;

typedef struct
{
  GUI gui;
  WSHDR *ws1;
  WSHDR *ws2;
  int i1;
}MAIN_GUI;

IMGHDR screen={0,0,8,""};

void DrwImg2(IMGHDR *img, int x, int y, char *pen, char *brush)
{
  RECT rc;
  DRWOBJ drwobj;
  StoreXYWHtoRECT(&rc,x,y,img->w,img->h);
  SetPropTo_Obj5(&drwobj,&rc,0,img);
  SetColor(&drwobj,pen,brush);
  DrawObject(&drwobj);
}

void DoScreen()
{
    int ScrH=ScreenH();
    int ScrW=ScreenW();
    char *ms=RamScreenBuffer();
    screen.w=ScrW;
    screen.h=ScrH;
    screen.bitmap=malloc(ScrW*ScrH*2);
    memcpy(screen.bitmap, ms, ScrW*ScrH*2);
}

void RunSoft(char *path)
{
  WSHDR *elfname=AllocWS(256);
  wsprintf(elfname, path);
  ExecuteFile(elfname,NULL,NULL);
  FreeWS(elfname);
}

void RunEntry(char *entry)
{
  typedef void (*voidfunc)(); 
  unsigned int addr=strtoul( entry, 0, 16 );
  voidfunc pp=(voidfunc)addr;
  SUBPROC((void*)pp);
}

int battery;

void ShowBattery()
{
  DrawImg(x-68,y-36,(int)"0:\\zbin\\miosd\\img9.png");
  battery = *RamCap();
  WSHDR *ws=AllocWS(64);
  wsprintf(ws,"Capacity:%d%", battery);
  DrawString(ws,x-65,y-33,x-64+Get_WS_width(ws,11),y-32+GetFontYSIZE(11),11,0,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
  FreeWS(ws);
}

void DrawData(int x1, int y1, char *the_txt)
{
  WSHDR *ws=AllocWS(64);
  wsprintf(ws, the_txt);
  DrawString(ws,x1,y1,x1+Get_WS_width(ws,11)+1,y1+GetFontYSIZE(11),11,0,GetPaletteAdrByColorIndex(1),GetPaletteAdrByColorIndex(0));
  FreeWS(ws);
}

void ClockDraw()
{
    WSHDR *ws=AllocWS(64);
    TTime time;
    GetDateTime(NULL, &time);
    wsprintf(ws, "%02d:%02d:%02d", time.hour, time.min, time.sec);  
    void *canvasdata = BuildCanvas();
    DrawCanvas(canvasdata,126-Get_WS_width(ws,11),162,130,162+GetFontYSIZE(11)+3,1);
    DrawString(ws,128-Get_WS_width(ws,11),162,130,162+GetFontYSIZE(11)+3,11,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
    FreeWS(ws);
}

GBSTMR min_ref;

void refresher()
{
  DirectRedrawGUI();
}

void OnRedraw(MAIN_GUI *data) // OnRedraw
{
  GBS_DelTimer(&min_ref);
  DrwImg2(&screen, 0, 0, NULL, NULL);
  DrawImg(20,20,(int)"0:\\zbin\\img\\1063.PNG");
  DrawImg(10,70,(int)"0:\\zbin\\ms_control\\naticq.png");
  DrawImg(30,120,(int)"0:\\zbin\\ms_control\\ms_opera.png");
  DrawImg(x,y,(int)"0:\\zbin\\ms_control\\cursor.png");
  if ((x>24)&&(x<42)&&(y>24)&&(y<48)) DrawData(x+11, y+19, "FileSystem");
  if ((x>10)&&(x<32)&&(y>70)&&(y<98)) DrawData(x+11, y+19, "Naticq");
  if ((x>114)&&(x<128)&&(y>136)&&(y<158)) ShowBattery();
  ClockDraw();
  if ((x>30)&&(x<52)&&(y>120)&&(y<148)) DrawData(x+11, y+19, "Ballet Mini");
  GBS_StartTimerProc(&min_ref, 216, refresher);
}

void onCreate(MAIN_GUI *data, void *(*malloc_adr)(int)) //Create
{
  // ��� ����� ������� ����������
  data->gui.state=1;
}

void onClose(MAIN_GUI *data, void (*mfree_adr)(void *)) //Close
{
  // ��� ����� ���������� ���������� ������
  data->gui.state=0;
  mfree(screen.bitmap);
}

void onFocus(MAIN_GUI *data, void *(*malloc_adr)(int), void (*mfree_adr)(void *))//Focus
{
  data->gui.state=2;
}

void onUnfocus(MAIN_GUI *data, void (*mfree_adr)(void *)) //Unfocus
{
  if (data->gui.state!=2) return;
  data->gui.state=1;
  CloseCSM(MAINCSM_ID);
}

int OnKey(MAIN_GUI *data, GUI_MSG *msg) //OnKey
{ 
  if ((msg->gbsmsg->msg==KEY_DOWN)||(msg->gbsmsg->msg==LONG_PRESS))
  {          
    switch(msg->gbsmsg->submess)
    {
    case ENTER_BUTTON:
 //     if ((x>114)&&(x<128)&&(y>136)&&(y<158)) ShowBattery();
      if ((x>24)&&(x<42)&&(y>24)&&(y<48)) RunEntry("A032DFBB");
      if ((x>10)&&(x<32)&&(y>70)&&(y<98)) RunSoft("0:\\zbin\\naticq\\naticq.elf");
      if ((x>30)&&(x<52)&&(y>120)&&(y<148)) RunSoft("0:\\zbin\\balletmini\\balletmini.elf");
      break;
    case LEFT_BUTTON:
      x=x-4;
      if (x<2) x=x+4;
      DirectRedrawGUI();  
      break;
    case RIGHT_BUTTON:
      x=x+4;
      if (x>130) x=x-4;
      DirectRedrawGUI();  
      break;
    case UP_BUTTON:
      y=y-4;
      if (y<18) y=y+4;
      DirectRedrawGUI();  
      break;
    case DOWN_BUTTON:
      y=y+4;
      if (y>156) y=y-4;
      DirectRedrawGUI();  
      break;
    case RIGHT_SOFT:
      return(1);
    }
  }
  return(0);
}

int method8(void){return(0);}

int method9(void){return(0);}

extern void kill_data(void *p,void (*func_p)(void *));
void ElfKiller(void)
{
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}

// ������ � ��������, ����� ���� �� ����������, ����� ����� ��������
const void * const gui_methods[11]={
  (void *)OnRedraw,	//Redraw
  (void *)onCreate,	//Create
  (void *)onClose,	//Close
  (void *)onFocus,	//Focus
  (void *)onUnfocus,	//Unfocus
  (void *)OnKey,	//OnKey
  0,
  (void *)kill_data,	//Destroy
  (void *)method8,
  (void *)method9,
  0
};

// ������ ��� ��������� GUI
const RECT Canvas={0,0,0,0};

// ���������� ��� �������� �������� CSM. � ������ �������
// �������� GUI, ��� ID ������������ � MAINGUI_ID
// �� ������ ������ - ����� ����������� ;)

#pragma inline
void patch_rect(const RECT*rcc,int x,int y, int x2, int y2)
{
  RECT *rc=(RECT *)rcc;
  rc->x=x;
  rc->y=y;
  rc->x2=x2;
  rc->y2=y2;
}

void maincsm_oncreate(CSM_RAM *data)
{
  MAIN_GUI *main_gui=malloc(sizeof(MAIN_GUI));
  MAIN_CSM*csm=(MAIN_CSM*)data;
  zeromem(main_gui,sizeof(MAIN_GUI));
  main_gui->gui.canvas=(void *)(&Canvas);
  //main_gui->gui.flag30=2;
  main_gui->gui.methods=(void *)gui_methods;
  main_gui->gui.item_ll.data_mfree=(void (*)(void *))mfree_adr();
  patch_rect((RECT*)&Canvas,0,YDISP,ScreenW()-1,ScreenH()-1);
  csm->csm.state=0;
  csm->csm.unk1=0;
  csm->gui_id=CreateGUI(main_gui);
}

// ���������� ��� �������� �������� CSM. ��� � ���������� ������
void maincsm_onclose(CSM_RAM *csm)
{
  //SUBPROC((void *)ElfKiller);
}

// ���������� ������� �������� CSM
int maincsm_onmessage(CSM_RAM *data, GBS_MSG *msg)
{
  MAIN_CSM *csm=(MAIN_CSM*)data;
   if ((msg->msg==MSG_GUI_DESTROYED)&&((int)msg->data0==csm->gui_id))
  {
    csm->csm.state=-3;
  } 
  return(1); 
}

// ������������� ��������� MAINCSM
const struct
{
  CSM_DESC maincsm;
  WSHDR maincsm_name;
}MAINCSM =
{
  {
  maincsm_onmessage,
  maincsm_oncreate,
#ifdef NEWSGOLD
  0,
  0,
  0,
  0,
#endif
  maincsm_onclose,
  sizeof(MAIN_CSM),
  1,
  &minus11
  },
  {
    maincsm_name_body,
    NAMECSM_MAGIC1,
    NAMECSM_MAGIC2,
    0x0,
    139
  }
};

// �������, ������� ������������� �������� ����� CSM ��� X-Task.
void UpdateCSMname(void)
{
  wsprintf((WSHDR *)(&MAINCSM.maincsm_name),"MS_control");
}


void MyIDLECSM_onClose(CSM_RAM *data)
{
  extern void seqkill(void *data, void(*next_in_seq)(CSM_RAM *), void *data_to_kill, void *seqkiller);
  extern void *ELF_BEGIN;
  seqkill(data,old_icsm_onClose,&ELF_BEGIN,SEQKILLER_ADR());
}

#pragma inline=forced
int toupper(int c)
{
  if ((c>='a')&&(c<='z')) c+='A'-'a';
  return(c);
}
#pragma inline
int strcmp_nocase(const char *s1,const char *s2)
{
  int i;
  int c;
  while(!(i=(c=toupper(*s1++))-toupper(*s2++))) if (!c) break;
  return(i);
}

int MyIDLECSM_onMessage(CSM_RAM* data, GBS_MSG* msg)
{
  int csm_result;
  csm_result=old_icsm_onMessage(data,msg);

  void *icsm=FindCSMbyID(CSM_root()->idle_id);
  if ((IsGuiOnTop(((int *)icsm)[DISPLACE_OF_IDLEGUI_ID/4]))&&(!IsScreenSaver()))
  {
    DrawImg(20,20,(int)"0:\\zbin\\img\\1063.PNG");
    DrawImg(10,70,(int)"0:\\zbin\\ms_control\\naticq.png");
    DrawImg(30,120,(int)"0:\\zbin\\ms_control\\ms_opera.png");
  }
  
  return(csm_result);
}  

int my_keyhook(int key, int m)
{
  void *icsm=FindCSMbyID(CSM_root()->idle_id);
  if ((IsGuiOnTop(((int *)icsm)[DISPLACE_OF_IDLEGUI_ID/4]))&&IsUnlocked()&&(m==KEY_DOWN)&&(!IsScreenSaver()))
     if (key==ENTER_BUTTON) 
       {
         DoScreen();
         LockSched();
         char dummy[sizeof(MAIN_CSM)];
         UpdateCSMname();
         MAINCSM_ID=CreateCSM(&MAINCSM.maincsm,dummy,2);
         UnlockSched();
       }
  
  return 0;
}

// �������� ���������. ��� ������ �������� ���������� ��� ������ �����.
int main(void)
{
  LockSched();
  CSM_RAM *icsm=FindCSMbyID(CSM_root()->idle_id);
  memcpy(&icsmd,icsm->constr,sizeof(icsmd));
  old_icsm_onMessage=icsmd.onMessage;
  icsmd.onMessage=MyIDLECSM_onMessage;
  old_icsm_onClose=icsmd.onClose;
  icsmd.onClose=MyIDLECSM_onClose;  
  icsm->constr=&icsmd;  
  
  AddKeybMsgHook((void *)my_keyhook);

  UnlockSched();
  
  return 0;
}
