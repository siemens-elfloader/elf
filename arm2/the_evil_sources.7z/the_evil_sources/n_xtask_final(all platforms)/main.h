typedef struct
{
  void *next;
  int number;
  WSHDR *name;
  void *p;
  int is_daemon;
  char icon_path[64];
} NAMELIST;




