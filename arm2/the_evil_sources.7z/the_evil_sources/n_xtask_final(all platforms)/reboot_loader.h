void load_reboot_list();
