#include "..\inc\cfg_items.h"
//������������
__root const CFG_HDR cfghdr0 = {CFG_STR_WIN1251, "menu file path", 0, 127};
__root const char path[128] = "4:\\Zbin\\fox_menu\\";

__root const CFG_HDR cfghdr1={CFG_UINT,"Activation key",0,99};
__root const int CALL_BUTTON=1;

__root const CFG_HDR cfghdr2={CFG_CBOX,"Use logo img",0,2};
__root const int use_add_m=1;
__root const CFG_CBOX_ITEM cfgcbox2[2]={"No","Yes"};

__root const CFG_HDR cfghdr3={CFG_CBOX,"Animate/open From",0,2};
__root const int UPPER=1;
__root const CFG_CBOX_ITEM cfgcbox3[2]={"Down","Up"};

__root const CFG_HDR cfghdr4={CFG_CBOX,"Animate bg open",0,2};
__root const int animate_bg=1;
__root const CFG_CBOX_ITEM cfgcbox4[2]={"Animate","Dont animate"};
/*
__root const CFG_HDR cfghdr4={CFG_CBOX,"Use animation",0,2};
__root const int use_anim=1;
__root const CFG_CBOX_ITEM cfgcbox4[2]={"No","Yes"};
*/
