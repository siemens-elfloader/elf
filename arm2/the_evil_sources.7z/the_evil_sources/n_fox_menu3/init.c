#include "..\inc\swilib.h"

extern const char path[128];
char temp[128];
char LinkCounters[10];

void InitUnderlinks_count()
{
  int f;
  int fsize;
  FSTATS stat;
  unsigned int ul;
  sprintf(temp, "%slinkcounters.fx", path);
  GetFileStats(temp,&stat,&ul);
  if(stat.size>0)
  {
    f=fopen(temp,A_ReadOnly+A_BIN,P_READ,&ul);
    fsize=stat.size;
    char *p=malloc(fsize);
    p[fread(f,p,fsize,&ul)];
    fclose(f,&ul);
    strcpy(LinkCounters, p);
    LinkCounters[fsize]='\0';
    mfree(p);
  }
}

//=================initing img paths
extern char anime_bg[128];
extern char bg[128];
extern char cursor[128];
extern char main_addi[128];
extern char main_list[128];
extern char one_bg[128];
extern char two_bg[128];
extern char three_bg[128];
extern char four_bg[128];
extern char five_bg[128];
extern char six_bg[128];
extern char seven_bg[128];
extern char eight_bg[128];
extern char nine_bg[128];
extern char one_list[128];
extern char two_list[128];
extern char three_list[128];
extern char four_list[128];
extern char five_list[128];
extern char six_list[128];
extern char seven_list[128];
extern char eight_list[128];
extern char nine_list[128];
//=================initing img paths

//=================main links
extern char MLINK1[128];
extern char MLINK2[128];
extern char MLINK3[128];
extern char MLINK4[128];
extern char MLINK5[128];
extern char MLINK6[128];
extern char MLINK7[128];
extern char MLINK8[128];
extern char MLINKER[10];
//=================main links

void InitImgPaths()
{
  sprintf(anime_bg, "%simg\\anime_bg.png", path);
  sprintf(bg, "%simg\\bg.png", path);
  sprintf(cursor, "%simg\\cursor.png", path);
  sprintf(main_addi, "%simg\\main_add.png", path);
  sprintf(main_list, "%simg\\main_list.png", path);
  sprintf(one_bg, "%simg\\1st_bg.png", path);
  sprintf(one_list, "%simg\\1st_list.png", path);
  sprintf(two_bg, "%simg\\2nd_bg.png", path);
  sprintf(two_list, "%simg\\2nd_list.png", path);
  sprintf(three_bg, "%simg\\3rd_bg.png", path);
  sprintf(three_list, "%simg\\3rd_list.png", path);
  sprintf(four_bg, "%simg\\4th_bg.png", path);
  sprintf(four_list, "%simg\\4th_list.png", path);
  sprintf(five_bg, "%simg\\5th_bg.png", path);
  sprintf(five_list, "%simg\\5th_list.png", path);
  sprintf(six_bg, "%simg\\6th_bg.png", path);
  sprintf(six_list, "%simg\\6th_list.png", path);
  sprintf(seven_bg, "%simg\\7th_bg.png", path);
  sprintf(seven_list, "%simg\\7th_list.png", path);
  sprintf(eight_bg, "%simg\\8th_bg.png", path);
  sprintf(eight_list, "%simg\\8th_list.png", path);
  sprintf(nine_bg, "%simg\\9th_bg.png", path);
  sprintf(nine_list, "%simg\\9th_list.png", path);
}

void InitMainLink(char *link, int number)
{
  char buffer[4];
  sprintf(buffer,"[%d]", number);
  char p2[]="||";
  char *s,*s1,*s2;
  int len;
  if((s1=strstr(p,buffer))>0)
  {
    s1+=strlen(buffer);
    if((s2=strstr(s1,p2))>0)
    {
      len=s2-s1-3;
      s=malloc(len+1);
      strncpy(s,s1+3,len);
      s[len]='\0';
      MLINKER[number]=s1[1];
      mfree(s);
    }
  }
  mfree(p);
}
/*
void SearchIcon(WSHDR *ramed, int w, int show)
{
  char buffer[256];
  //ws_2str(ramed, buffer, 64);
  convWS_to_ANSI(ramed, buffer);
  if(strstr(buffer, "NATICQ")>0) strcpy(buffer, "NATICQ");
  if(strstr(buffer, "SieJC")>0) strcpy(buffer, "SieJC");
  if(strstr(buffer, "MC:")>0) strcpy(buffer, "MC");
  if(strstr(buffer, "BM:")>0) strcpy(buffer, "BM:");
  char p2[]="||";
  char *s,*s1,*s2;
  int len;
  if((s1=strstr(icon_text,buffer))>0)
  {
    s1+=strlen(buffer);
    if((s2=strstr(s1,p2))>0)
    {
      len=s2-s1-1;
      s=malloc(len+1);
      strncpy(s,s1+1,len);
      s[len]='\0';
      if(show) DrawImg(17,w+1,(int)s);
      DrawImg(102,w+1,(int)s);
      mfree(s);
    }
  }
}
*/
void InitFiles()
{
  InitUnderlinks_count();
  InitImgPaths();
  if(LinkCounters[0]=='0') InitMainLink(MLINK1, 1);
  if(LinkCounters[1]=='0') InitMainLink(MLINK2, 2);
  if(LinkCounters[2]=='0') InitMainLink(MLINK3, 3);
  if(LinkCounters[3]=='0') InitMainLink(MLINK4, 4);
  if(LinkCounters[4]=='0') InitMainLink(MLINK5, 5);
  if(LinkCounters[5]=='0') InitMainLink(MLINK6, 6);
  if(LinkCounters[6]=='0') InitMainLink(MLINK7, 7);
  if(LinkCounters[7]=='0') InitMainLink(MLINK8, 8);
//  if(LinkCounters[8]=='0') InitMainLink(MLINK9, 9);
}
