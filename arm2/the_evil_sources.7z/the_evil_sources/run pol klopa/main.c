#include "..\inc\swilib.h"
#include "conf_loader.h"

extern const int sec;
GBSTMR mytmr;
extern const char elf1[64];
extern const char elf2[64];
extern const char elf3[64];
extern const char elf4[64];
extern const char elf5[64];
extern const char elf6[64];
extern const char elf7[64];
extern const char elf8[64];
extern const char elf9[64];
extern const char elf10[64];

void run(char *elfiks)
{
          WSHDR *elfname=AllocWS(64);
          wsprintf(elfname, elfiks);
          ExecuteFile(elfname,NULL,NULL);
          FreeWS(elfname);
}

void dodo()
{
//  ShowMSG(1,(int)"done");
  if(strlen(elf1)>3) run((char*)elf1);
  if(strlen(elf2)>3) run((char*)elf2);
  if(strlen(elf3)>3) run((char*)elf3);
  if(strlen(elf4)>3) run((char*)elf4);
  if(strlen(elf5)>3) run((char*)elf5);
  if(strlen(elf6)>3) run((char*)elf6);
  if(strlen(elf7)>3) run((char*)elf7);
  if(strlen(elf8)>3) run((char*)elf8);
  if(strlen(elf9)>3) run((char*)elf9);
  if(strlen(elf10)>3) run((char*)elf10);
}

int main()
{
  InitConfig();
  GBS_StartTimerProc(&mytmr, 216*sec, dodo);
  return 0;
}
