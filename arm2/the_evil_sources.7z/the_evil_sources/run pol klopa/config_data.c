#include "..\inc\cfg_items.h"
//������������
__root const CFG_HDR cfghdr0={CFG_UINT,"countdown",0,60000};
__root const int sec=60;

__root const CFG_HDR cfghdr1 = {CFG_STR_WIN1251, "elf1 path", 0, 63};
__root const char elf1[64] = "";

__root const CFG_HDR cfghdr2 = {CFG_STR_WIN1251, "elf2 path", 0, 63};
__root const char elf2[64] = "";

__root const CFG_HDR cfghdr3 = {CFG_STR_WIN1251, "elf3 path", 0, 63};
__root const char elf3[64] = "";

__root const CFG_HDR cfghdr4 = {CFG_STR_WIN1251, "elf4 path", 0, 63};
__root const char elf4[64] = "";

__root const CFG_HDR cfghdr5 = {CFG_STR_WIN1251, "elf5 path", 0, 63};
__root const char elf5[64] = "";

__root const CFG_HDR cfghdr6 = {CFG_STR_WIN1251, "elf6 path", 0, 63};
__root const char elf6[64] = "";

__root const CFG_HDR cfghdr7 = {CFG_STR_WIN1251, "elf7 path", 0, 63};
__root const char elf7[64] = "";

__root const CFG_HDR cfghdr8 = {CFG_STR_WIN1251, "elf8 path", 0, 63};
__root const char elf8[64] = "";

__root const CFG_HDR cfghdr9 = {CFG_STR_WIN1251, "elf9 path", 0, 63};
__root const char elf9[64] = "";

__root const CFG_HDR cfghdr10 = {CFG_STR_WIN1251, "elf10 path", 0, 63};
__root const char elf10[64] = "";

