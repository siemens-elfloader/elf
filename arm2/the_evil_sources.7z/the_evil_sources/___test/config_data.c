#include "..\inc\cfg_items.h"
//������������

__root const CFG_HDR cfghdr0 = {CFG_COORDINATES,"Text position",0,0};
__root const unsigned int date_X = 0;
__root const unsigned int date_Y = 150;

__root const CFG_HDR cfghdr1 = {CFG_COLOR, "Color", 0, 0};
__root const char color[4]={0,0,0,100};
