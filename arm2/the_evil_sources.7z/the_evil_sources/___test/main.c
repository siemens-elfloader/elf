#include "..\inc\swilib.h"
#include "conf_loader.h"

const int minus11=-11;
extern const char color[];
extern const unsigned int date_X;
extern const unsigned int date_Y;
char buf[256];

typedef struct
{
  CSM_RAM csm;
}MAIN_CSM;

CSM_RAM *under_idle;

extern void kill_data(void *p, void (*func_p)(void *));

#pragma inline=forced

int toupper(int c)
{
  if ((c>='a')&&(c<='z')) c+='A'-'a';
  return(c);
}

int strcmp_nocase(const char *s1,const char *s2)
{
  int i;
  int c;
  while(!(i=(c=toupper(*s1++))-toupper(*s2++))) if (!c) break;
  return(i);
}
/*
GBSTMR mytmr;
int hmm;
int ggg;
void Counter()
{
  if(IsGPRSConnected())
  {
    RefreshGPRSTraffic();
    int *traf = GetGPRSTrafficPointer();
    hmm=*traf-ggg;
    sprintf(buf, "%d", hmm);
    ggg=*traf;
    GBS_StartTimerProc(&mytmr, 216, Counter);
  }
  else
    GBS_StartTimerProc(&mytmr, 216, Counter);
}

void Draw(void *canv)
{
  WSHDR *ws=AllocWS(256);
    wsprintf(ws,"%d:%d:%d", stundas, minutes, sekundes);
  DrawCanvas(canv,date_X,date_Y,date_X+wstrlen(ws)*25,date_Y+GetFontYSIZE(9),1);
  DrawString(ws,date_X,date_Y,date_X+Get_WS_width(ws,9)+2,date_Y+GetFontYSIZE(9),9,0,( char*) color,GetPaletteAdrByColorIndex(23));
  FreeWS(ws);
}

*/
int hmm;
void Draw(void *canv)
{
  hmm=*RamCap();
  WSHDR *ws=AllocWS(256);
  wsprintf(ws,"%02d", hmm);
  DrawCanvas(canv,date_X,date_Y,date_X+wstrlen(ws)*12,date_Y+GetFontYSIZE(9),1);
  DrawString(ws,date_X,date_Y,date_X+Get_WS_width(ws,9)+2,date_Y+GetFontYSIZE(9),9,0,( char*) color,GetPaletteAdrByColorIndex(23));
  FreeWS(ws);
}

int maincsm_onmessage(CSM_RAM* data,GBS_MSG* msg)
{
/*  char *ICON_PATH;
  ICON_PATH = "4:\\nahui.png";*/ // ����� ������� ���
  void *canvasdata=BuildCanvas();
  if(msg->msg == MSG_RECONFIGURE_REQ) 
  {
    extern const char *successed_config_filename;
    if (strcmp_nocase(successed_config_filename,(char *)msg->data0)==0)
    {
      ShowMSG(1,(int)"test config updated!");
      InitConfig();
    }
  }
  #define idlegui_id (((int *)icsm)[DISPLACE_OF_IDLEGUI_ID/4])
    CSM_RAM *icsm=FindCSMbyID(CSM_root()->idle_id);
    if (IsGuiOnTop(idlegui_id)/*&&IsUnlocked()*/) //���� IdleGui �� ����� �����
    {
      GUI *igui=GetTopGUI();
      if (igui) //� �� ����������
      {
	void *canvasdata=BuildCanvas();
      }
	//��� ����� �������
	// by Rainmaker: ������ ����� ������ ��� ������ � ������� � ����� �����������
//      if (IsUnlocked())
//      {

        Draw(canvasdata);
//	DrawCanvas(canvasdata,IDLEICON_X,IDLEICON_Y,IDLEICON_X+GetImgWidth((int)ICON)-1,IDLEICON_Y+GetImgHeight((int)ICON)-1,1);
//	DrawImg(IDLEICON_X,IDLEICON_Y,(int)ICON);
//        Draw(canvasdata);
//      }
      }
  return (1);  
}

static void maincsm_oncreate(CSM_RAM *data)
{

}

static void Killer(void)
{
//  GBS_DelTimer(&mytmr);
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}

static void maincsm_onclose(CSM_RAM *csm)
{
  SUBPROC((void *)Killer);
}

static unsigned short maincsm_name_body[140];

static const struct
{
  CSM_DESC maincsm;
  WSHDR maincsm_name;
}MAINCSM =
{
  {
  maincsm_onmessage,
  maincsm_oncreate,
#ifdef NEWSGOLD
  0,
  0,
  0,
  0,
#endif
  maincsm_onclose,
  sizeof(MAIN_CSM),
  1,
  &minus11
  },
  {
    maincsm_name_body,
    NAMECSM_MAGIC1,
    NAMECSM_MAGIC2,
    0x0,
    139
  }
};


static void UpdateCSMname(void)
{
  wsprintf((WSHDR *)(&MAINCSM.maincsm_name),"test");
}

int main()
{
  InitConfig();
//  Counter();
  CSM_RAM *save_cmpc;
  char dummy[sizeof(MAIN_CSM)];
  UpdateCSMname();  
  LockSched();
  save_cmpc=CSM_root()->csm_q->current_msg_processing_csm;
  CSM_root()->csm_q->current_msg_processing_csm=CSM_root()->csm_q->csm.first;
  CreateCSM(&MAINCSM.maincsm,dummy,0);
  CSM_root()->csm_q->current_msg_processing_csm=save_cmpc;
  UnlockSched();
//  extern const int ENA_HELLO_MSG;
//  if (ENA_HELLO_MSG) ShowMSG(1,(int)"NSD ����������!");  
  return 0;
}
