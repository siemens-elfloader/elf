
#ifndef __HELPERPROC_H__
#define __HELPERPROC_H__




void helperproc_schedule(void *func, void *d1, void *d2, void *d3);


#endif
