#ifndef _ASM_SIGCONTEXT_H
#define _ASM_SIGCONTEXT_H

#include <sys/cdefs.h>

__BEGIN_DECLS


#include <asm/arm-sigcontext.h>


__END_DECLS

#endif
