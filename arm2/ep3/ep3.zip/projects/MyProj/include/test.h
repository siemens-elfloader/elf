#ifndef TEST_H
#define TEST_H


class test
{
    public:
        test();
        ~test();
    protected:
    private:
};

#endif // TEST_H
