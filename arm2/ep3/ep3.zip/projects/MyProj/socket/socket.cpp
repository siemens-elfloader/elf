#include <swilib.h>
#include <stdlib.h>
#include <sys/socket.h>

#include "socket.h"
SOCKET::SOCKET(char *h,int p)
{
HOST=new char(strlen(h));
buf = new char(BUFFSIZE);
strcpy(HOST,h);
PORT=p;
BUFFSIZE=2024;
MAXBUF=2024*1024;
}

SOCKET::~SOCKET()
{
    delete HOST;
    delete buf;
}

unsigned int SOCKET::IP(const char *ip)
{
    unsigned int A,B,C,D;
    sscanf(ip,"%d.%d.%d.%d",&A,&B,&C,&D);
    return IP_ADDR(A,B,C,D);
}


void SOCKET::connect()
{
    SOCK_ADDR sa;
    connect_state=0;
    sock = _socket(1,1,0);
    if (sock!=-1)
    {
        sa.family=AF_UNIX;
        sa.port=htons(PORT);
        sa.ip=htonl(IP(HOST));
        if(_connect(sock,&sa,sizeof(sa))!=-1)
        {
            connect_state=1;
        }
        else
        {
            closesocket(sock);
            sock=-1;
        }
    }
}

int SOCKET::sendr(char *request)
{
    if(!buf)buf = new char(BUFFSIZE);

    connect_state=2;

    return send(sock,request,strlen(request),0);
}


int SOCKET::recvr()
{

    int j=0;
    int pbuf=0;
    while((j=recv(sock,buf+pbuf,BUFFSIZE,0))>0)//�������� ���� �����
    {
        pbuf+=j;
        buf[pbuf] = 0;
        buf=(char*)realloc(buf,pbuf+BUFFSIZE);
        if(pbuf>MAXBUF)
        {

            //
        }
    }

buf[pbuf]=0;
return pbuf;
}


void SOCKET::set_bufsize(int size,int max_size)
{
    BUFFSIZE=size;
    MAXBUF=max_size;
}

void SOCKET::onmess(int data1,int data0)
{

        if (data1==sock)
        {
            switch(data0)
            {
            case ENIP_SOCK_CONNECTED:
                if (connect_state==1)
                {

                }
                break;
            case ENIP_SOCK_DATA_READ:
                if (connect_state==2)

                    recvr();
                break;
            case ENIP_SOCK_REMOTE_CLOSED:
                //������ �� ������� �������
              //  if (connect_state)
                //    SUBPROC((void *)end_socket);
                //    end_socket();
                break;
            }
        }
}
