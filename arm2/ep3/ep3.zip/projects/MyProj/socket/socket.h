class SOCKET
{
    private:
    int sock;
    int connect_state;
    int PORT;
    char *HOST;
    unsigned int IP(const char *);
    int BUFFSIZE;
    int MAXBUF;
    public:
    SOCKET(char *,int);
    ~SOCKET();
    void set_bufsize(int,int);
    void connect();
    int sendr(char *);
    int recvr();
    char *buf;
    void onmess(int,int);
};
