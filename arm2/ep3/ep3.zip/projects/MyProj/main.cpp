#include <swilib.h>
#include <unistd.h>
#include <conf_loader.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
//#include "gui/gui.h"
#include "SOCKET/SOCKET.h"












void _init()
{
    ShowMSG(1, (int)"Hello");
}




