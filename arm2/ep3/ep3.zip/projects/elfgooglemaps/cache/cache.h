void load_cache();
void search_cache();
