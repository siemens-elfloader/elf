double LToX(double x);
double LToY(double y);
double XToL(double x);
double YToL(double x);
#define PI 3.1415926535
#define offset  268435456
double radius  =offset / PI;


int mktree(char* path);
void save_image_in_cache(int n);
double round(double num);
double LToX(double x);
double LToY(double y);
double XToL(double x);
double YToL(double y);
