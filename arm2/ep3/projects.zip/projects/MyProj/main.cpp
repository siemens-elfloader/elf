#include <swilib.h>
#include <unistd.h>
#include <conf_loader.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include "SOCKET/SOCKET.h"












void _init()
{
   //SOCKET *s= new SOCKET("http://google.ru/",80);
}
int Test()
{
    return 1;
}



