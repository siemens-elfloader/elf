#ifndef INTERNET_H
#define INTERNET_H
void create_connect();
void send_req();
void get_answer();
void create_request();
void c();
void end_socket();
#endif
