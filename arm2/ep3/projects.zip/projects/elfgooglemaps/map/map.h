#ifndef MAP_H
#define MAP_H
double LToX(double x);
double LToY(double y);
double XToL(double x);
double YToL(double x);
int mktree(char* path);
void save_image_in_cache(int n);
double round(double num);
double LToX(double x);
double LToY(double y);
double XToL(double x);
double YToL(double y);
#endif
