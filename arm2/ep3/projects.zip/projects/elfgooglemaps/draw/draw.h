#ifndef DRAW_H
#define DRAW_H
void Redraw();
void DrawInstall();
#endif
