#ifndef CACHE_H
#define CACHE_H
void load_cache();
void search_cache();
#endif
