#ifndef SOCKET_H
#define SOCKET_H

int Test();

#endif
