extern void CONNECT_GUI();

extern const char perc_t[];

