/* * * * * * * * * * * * * * * * * * */
/*  Chest Archiver 1.0 source code   */
/*  (C) Simakov Alexander 11/07/2K   */
/* * * * * * * * * * * * * * * * * * */

#include <stdio.h>
#include <string.h>

#define MAX_BITS  14
#define INC_SIZE  256
#define END_FILE  257
#define TAB_RESET 258
#define MAX_CODE  1<<MAX_BITS
#define EMPTY     MAX_CODE

#if MAX_BITS==14
 #define TAB_SIZE 18041
#endif
#if MAX_BITS==13
 #define TAB_SIZE 9029
#endif
#if MAX_BITS<=12
 #define TAB_SIZE 5021
#endif

typedef unsigned long int DWORD;
typedef unsigned int      WORD;
typedef unsigned char     BYTE;

FILE  *infile, *outfile;
BYTE  code_size=9;
WORD  next_code=259;
WORD  sp=0;
WORD  w_buf=0;
DWORD r_buf=0;
DWORD tmp_buf=0;
BYTE  free_bits=16;

void *malloc();

WORD *code;
WORD *pref;
BYTE *root;
BYTE stack[MAX_CODE];

void put_code(WORD c) {
    if(free_bits>=code_size) {
        w_buf<<=code_size;
        w_buf|=c;
        if(free_bits==code_size) {
            fwrite(&w_buf,2,1,outfile);
            free_bits=16;
            return;
        }
        free_bits-=code_size;
    }
    else {
        w_buf<<=free_bits;
        w_buf|=c>>(code_size-free_bits);
        fwrite(&w_buf,2,1,outfile);
        w_buf=c;
        free_bits+=16-code_size;
    }
}

void flush_buf() {
    if(free_bits!=16) {
        w_buf<<=free_bits;
        fwrite(&w_buf,2,1,outfile);
        free_bits=16;
    }
}

WORD get_code() {
    WORD c;
    c=r_buf>>(32-code_size);
    r_buf<<=code_size;
    free_bits+=code_size;

    if(free_bits>=16) {
        tmp_buf=0;
        fread(&tmp_buf,2,1,infile);
        tmp_buf<<=free_bits-16;
        r_buf|=tmp_buf;
        free_bits-=16;    
    }
    return c;  
}

void fill_buf() {
    fread(&r_buf,2,1,infile);
    r_buf<<=16;
}
        
DWORD file_size(FILE *fp) {
    DWORD save_pos, size_of_file;
    save_pos=ftell(fp);
    fseek(fp,0L,SEEK_END);
    size_of_file=ftell(fp);
    fseek(fp,save_pos,SEEK_SET);
    return size_of_file;
}

WORD hash(WORD h_pref,BYTE h_root)
{
    register int index;
    register int offset;
    index=(h_root<<(code_size-8))^h_pref;
    if(index==0) offset=1;
    else offset=TAB_SIZE-index;
    while (1) {
        if(code[index]==EMPTY) return index;
        if(pref[index]==h_pref && root[index]==h_root) return index;
        index-=offset;
        if(index<0) index+=TAB_SIZE;
    }
}

void build_match(WORD c) {
    while(1) {        
        stack[sp++]=root[c];   
        if(pref[c]==EMPTY) break;
        c=pref[c];        
    }
}

void compress() {
    register WORD cur_pref;
    register BYTE cur_root;
    register WORD index;    
    DWORD bytes_left;
    WORD  i;
 
    cputs("Compressing...   ");
    code=malloc(TAB_SIZE*sizeof(WORD));
    pref=malloc(TAB_SIZE*sizeof(WORD));
    root=malloc(TAB_SIZE*sizeof(BYTE));
    if(code==NULL || pref==NULL || root==NULL) {
        printf("Fatal error allocating table space!\n");
        exit();
    }
    for(i=0; i<=TAB_SIZE-1; i++) code[i]=EMPTY;
    bytes_left=file_size(infile);
    cur_pref=fgetc(infile); bytes_left--;

    while(bytes_left--)
    {   
        cur_root=fgetc(infile);
        index=hash(cur_pref,cur_root);

        if(code[index]!=EMPTY) {
            cur_pref=code[index];
        }
        else {
            code[index]=next_code++;
            pref[index]=cur_pref;
            root[index]=cur_root;
            put_code(cur_pref);
            cur_pref=cur_root;

            if(next_code>>code_size) {
                if(next_code==MAX_CODE) {
                    for(i=0;i<=TAB_SIZE-1;i++) 
                    code[i]=EMPTY;
                    put_code(TAB_RESET);
                    next_code=259;
                    code_size=9;
                }
                else {
                    put_code(INC_SIZE);
                    code_size++; 
                }
            }
        }
    }
    cputs(" Work complete!\n"); put_code(cur_pref);
    free(code); free(pref); free(root);
    put_code(END_FILE); flush_buf(); 
}

void decompress() {
    register WORD new_code;
    register WORD old_code;
    WORD  i;

    cputs("Decompressing... ");            
    pref=malloc(TAB_SIZE*sizeof(WORD));
    root=malloc(TAB_SIZE*sizeof(BYTE));
    if(pref==NULL || root==NULL) {
        printf("Fatal error allocating table space!\n");
        exit();
    }
    for(i=0;i<=255;i++) {
        root[i]=i;
        pref[i]=EMPTY;
    }
    fill_buf(); old_code=get_code();
    fputc(old_code,outfile);
            
    while((new_code=get_code())!=END_FILE) {
        if(new_code==TAB_RESET) {
            code_size=9; 
            next_code=259;
            old_code=get_code();
            fputc(old_code,outfile);
            continue;
        }
        if(new_code==INC_SIZE) {
            code_size++;
            continue;
        }
        if(new_code<next_code) {
            build_match(new_code);
            for(i=1; i<=sp; i++) fputc(stack[sp-i],outfile);
        }
        else {
            build_match(old_code);
            for(i=1; i<=sp; i++) fputc(stack[sp-i],outfile); 
            fputc(stack[sp-1],outfile);
        }
            pref[next_code]=old_code;
            root[next_code]=stack[sp-1];
            old_code=new_code; 
            next_code++; sp=0;            
    }
            cputs(" Work complete!\n");
            free(pref); free(root);
}

void main(int argc, char *argv[]) {
    BYTE *s; 
    puts("\nChest Archiver 1.0, Copyright (C) 1998-2K Simakov Alexander");
    if((argc!=4) || ((s=argv[1],s[1] || strpbrk(s,"CDcd"))==NULL) || (strlen(s)!=1)) {
        printf("Usage: chest <command> <infile> <outfile>\n\n");
        printf("<command> -> c  compress   | <infile>  -> input file\n");
        printf("          -> d  decompress | <outfile> -> output file\n");
        return;
     }
    if((infile=fopen(argv[2],"rb"))==NULL) {
        printf("Can`t open file %s\n",argv[2]); 
        return;
    }
    if((outfile=fopen(argv[3],"wb"))==NULL) {
        printf("Can`t create file %s\n",argv[3]); 
        return;
    } 
    if((file_size(infile)==0) && (toupper(*argv[1])=='C')) {
        printf("File %s is empty\n",argv[2]); 
        remove(argv[3]); return;
    } 
    if(toupper(*argv[1])=='C') compress(); else decompress();
    fclose(infile); fclose(outfile);
}