#include "..\inc\cfg_items.h"

__root const CFG_HDR cfghdr0={CFG_STR_WIN1251,"Bookmark 1 name",1,31};
__root const char BM1NAME[32]="";
__root const CFG_HDR cfghdr1={CFG_STR_UTF8,"Bookmark 1 file",3,127};
__root const char BM1FILE[128]="";

__root const CFG_HDR cfghdr2={CFG_STR_WIN1251,"Bookmark 2 name",1,31};
__root const char BM2NAME[32]="";
__root const CFG_HDR cfghdr3={CFG_STR_UTF8,"Bookmark 2 file",3,127};
__root const char BM2FILE[128]="";

__root const CFG_HDR cfghdr4={CFG_STR_WIN1251,"Bookmark 3 name",1,31};
__root const char BM3NAME[32]="";
__root const CFG_HDR cfghdr5={CFG_STR_UTF8,"Bookmark 3 file",3,127};
__root const char BM3FILE[128]="";

__root const CFG_HDR cfghdr6={CFG_STR_WIN1251,"Bookmark 4 name",1,31};
__root const char BM4NAME[32]="";
__root const CFG_HDR cfghdr7={CFG_STR_UTF8,"Bookmark 4 file",3,127};
__root const char BM4FILE[128]="";

__root const CFG_HDR cfghdr8={CFG_STR_WIN1251,"Bookmark 5 name",1,31};
__root const char BM5NAME[32]="";
__root const CFG_HDR cfghdr9={CFG_STR_UTF8,"Bookmark 5 file",3,127};
__root const char BM5FILE[128]="";

__root const CFG_HDR cfghdr10={CFG_STR_WIN1251,"Bookmark 6 name",1,31};
__root const char BM6NAME[32]="";
__root const CFG_HDR cfghdr11={CFG_STR_UTF8,"Bookmark 6 file",3,127};
__root const char BM6FILE[128]="";

__root const CFG_HDR cfghdr12={CFG_STR_WIN1251,"Bookmark 7 name",1,31};
__root const char BM7NAME[32]="";
__root const CFG_HDR cfghdr13={CFG_STR_UTF8,"Bookmark 7 file",3,127};
__root const char BM7FILE[128]="";

__root const CFG_HDR cfghdr14={CFG_STR_WIN1251,"Bookmark 8 name",1,31};
__root const char BM8NAME[32]="";
__root const CFG_HDR cfghdr15={CFG_STR_UTF8,"Bookmark 8 file",3,127};
__root const char BM8FILE[128]="";

__root const CFG_HDR cfghdr16={CFG_STR_WIN1251,"Bookmark 9 name",1,31};
__root const char BM9NAME[32]="";
__root const CFG_HDR cfghdr17={CFG_STR_UTF8,"Bookmark 9 file",3,127};
__root const char BM9FILE[128]="";
