#include "swilib.h"

#define IMAG_CB_BW 1
#define IMAG_CB_8bit 5
#define IMAG_CB_16bit 8
#define IMAG_CB_packed 0x80

TImage ImageCreateHdr8(unsigned char ** bm,int w,int h,int size);
TImage ImageCreateHdr16(unsigned short ** bm,int w,int h,int size);

int ImageWidth(TImage a)
{
if(a==ImageNull)return 0;
if((a>>16)!=0)
return ((IMGHDR*)a)->w;
else
return GetImgWidth(a);
};

int ImageHeight(TImage a)
{
if(a==ImageNull)return 0;
if((a>>16)!=0)
return ((IMGHDR*)a)->h;
else
return GetImgHeight(a);
};


void _DrwImg(IMGHDR *img, int x, int y, int *pen, int *brush)
{
RECT rc;
DRWOBJ drwobj;
StoreXYWHtoRECT(&rc, x, y, img->w, img->h);
SetPropTo_Obj5(&drwobj, &rc, 0, img);
SetColor(&drwobj, (char*)pen, (char*)brush);
DrawObject(&drwobj);
}

void ImageDraw(TImage a,int x,int y)
{
if(a==ImageNull) return;
if((a>>16)==0)
DrawImg(x,y,(int)a);
else
_DrwImg((IMGHDR*)a,x,y,(int*)GetPaletteAdrByColorIndex(0),(int*)GetPaletteAdrByColorIndex(1));
};

void ImageFree(TImage a)
{
//ShowMSGParam("freeimg=%X",a);
if(a==ImageNull) return;
if((a>>16)==0)return;
mfree((void*)a);
};

void MakeFullScreenShotToBuf(TImage a)
{
//if(a>>16==0) return;
memcpy((void*)((char*)a+sizeof(IMGHDR)),(void *)RamScreenBuffer(),ScreenW()*ScreenH()*2);
};

TImage MakeFullScreenShot()
{
unsigned short *bm;
TImage re=ImageCreateHdr16(&bm,
ScreenW(),
ScreenH(),
ScreenW()*ScreenH()*2+2);
memcpy((void*)bm,(void *)RamScreenBuffer(),ScreenW()*ScreenH()*2);
return re;
};

TImage MakeScreenShot(int x,int y,int w,int h)
{
unsigned short *bm;
TImage re=ImageCreateHdr16(&bm,
w,
h,
w*h*2+2);
MakeScreenShotToBuf(re,x,y,w,h);
//memcpy((void*)bm,(void *)RamScreenBuffer(),ScreenW()*ScreenH()*2);
return re;
};

void MakeScreenShotToBuf(TImage a,int x,int y,int w,int h)
{
unsigned short *bm=(unsigned short*)((char*)a+sizeof(IMGHDR));
unsigned short * p=(unsigned short *)RamScreenBuffer()+x;
for(int i=0;i<h;i++)
{
memcpy((void*)bm,(void *)p,w*2);
p+=w;
bm+=w;
};
};

TImage ImageLoadFromRef(char * ref,char *cwd)
{
if(ref==0) return ImageNull;
if(ref[0]=='#')
return Hex2Int(&(ref[1]))&0xFFFF;
else
{
char bu[256];
if(ref[0]==0||ref[1]==0) return ImageNull;
if(ref[1]==':')
strcpy(bu,ref);
else
sprintf(bu,"%s%s",cwd,ref);
int l=strlen(bu)-1;
if(bu[l]=='!')
{
bu[l]=0;
return ImageLoadFromFile(bu,1);
}
else
return ImageLoadFromFile(bu,0);
};
}

typedef struct
{
short sign;
short unk1[8];
short w;
short zero1;
short h;
short zero2;
short numplanes;
short bpp;
short unk2[12];
}bmp_PICHDR;

typedef struct
{
char signature[16];
unsigned short picnum;
unsigned short unk1;
char w;
char h;
char Compr_Bits;
}gpf_PICHDR;


TImage _ReadBMP(char * data,int sz,int highquality)
{
bmp_PICHDR* g=(bmp_PICHDR*)data;
TImage res;

if(g->bpp!=24)
{
mfree(data);
return ImageNull;
}

if(highquality)
{
unsigned short *bm;
res=ImageCreateHdr16(&bm,
g->w,
g->h,
0
);
// switch(g->bpp)
// {
// case 24:
// {
bm+=(g->w*(g->h-1));
char *p=data+sizeof(bmp_PICHDR);
int _transparent_color=RGB24(*p,*(p+1),*(p+2));
int df=(g->w)&3;
for(int i=0;i<g->h;i++)
{
for(int j=0;j<g->w;j++){
char r=*p++;
char g=*p++;
char b=*p++;
*bm++=(RGB24(r,g,b)==_transparent_color)?TRANSPARENT_16:RGB16(b,g,r);
};
p+=df;
bm-=2*g->w;
};
// break;}
}
else
{
unsigned char *bm;
res=ImageCreateHdr8(&bm,
g->w,
g->h,
0
);
// switch(g->bpp)
// {
// case 24:
// {
bm+=(g->w*(g->h-1));
char *p=data+sizeof(bmp_PICHDR);
int _transparent_color=RGB24(*p,*(p+1),*(p+2));
int df=(g->w)&3;
for(int i=0;i<g->h;i++)
{
for(int j=0;j<g->w;j++){
char r=*p++;
char g=*p++;
char b=*p++;
*bm++=(RGB24(r,g,b)==_transparent_color)?TRANSPARENT_8:RGB8(b,g,r);
};
p+=df;
bm-=2*g->w;
};
};
/*

switch(g->bpp)
{
case 24:
{
bm+=(g->w*(g->h-1));
char *p=data+sizeof(bmp_PICHDR);
int df=(g->w)&3;
for(int i=0;i<g->h;i++)
{
for(int j=0;j<g->w;j++){
char r=*p++;
char g=*p++;
char b=*p++;
*bm++=RGB16(b,g,r);
};
p+=df;
bm-=2*g->w;
};
break;}

case 16:
{
bm+=(g->w*(g->h-1));
int df=(((g->w)&2)>>1);
unsigned short *p=(unsigned short *)(data+sizeof(bmp_PICHDR));
for(int i=0;i<g->h;i++)
{
for(int j=0;j<g->w;j++) {
int c=*p++;
//bug!!!
//*bm++=RGB16( ((c>>11)<<3),(((c>>5)&63)<<2),(c&31)<<3 );
*bm++=RGB16( ((c>>10)<<2),(((c>>5)&31)<<2),(c&31)<<2);
};
p+=df;
bm-=2*g->w;
break;
};
};
}; */
mfree(data);
return res;
};


TImage _ReadGPF(char * data,int sz)
{
char * a=malloc(sz);
((IMGHDR*)a)->w=((gpf_PICHDR*)data)->w;
((IMGHDR*)a)->h=((gpf_PICHDR*)data)->h;
((IMGHDR*)a)->bpnum=((gpf_PICHDR*)data)->Compr_Bits;
((IMGHDR*)a)->bitmap=a+sizeof(IMGHDR);
memcpy(a+sizeof(IMGHDR),data+sizeof(gpf_PICHDR),sz-sizeof(gpf_PICHDR));
mfree(data);
return (TImage)a;
};

void* xmalloc(int x,int n)
{
return malloc(n);
}

void xmfree(int x,void* n)
{
mfree(n);
}

typedef struct
{
char * data;
unsigned int errno;
int po;
}READ_MEM;


void read_data_fn(png_structp png_ptr, png_bytep data, png_size_t length)
{
READ_MEM*read;
read=png_get_io_ptr(png_ptr);
memcpy(data,(read->data)+(read->po),length);
read->po+=length;
}


TImage _ReadPNG(char * data,int sz,int highquality)
{
extern int enable_png;
if(!enable_png) return ImageNull;

READ_MEM read={data,0,4};

png_structp png_ptr = png_create_read_struct_2("1.2.5", (png_voidp)0, 0, 0, (png_voidp)0,(png_malloc_ptr)xmalloc,(png_free_ptr)xmfree);
if (!png_ptr) {mfree(data);return (0);}

png_infop info_ptr = png_create_info_struct(png_ptr);
if (!info_ptr)
{
png_destroy_read_struct(&png_ptr, (png_infopp)NULL, (png_infopp)NULL);
mfree(data);return ImageNull;
}

png_infop end_info = png_create_info_struct(png_ptr);
if (!end_info)
{
png_destroy_read_struct(&png_ptr, &info_ptr,(png_infopp)NULL);
mfree(data);return ImageNull;
}

if (setjmp(png_jmpbuf(png_ptr)))
{
png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
mfree(data);return ImageNull;
}

png_set_read_fn(png_ptr, &read, read_data_fn);

png_set_sig_bytes(png_ptr, 4);

png_read_info(png_ptr, info_ptr);

png_uint_32 width, height;
int bit_depth, color_type;

png_get_IHDR(png_ptr, info_ptr, &width, &height, &bit_depth, &color_type, 0, 0, 0);

if (bit_depth == 16) png_set_strip_16(png_ptr);

if (bit_depth < 8) png_set_packing(png_ptr);

if (color_type == PNG_COLOR_TYPE_PALETTE)
png_set_palette_to_rgb(png_ptr);

if (color_type == PNG_COLOR_TYPE_GRAY || color_type == PNG_COLOR_TYPE_GRAY_ALPHA)
png_set_gray_to_rgb(png_ptr);

if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS))
png_set_tRNS_to_alpha(png_ptr);

png_set_filler(png_ptr,0xFF,PNG_FILLER_AFTER);

png_read_update_info(png_ptr, info_ptr);

png_uint_32 rowbytes = png_get_rowbytes(png_ptr, info_ptr);

TImage a;

unsigned char *row=malloc(rowbytes);

if(highquality)
{
unsigned short *bm;
a=ImageCreateHdr16(&bm,
width,
height,
0);
for (unsigned int y = 0; y<height; y++)
{
png_read_row(png_ptr, (png_bytep)row, NULL);
for (unsigned int x = 0; x<width; x++)
{
if (!row[x*4+3])
bm[x+y*width]=TRANSPARENT_16;
else
{
unsigned short c=RGB16(row[x*4+0],row[x*4+1],row[x*4+2]);
bm[x+y*width]=(c==TRANSPARENT_16)?(TRANSPARENT_16+1):c;
}
}
}
}
else
{
unsigned char * bm;
a=ImageCreateHdr8(&bm,
width,
height,
0);
for (unsigned int y = 0; y<height; y++)
{
png_read_row(png_ptr, (png_bytep)row, NULL);
for (unsigned int x = 0; x<width; x++)
{
if (!row[x*4+3])
bm[x+y*width]=TRANSPARENT_8;
else
{
unsigned char c=RGB8(row[x*4+0],row[x*4+1],row[x*4+2]);
bm[x+y*width]=(c==TRANSPARENT_8)?(TRANSPARENT_8+1):c;
}
}
}
};

png_read_end(png_ptr, end_info);
png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);

mfree(row);
mfree(data);
return a;
};

TImage ImageLoadFromFile(char * path,int highquality)
{
int sz;
char * data=ReadFile(path,&sz);
if(data==0) return ImageNull;
if(data[0]=='B'&&data[1]=='M')
{
//bmp
return _ReadBMP(data,sz,highquality);
}
else if(data[0]==0x89&&data[1]=='P'&&data[2]=='N'&&data[3]=='G')
{
//png
return _ReadPNG(data,sz,highquality);
}
else if(data[0]=='G'&&data[1]=='r'&&data[2]=='a'&&data[3]=='p')
{
//gpf
return _ReadGPF(data,sz);
}
else
{
return ImageNull;
};
};


TImage ImageCreateHdr16(unsigned short ** bm,int w,int h,int size)
{
if(size==0) size=w*h*2;
IMGHDR *img=malloc(sizeof(IMGHDR)+size+4);
*bm=(unsigned short *)((unsigned int)img+sizeof(IMGHDR));
img->w=w;
img->h=h;
img->bpnum=IMAG_CB_16bit; //For BW=1, 8bit=5, 16bit=8, 0x80 - packed
img->bitmap=(char*)(*bm);
return (TImage)img;
};

TImage ImageCreateHdr8(unsigned char ** bm,int w,int h,int size)
{
if(size==0) size=w*h;
IMGHDR *img=malloc(sizeof(IMGHDR)+size+4);
*bm=(unsigned char *)((unsigned int)img+sizeof(IMGHDR));
img->w=w;
img->h=h;
img->bpnum=IMAG_CB_8bit; //For BW=1, 8bit=5, 16bit=8, 0x80 - packed
img->bitmap=(char*)(*bm);
return (TImage)img;
};


TImage ImageCreate(unsigned short ** bm,int w,int h)
{
IMGHDR *img=malloc(sizeof(IMGHDR)+2*w*h+4);
*bm=(unsigned short *)((unsigned int)img+sizeof(IMGHDR));
img->w=w;
img->h=h;
img->bpnum=8; //For BW=1, 8bit=5, 16bit=8, 0x80 - packed
// img->zero=0;
img->bitmap=(char*)(*bm);
return (TImage)img;
};