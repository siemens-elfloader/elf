#ifndef image_H
#define image_H

#define RGB24(R, G, B) ((B<<16) | (G<<8) | (R))
#define RGB16(R, G, B) ((B>>3) | ((G>>2) << 5) | ((R>>3) << 11))
#define RGB8(R,G,B) ((R & 0xE0)|((G>>3)&0x1C)|((B>>6)&0x3))

#define TRANSPARENT_8 (0xC0)
#define TRANSPARENT_16 (0xE000)

typedef unsigned int TImage;

#define ImageNull ((TImage)0)

void ImageDraw(TImage a,int x,int y);
void ImageFree(TImage a);
int ImageWidth(TImage a);
int ImageHeight(TImage a);
TImage ImageLoadFromFile(char * path,int highquality);
TImage ImageLoadFromRef(char * ref,char *cwd);
TImage MakeScreenShot(int x,int y,int w,int h);
TImage MakeFullScreenShot();
void MakeScreenShotToBuf(TImage a,int x,int y,int w,int h);
void MakeFullScreenShotToBuf(TImage a);
//TImage ImageCreate(unsigned short **bm,int w,int h);
//bmp,gpf,png,#

#endif