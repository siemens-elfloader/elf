#include "E:\arm\swilib.h"
#include "E:\arm\cfg_items.h"
#include "conf_loader.h"

extern const unsigned int alram1;
extern const unsigned int alram2;
extern const unsigned int alram3;

extern const unsigned int h1;
extern const unsigned int h2;
extern const unsigned int h3;

extern const unsigned int m1;
extern const unsigned int m2;
extern const unsigned int m3;

int count;

GBSTMR mytmr;

void Check(void)
{
TDate date; 
TTime time; 
GetDateTime(&date,&time); 

if (time.hour==h1)
{
    if (time.min==m1) 
  {
  if (alram1)
     AlarmClockRing();
  }
}

GetDateTime(&date,&time); 
if (time.hour==h2)
{
    if (time.min==m2) 
  {
  if (alram2)
     AlarmClockRing();
  }
}
GetDateTime(&date,&time); 
if (time.hour==h3)
{
    if (time.min==m3) 
  {
  if (alram3)
     AlarmClockRing();
  }
}
GBS_StartTimerProc(&mytmr,131*60,Check);
}

int main(void)
{
  InitConfig();
  Check();
  return 0;
}
