#include "E:\arm\cfg_items.h"

__root const CFG_HDR cfghdr0={CFG_CBOX,"1st alram",0,2};
__root const unsigned int alram1=1;
__root const CFG_CBOX_ITEM cfgcbox1[2]={"off","on"};

__root const CFG_HDR cfghdr1={CFG_UINT,"1st alram hours",0,24};
__root const unsigned int h1=6;

__root const CFG_HDR cfghdr2={CFG_UINT,"1st alram minuts",0,59};
__root const unsigned int m1=30;

__root const CFG_HDR cfghdr3={CFG_CBOX,"2nd alram",0,2};
__root const unsigned int alram2=0;
__root const CFG_CBOX_ITEM cfgcbox2[2]={"off","on"};

__root const CFG_HDR cfghdr4={CFG_UINT,"2nd alram hours",0,24};
__root const unsigned int h2=0;

__root const CFG_HDR cfghdr5={CFG_UINT,"2nd alram minuts",0,59};
__root const unsigned int m2=0;

__root const CFG_HDR cfghdr6={CFG_CBOX,"3rd alram",0,2};
__root const unsigned int alram3=0;
__root const CFG_CBOX_ITEM cfgcbox3[2]={"off","on"};

__root const CFG_HDR cfghdr7={CFG_UINT,"3rd alram hours",0,24};
__root const unsigned int h3=0;

__root const CFG_HDR cfghdr8={CFG_UINT,"3rd alram minuts",0,59};
__root const unsigned int m3=0;
