#include "E:\arm\swilib.h"
#include "E:\arm\cfg_items.h"
#include "conf_loader.h"

extern const unsigned int delay;
extern const unsigned int check_each;
extern const int dis;
extern const int key;
extern const int vib;
extern const unsigned int light;
extern const unsigned int vibra_pow;
extern const int check;

int count;

GBSTMR mytmr;

void LightOff();
void Check(void);
void LightOn()
{
  if (key)
    SetIllumination(1,1,light,0);   
  if (dis)
    SetIllumination(0,1,light,0);   
  if (vib)
    SetVibration(vibra_pow);    
  GBS_StartTimerProc(&mytmr,delay,LightOff);
}

void LightOff()
{
  if (key)
    SetIllumination(1,1,0,0);   
  if (dis)
    SetIllumination(0,1,0,0);   
  if (vib)
    SetVibration(0);    
  count--;
  if (count>0)
  {
    GBS_StartTimerProc(&mytmr,delay,LightOn);
  }
  else
  {
    GBS_StartTimerProc(&mytmr,check_each,Check);    
  }
}

void Check(void)
{
if(IsPlayerOn())
  {
    if (key || dis || vib)
    {
      LightOn();
    }
  }
    else   GBS_StartTimerProc(&mytmr,check_each,Check);
}

int main(void)
{
  InitConfig();
  Check();
  return 0;
}
