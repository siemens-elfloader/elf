#include "E:\arm\cfg_items.h"

__root const CFG_HDR cfghdr0={CFG_UINT,"freq",0,1048};
__root const unsigned int delay=10;

__root const CFG_HDR cfghdr1={CFG_UINT,"periods",0,104800};
__root const unsigned int check_each=10000;

__root const CFG_HDR cfghdr2={CFG_CBOX,"display",0,2};
__root const int dis=1;
__root const CFG_CBOX_ITEM cfgcbox1[2]={"off","on"};

__root const CFG_HDR cfghdr3={CFG_CBOX,"keyboard",0,2};
__root const int key=1;
__root const CFG_CBOX_ITEM cfgcbox0[2]={"off","on"};

__root const CFG_HDR cfghdr4={CFG_CBOX,"vibra",0,2};
__root const int vib=0;
__root const CFG_CBOX_ITEM cfgcbox2[2]={"off","on"};

__root const CFG_HDR cfghdr5={CFG_UINT,"light",0,100};
__root const unsigned int light=100;

__root const CFG_HDR cfghdr6={CFG_UINT,"Vibra power",0,100};
__root const unsigned int vibra_pow=100;

__root const CFG_HDR cfghdr7={CFG_CBOX,"work",0,3};
__root const int check=2;
__root const CFG_CBOX_ITEM cfgcbox5[3]={"1","2", "all"};
