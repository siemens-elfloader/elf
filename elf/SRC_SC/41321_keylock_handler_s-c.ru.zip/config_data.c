#include "E:\arm\cfg_items.h"

__root const CFG_HDR cfghdr0={CFG_UINT,"lock_profile",0,8};
__root const unsigned int set_pr1=0;

__root const CFG_HDR cfghdr1={CFG_UINT,"unlock_profile",0,8};
__root const unsigned int set_pr2=1;
