#include "E:\arm\swilib.h"
#include "E:\arm\cfg_items.h"
#include "conf_loader.h"

extern const unsigned int set_pr1;
extern const unsigned int set_pr2;

int count;
int profile;

GBSTMR mytmr;

void Check(void)
{
if (!IsUnlocked())
{
  SetProfile(set_pr1);
  
}   else   GBS_StartTimerProc(&mytmr,50,Check);
if (IsUnlocked())
{
  SetProfile(set_pr2);
}
    else   GBS_StartTimerProc(&mytmr,50,Check);
}

int main(void)
{
  InitConfig();
  Check();
  return 0;
}
