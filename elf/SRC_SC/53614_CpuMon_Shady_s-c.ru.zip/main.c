#include "E:\ARM\swilib.h"

#define UPDATE_TIME (1*131)
#define WIDTH 130
#define HEIGHT 25
#define X 0
#define Y 90

#define RGB8(R,G,B) (B+(G<<2)+(R<<5))

CSM_DESC icsmd;

int (*old_icsm_onMessage)(CSM_RAM*,GBS_MSG*);

GBSTMR mytmr;

unsigned char hhh;

unsigned char img1_bmp[WIDTH*HEIGHT-1];

const IMGHDR img1=
{
  WIDTH,
  HEIGHT,
  5,
  0,
  (char *)img1_bmp
};

unsigned char loads[WIDTH-1];
unsigned char clocks[WIDTH-1];

DrwImg(IMGHDR *img, int x, int y, int *pen, int *brush)
{
  RECT rc;
  DRWOBJ drwobj;
  StoreXYWHtoRECT(&rc,x,y,img->w,img->h);
  SetPropTo_Obj5(&drwobj,&rc,0,img);
  SetColor(&drwobj,pen,brush);
  DrawObject(&drwobj);
}

void TimerProc(void)
{
  GBS_SendMessage(MMI_CEPID,0xDE,GetCPULoad());
  GBS_StartTimerProc(&mytmr,UPDATE_TIME,TimerProc);
}


int MyIDLECSM_onMessage(CSM_RAM* data,GBS_MSG* msg)
{
  int csm_result;
  unsigned int x;
#define idlegui_id (((int *)data)[DISPLACE_OF_IDLEGUI_ID/4])

  //����������� ��������
  if (msg->msg==0xDE)
  {
    LockSched();
    loads[hhh]=HEIGHT*/*GetCPULoad()*/msg->submess/100;
    clocks[hhh]=HEIGHT*GetCPUClock()/104;
    UnlockSched();
    hhh++;
    if (hhh>=WIDTH) hhh=0;
    csm_result=0;
  }
  else
    csm_result=old_icsm_onMessage(data,msg); //�������� ������ ���������� �������
  if (IsGuiOnTop(idlegui_id)) //���� IdleGui �� ����� �����
  {
    GUI *igui=GetTopGUI();
    if (igui) //� �� ����������
    {
      void *idata;
      idata=GetDataOfItemByID(igui,2);
      if (idata)
      {
	void *canvasdata=((void **)idata)[DISPLACE_OF_IDLECANVAS/4];
	int y;
	DrawCanvas(canvasdata,X,Y,X+WIDTH,Y+HEIGHT,1);
	//������ ���� �������
	//     zeromem(img1_bmp,sizeof(img1_bmp));
	int h=hhh;
	for(x=0;x<WIDTH;x++){
	  for(y=0;y<HEIGHT;y++){
	    if (y<loads[h]){
	      img1_bmp[x+(HEIGHT-1-y)*WIDTH]=RGB8(7,0,0);
	    }else{
              if (y<loads[h])
                img1_bmp[x+(HEIGHT-1-y)*WIDTH]=RGB8(0,5,0);
              else
	        img1_bmp[x+(HEIGHT-1-y)*WIDTH]=RGB8(6,0,0);
	    }
	  }
	  h++;
	  if (h>=WIDTH) h=0;
	}
	DrwImg((IMGHDR *)&img1,X,Y,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(1));
      }
    }
  }
  return(csm_result);
}


int main(void)
{
  hhh=0;
  LockSched();
  CSM_RAM *icsm=FindCSMbyID(CSM_root()->idle_id);
  memcpy(&icsmd,icsm->constr,sizeof(icsmd));
  old_icsm_onMessage=icsmd.onMessage;
  icsmd.onMessage=MyIDLECSM_onMessage;
  icsm->constr=&icsmd;
  GBS_StartTimerProc(&mytmr,UPDATE_TIME*10,TimerProc);
  UnlockSched();
  return 0;
}
