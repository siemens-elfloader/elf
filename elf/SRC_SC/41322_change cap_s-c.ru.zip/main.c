#include "E:\arm\swilib.h"
#include "E:\arm\cfg_items.h"
#include "conf_loader.h"

extern const unsigned int cap;

GBSTMR mytmr;

void Check(void)
{
*RamCap()=cap;
GBS_StartTimerProc(&mytmr,10,Check);
}

int main(void)
{
  InitConfig();
  Check();
  return 0;
}
