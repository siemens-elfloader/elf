#include "E:\arm\cfg_items.h"

__root const CFG_HDR cfghdr0={CFG_UINT,"cap",0,100};
__root const unsigned int cap=0;
