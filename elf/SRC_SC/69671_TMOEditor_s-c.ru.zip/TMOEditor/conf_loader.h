#ifndef _CONFLOADER_H_
  #define _CONFLOADER_H_

char *getMiniGPSPath(char *buffer);
void InitConfig();
#endif
