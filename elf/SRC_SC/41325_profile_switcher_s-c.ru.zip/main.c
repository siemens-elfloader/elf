#include "E:\arm\swilib.h"
#include "E:\arm\cfg_items.h"
#include "conf_loader.h"

extern const unsigned int profile;
extern const unsigned int cap;
extern const unsigned int sound;
extern const int melody;

GBSTMR mytmr;

void Check(void)
{
if (cap>*RamCap())
     {
       SetProfile(profile);
       if (sound){
         PlaySound(1,0,0,melody,0);}
       GBS_StartTimerProc(&mytmr,1000,Check);
     }
GBS_StartTimerProc(&mytmr,1000,Check);
}

int main(void)
{
  InitConfig();
  Check();
  return 0;
}
