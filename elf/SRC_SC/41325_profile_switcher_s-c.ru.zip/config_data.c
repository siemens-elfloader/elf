#include "E:\arm\cfg_items.h"

__root const CFG_HDR cfghdr0={CFG_UINT,"set to profile",0,8};
__root const unsigned int profile=6;

__root const CFG_HDR cfghdr1={CFG_UINT,"cap",0,100};
__root const unsigned int cap=10;

__root const CFG_HDR cfghdr2={CFG_CBOX,"play sound",0,2};
__root const int sound=1;
__root const CFG_CBOX_ITEM cfgcbox1[2]={"off","on"};

__root const CFG_HDR cfghdr3={CFG_UINT,"melody",0,100};
__root const unsigned int melody=2;
