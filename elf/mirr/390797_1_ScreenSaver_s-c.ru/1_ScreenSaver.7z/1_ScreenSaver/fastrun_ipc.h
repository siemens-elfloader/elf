#define IPC_FASTRUN_NAME "FastRun_Imperial"
#define IPC_UPDATE_STAT 10

