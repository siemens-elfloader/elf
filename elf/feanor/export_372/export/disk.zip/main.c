#include "D:\Iar\inc\swilib.h"

IPC_REQ gipc;
char text[128];
void print()
{     
gipc.name_to= "Console";
gipc.name_from=text;
gipc.data=0;
GBS_SendMessage(MMI_CEPID,MSG_IPC,0,&gipc);
}


int main(char *exename, char *fname)
{
  unsigned int *ErrorNumber;
  
     int t0 = GetTotalFlexSpace(0, ErrorNumber)/1024;
     int t1 = GetTotalFlexSpace(1, ErrorNumber)/1024;
     int t2 = GetTotalFlexSpace(2, ErrorNumber)/1024;
     int t4 = GetTotalFlexSpace(4, ErrorNumber)/1024;
     
     int f0 = GetFreeFlexSpace(0, ErrorNumber)/1024;
     int f1 = GetFreeFlexSpace(1, ErrorNumber)/1024;
     int f2 = GetFreeFlexSpace(2, ErrorNumber)/1024;
     int f4 = GetFreeFlexSpace(4, ErrorNumber)/1024;
     
     int p0 = (f0*100)/t0;
     int p1 = (f1*100)/t1;
     int p2 = (f2*100)/t2;
     int p4 = (f4*100)/t4;
     
  if(strlen(fname)==1) 
  {
    sprintf(text,"Disk %i: %i/%i kb",fname[0]-'0',GetFreeFlexSpace(fname[0]-'0', ErrorNumber)/1024,GetTotalFlexSpace(fname[0]-'0', ErrorNumber)/1024);
    print();
  }
  
  if(strlen(fname)!=1)
  {
    sprintf(text,"Disk 0: %d kb/%d kb %i%%\rDisk 1: %d kb/%i kb %i%%\rDisk 2: %d kb/%i kb %i%%\rDisk 4: %d kb/%i kb %i%%",f0,t0,p0,f1,t1,p1,f2,t2,p2,f4,t4,p4);
    print();
  }
  return 0;
}
