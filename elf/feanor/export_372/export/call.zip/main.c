#include "..\..\inc\swilib.h"

int main(char *exename, char *fname)
{
  MakeVoiceCall(fname,0x10,(fname[0]=='*')?0x2FFF:0x20C0);
  return 0;
}
