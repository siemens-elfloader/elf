#include "cfg_items.h"
#include "swilib.h"
#include "lang.h"

__root const CFG_HDR cfghdr0={CFG_STR_UTF8,LG_SET_SMS_DAT_PATH,0,127};
__root const char SMS_DAT_PATH[128]="0:\\system\\sms\\sms.dat";
	
__root const CFG_HDR cfghdr1={CFG_STR_UTF8,LG_SET_SMSSOUND,0,127};
__root const char InSMSSound[128]="4:\\ZBin\\SMSman\\snd\\sms.mp3";

__root const CFG_HDR cfghdr2={CFG_STR_UTF8,LG_SET_FOLDERPIC,0,127};
__root const char pic_folder[128]="4:\\ZBin\\SMSman\\pic\\";

__root const CFG_HDR cfghdr3={CFG_STR_UTF8,LG_SET_FOLDERLOG,0,127};
__root const char log_folder[128]="4:\\ZBin\\SMSman\\log\\";

__root const CFG_HDR cfghdr4={CFG_CHECKBOX,LG_SET_IN_NOTIFY,0,0};
__root const int IN_NOTIFY=1;

//------------------------------------------------------------------------------

__root const CFG_HDR cfghdr_m02={CFG_LEVEL,LG_SET_IDLE,1,0};

__root const CFG_HDR cfghdr00_0={CFG_CHECKBOX,LG_SET_SHOW_IDLE_TEXT,0,0};
__root const int SHOW_IDLE_TEXT=1;

__root const CFG_HDR cfghdr00_1={CFG_CBOX,LG_SET_TYPE_FNT,0,2};
__root const int TYPE_FNT=1;
__root const CFG_CBOX_ITEM cfgcbox0[2]={"DrawString","PNG"};

__root const CFG_HDR cfghdr00_2={CFG_CBOX,LG_SET_SHOW_IN,0,3};
__root const int show_in=2;
__root const CFG_CBOX_ITEM cfgcbox1[3]={LG_SET_SHOW_IN_LOCK,LG_SET_SHOW_IN_UNLOCK,LG_SET_SHOW_IN_ALLLOCK};

__root const CFG_HDR cfghdr00_3={CFG_STR_WIN1251,LG_SET_IDLE_TEXT,0,127};
__root const char IDLETXT[128]=LG_SET_TEXT_FORMAT;
	 
__root const CFG_HDR cfghdr00_4={CFG_COORDINATES,LG_SET_IDLE_XY,0,0};
__root const unsigned int IDLE_X=10;
__root const unsigned int IDLE_Y=95;
 
__root const CFG_HDR cfghdr00_5={CFG_UINT,LG_SET_IDLE_FNT,0,12};
__root const unsigned int IDLE_FNT=FONT_SMALL_BOLD;

__root const CFG_HDR cfghdr00_6={CFG_STR_UTF8,LG_SET_PNG_FNT,0,63};
__root const char PNG_FNT_PATH[64]="4:\\ZBin\\Fonts\\";

__root const CFG_HDR cfghdr00_7={CFG_CHECKBOX,LG_SET_FULLFONT,0,0};
__root const int FULLFONT=0;

__root const CFG_HDR cfghdr00_8={CFG_CBOX,LG_SET_ALIGN,0,3};
__root const int ALIGN=0;
__root const CFG_CBOX_ITEM cfgcbox2[3]={LG_SET_ALIGN_LEFT,LG_SET_ALIGN_CENTER,LG_SET_ALIGN_RIGHT};

__root const CFG_HDR cfghdr00_9={CFG_UINT,LG_SET_SPACE,0,10};
__root const unsigned int SPACE=1;
	 
__root const CFG_HDR cfghdr00_10={CFG_CHECKBOX,LG_SET_SHOW_IDLE_PIC,0,0};
__root const int SHOW_IDLE_PIC=1;

__root const CFG_HDR cfghdr00_11={CFG_COORDINATES,LG_SET_IDLE_PIC_XY,0,0};
__root const unsigned int IDLEICON_X=10;
__root const unsigned int IDLEICON_Y=95;

__root const CFG_HDR cfghdr00_12={CFG_CHECKBOX,LG_SET_SHOW0NEW,0,0};
__root const int SHOW0NEW=1;

__root const CFG_HDR cfghdr_m03={CFG_LEVEL,"",0,0};

//------------------------------------------------------------------------------

//------------------------------------------------------------------------------

__root const CFG_HDR cfghdr_m000={CFG_LEVEL,LG_SET_PROFILES,1,0};

__root const CFG_HDR cfghdr_m00={CFG_LEVEL,LG_SET_PROFILE" 1",1,0};

__root const CFG_HDR cfghdr0_1={CFG_CHECKBOX,LG_SET_VIBRA,0,0};
__root const int VIBR_1=1;
 
__root const CFG_HDR cfghdr0_2={CFG_UINT,LG_SET_VIBRA_POWER,0,100};
__root const unsigned int V_P_1=100;
 
__root const CFG_HDR cfghdr0_3={CFG_UINT,LG_SET_VIBRA_COUNT,0,256};
__root const unsigned int V_C_1=10;
	 
__root const CFG_HDR cfghdr0_4={CFG_CHECKBOX,LG_SET_SOUND,0,0};
__root const int SOUND_1=1;
 
__root const CFG_HDR cfghdr0_5={CFG_UINT,LG_SET_SOUND_VOLUME,0,24};
__root const unsigned int S_VOL_1=5;

#ifdef ELKA
__root const CFG_HDR cfghdr0_6={CFG_CHECKBOX,LG_SET_SLI,0,0};
__root const int SLI_1=1;
#endif

__root const CFG_HDR cfghdr_m01={CFG_LEVEL,"",0,0};

//------------------------------------------------------------------------------
 
__root const CFG_HDR cfghdr_m10={CFG_LEVEL,LG_SET_PROFILE" 2",1,0};

__root const CFG_HDR cfghdr1_1={CFG_CHECKBOX,LG_SET_VIBRA,0,0};
__root const int VIBR_2=1;
 
__root const CFG_HDR cfghdr1_2={CFG_UINT,LG_SET_VIBRA_POWER,0,100};
__root const unsigned int V_P_2=100;
 
__root const CFG_HDR cfghdr1_3={CFG_UINT,LG_SET_VIBRA_COUNT,0,256};
__root const unsigned int V_C_2=10;
	 
__root const CFG_HDR cfghdr1_4={CFG_CHECKBOX,LG_SET_SOUND,0,0};
__root const int SOUND_2=1;
 
__root const CFG_HDR cfghdr1_5={CFG_UINT,LG_SET_SOUND_VOLUME,0,24};
__root const unsigned int S_VOL_2=5;

#ifdef ELKA
__root const CFG_HDR cfghdr1_6={CFG_CHECKBOX,LG_SET_SLI,0,0};
__root const int SLI_2=1;
#endif

__root const CFG_HDR cfghdr_m11={CFG_LEVEL,"",0,0};

//------------------------------------------------------------------------------
 
__root const CFG_HDR cfghdr_m20={CFG_LEVEL,LG_SET_PROFILE" 3",1,0};

__root const CFG_HDR cfghdr2_0={CFG_CHECKBOX,LG_SET_VIBRA,0,0};
__root const int VIBR_3=0;
 
__root const CFG_HDR cfghdr2_2={CFG_UINT,LG_SET_VIBRA_POWER,0,100};
__root const unsigned int V_P_3=100;
 
__root const CFG_HDR cfghdr2_3={CFG_UINT,LG_SET_VIBRA_COUNT,0,256};
__root const unsigned int V_C_3=10;
	 
__root const CFG_HDR cfghdr2_4={CFG_CHECKBOX,LG_SET_SOUND,0,0};
__root const int SOUND_3=1;
 
__root const CFG_HDR cfghdr2_5={CFG_UINT,LG_SET_SOUND_VOLUME,0,24};
__root const unsigned int S_VOL_3=5;

#ifdef ELKA
__root const CFG_HDR cfghdr2_6={CFG_CHECKBOX,LG_SET_SLI,0,0};
__root const int SLI_3=1;
#endif

__root const CFG_HDR cfghdr_m21={CFG_LEVEL,"",0,0};

//------------------------------------------------------------------------------
 
__root const CFG_HDR cfghdr_m30={CFG_LEVEL,LG_SET_PROFILE" 4",1,0};

__root const CFG_HDR cfghdr3_1={CFG_CHECKBOX,LG_SET_VIBRA,0,0};
__root const int VIBR_4=0;
 
__root const CFG_HDR cfghdr3_2={CFG_UINT,LG_SET_VIBRA_POWER,0,100};
__root const unsigned int V_P_4=100;
 
__root const CFG_HDR cfghdr3_3={CFG_UINT,LG_SET_VIBRA_COUNT,0,256};
__root const unsigned int V_C_4=10;
	 
__root const CFG_HDR cfghdr3_4={CFG_CHECKBOX,LG_SET_SOUND,0,0};
__root const int SOUND_4=1;
 
__root const CFG_HDR cfghdr3_5={CFG_UINT,LG_SET_SOUND_VOLUME,0,24};
__root const unsigned int S_VOL_4=5;

#ifdef ELKA
__root const CFG_HDR cfghdr3_6={CFG_CHECKBOX,LG_SET_SLI,0,0};
__root const int SLI_4=1;
#endif

__root const CFG_HDR cfghdr_m31={CFG_LEVEL,"",0,0};

//------------------------------------------------------------------------------
 
__root const CFG_HDR cfghdr_m40={CFG_LEVEL,LG_SET_PROFILE" 5",1,0};

__root const CFG_HDR cfghdr4_1={CFG_CHECKBOX,LG_SET_VIBRA,0,0};
__root const int VIBR_5=0;
 
__root const CFG_HDR cfghdr4_2={CFG_UINT,LG_SET_VIBRA_POWER,0,100};
__root const unsigned int V_P_5=100;
 
__root const CFG_HDR cfghdr4_3={CFG_UINT,LG_SET_VIBRA_COUNT,0,256};
__root const unsigned int V_C_5=10;
	 
__root const CFG_HDR cfghdr4_4={CFG_CHECKBOX,LG_SET_SOUND,0,0};
__root const int SOUND_5=1;
 
__root const CFG_HDR cfghdr4_5={CFG_UINT,LG_SET_SOUND_VOLUME,0,24};
__root const unsigned int S_VOL_5=5;

#ifdef ELKA
__root const CFG_HDR cfghdr4_6={CFG_CHECKBOX,LG_SET_SLI,0,0};
__root const int SLI_5=1;
#endif

__root const CFG_HDR cfghdr_m41={CFG_LEVEL,"",0,0};

//------------------------------------------------------------------------------
 
__root const CFG_HDR cfghdr_m50={CFG_LEVEL,LG_SET_PROFILE" 6",1,0};

__root const CFG_HDR cfghdr5_1={CFG_CHECKBOX,LG_SET_VIBRA,0,0};
__root const int VIBR_6=0;
 
__root const CFG_HDR cfghdr5_2={CFG_UINT,LG_SET_VIBRA_POWER,0,100};
__root const unsigned int V_P_6=100;
 
__root const CFG_HDR cfghdr5_3={CFG_UINT,LG_SET_VIBRA_COUNT,0,256};
__root const unsigned int V_C_6=10;
	 
__root const CFG_HDR cfghdr5_4={CFG_CHECKBOX,LG_SET_SOUND,0,0};
__root const int SOUND_6=1;
 
__root const CFG_HDR cfghdr5_5={CFG_UINT,LG_SET_SOUND_VOLUME,0,24};
__root const unsigned int S_VOL_6=5;

#ifdef ELKA
__root const CFG_HDR cfghdr5_6={CFG_CHECKBOX,LG_SET_SLI,0,0};
__root const int SLI_6=1;
#endif

__root const CFG_HDR cfghdr_m51={CFG_LEVEL,"",0,0};

//------------------------------------------------------------------------------
 
__root const CFG_HDR cfghdr_m60={CFG_LEVEL,LG_SET_PROFILE" 7",1,0};

__root const CFG_HDR cfghdr6_1={CFG_CHECKBOX,LG_SET_VIBRA,0,0};
__root const int VIBR_7=0;
 
__root const CFG_HDR cfghdr6_2={CFG_UINT,LG_SET_VIBRA_POWER,0,100};
__root const unsigned int V_P_7=100;
 
__root const CFG_HDR cfghdr6_3={CFG_UINT,LG_SET_VIBRA_COUNT,0,256};
__root const unsigned int V_C_7=10;
	 
__root const CFG_HDR cfghdr6_4={CFG_CHECKBOX,LG_SET_SOUND,0,0};
__root const int SOUND_7=1;
 
__root const CFG_HDR cfghdr6_5={CFG_UINT,LG_SET_SOUND_VOLUME,0,24};
__root const unsigned int S_VOL_7=5;

#ifdef ELKA
__root const CFG_HDR cfghdr6_6={CFG_CHECKBOX,LG_SET_SLI,0,0};
__root const int SLI_7=1;
#endif

__root const CFG_HDR cfghdr_m61={CFG_LEVEL,"",0,0};

//------------------------------------------------------------------------------
 
__root const CFG_HDR cfghdr_m70={CFG_LEVEL,LG_SET_PROFILE" 8",1,0};

__root const CFG_HDR cfghdr7_1={CFG_CHECKBOX,LG_SET_VIBRA,0,0};
__root const int VIBR_8=0;
 
__root const CFG_HDR cfghdr7_2={CFG_UINT,LG_SET_VIBRA_POWER,0,100};
__root const unsigned int V_P_8=100;
 
__root const CFG_HDR cfghdr7_3={CFG_UINT,LG_SET_VIBRA_COUNT,0,256};
__root const unsigned int V_C_8=10;
	 
__root const CFG_HDR cfghdr7_4={CFG_CHECKBOX,LG_SET_SOUND,0,0};
__root const int SOUND_8=1;
 
__root const CFG_HDR cfghdr7_5={CFG_UINT,LG_SET_SOUND_VOLUME,0,24};
__root const unsigned int S_VOL_8=5;

#ifdef ELKA
__root const CFG_HDR cfghdr7_6={CFG_CHECKBOX,LG_SET_SLI,0,0};
__root const int SLI_8=1;
#endif

__root const CFG_HDR cfghdr_m71={CFG_LEVEL,"",0,0};

//------------------------------------------------------------------------------

__root const CFG_HDR cfghdr_m001={CFG_LEVEL,"",0,0};

//------------------------------------------------------------------------------
