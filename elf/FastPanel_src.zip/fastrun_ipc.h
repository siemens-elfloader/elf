#define IPC_FASTRUN_NAME "FastRun"
#define IPC_UPDATE_STAT 1

