#ifndef _ELFGROOP_H_
#define _ELFGROOP_H_
void Sys();
void Int();
void Gam();
void Uti();
void Mlt();
#endif
