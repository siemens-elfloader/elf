#ifndef _SUBMAINMENU_H_
#define _SUBMAINMENU_H_
void GetSubMenu();
#endif
