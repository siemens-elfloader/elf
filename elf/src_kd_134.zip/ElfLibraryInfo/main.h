#ifndef _MAIN_H_
#define _MAIN_H_
void patch_rect(RECT*rc,int x,int y, int x2, int y2);
void patch_header(HEADER_DESC* head);
void patch_input(INPUTDIA_DESC* inp);
void GetInetInfo();
#endif
