#include "..\inc\cfg_items.h"
//������������

__root const CFG_HDR cfghdr0 = {CFG_CBOX, "Show copyright text at startup", 0, 2};
__root const int msg = 1;
__root const CFG_CBOX_ITEM cfgcbox2[2] = {"No", "Yes"};


__root const CFG_HDR cfghdr91 = {CFG_COORDINATES,"Clock position",0,0};
__root const unsigned int date_X0 = 30;
__root const unsigned int date_Y0 = 264;

__root const CFG_HDR cfghdr71={CFG_STR_WIN1251,"font1",0,63};
__root const char txt0[64]="";

__root const CFG_HDR cfghdr72={CFG_STR_WIN1251,"font2",0,63};
__root const char txt1[64]="";

__root const CFG_HDR cfghdr73={CFG_STR_WIN1251,"font3",0,63};
__root const char txt2[64]="";

__root const CFG_HDR cfghdr74={CFG_STR_WIN1251,"font4",0,63};
__root const char txt3[64]="";

__root const CFG_HDR cfghdr75={CFG_STR_WIN1251,"font5",0,63};
__root const char txt4[64]="";

__root const CFG_HDR cfghdr76={CFG_STR_WIN1251,"font6",0,63};
__root const char txt5[64]="";

__root const CFG_HDR cfghdr77={CFG_STR_WIN1251,"font7",0,63};
__root const char txt6[64]="";

__root const CFG_HDR cfghdr78={CFG_STR_WIN1251,"font8",0,63};
__root const char txt7[64]="";

__root const CFG_HDR cfghdr79={CFG_STR_WIN1251,"font9",0,63};
__root const char txt8[64]="";

__root const CFG_HDR cfghdr70={CFG_STR_WIN1251,"font10",0,63};
__root const char txt9[64]="";

__root const CFG_HDR cfghdr11 = {CFG_CBOX, "fullfont use", 0, 2};
__root const int fullfont = 0;
__root const CFG_CBOX_ITEM cfgcbox3[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr22 = {CFG_CBOX, "Align", 0, 3};
__root const int align = 0;
__root const CFG_CBOX_ITEM cfgcbox6[3] = {"Left", "Center", "Right"};

__root const CFG_HDR cfghdr2_2 = {CFG_UINT, "Pixels between letters", 0, 10};
__root const unsigned int space = 1;

__root const CFG_HDR cfghdr2_2z = {CFG_UINT, "font count", 0, 10};
__root const unsigned int max_font = 1;

