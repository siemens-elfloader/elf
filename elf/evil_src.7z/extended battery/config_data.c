#include "..\inc\cfg_items.h"
//������������
__root const CFG_HDR cfghdr0={CFG_CBOX,"Copyright",0,2};
__root const int ENA_HELLO_MSG=0;
__root const CFG_CBOX_ITEM cfgcbox0[2]={"Nop","Yap"};

__root const CFG_HDR cfghdr1 = {CFG_STR_UTF8, "font path", 0, 63};
__root const char fontpath[64] = "4:\\zbin\\img\\font\\";

__root const CFG_HDR cfghdr9 = {CFG_COORDINATES,"Text position",0,0};
__root const unsigned int date_X = 0;
__root const unsigned int date_Y = 170;

