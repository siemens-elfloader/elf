#include "..\inc\cfg_items.h"
//������������
//__root const CFG_HDR cfghdr0 = {CFG_UINT, "First in cycle blink time", 0, 50};
//__root const unsigned int lenght = 4;

//__root const CFG_HDR cfghdr1 = {CFG_UINT, "First in cycle Pause", 0, 50};
//__root const unsigned int lenght2 = 4;

//__root const CFG_HDR cfghdr2 = {CFG_UINT, "second in cycle blink time", 0, 50};
//__root const unsigned int lenght3 = 10;

//__root const CFG_HDR cfghdr3 = {CFG_UINT, "Second in cycle Pause", 0, 50};
//__root const unsigned int lenght4 = 4;

__root const CFG_HDR cfghdr0 = {CFG_CBOX, "Show copyright text at startup", 0, 2};
__root const int zajebalo = 1;
__root const CFG_CBOX_ITEM cfgcbox2[2] = {"No", "Yes"};

//__root const CFG_HDR cfghdr1 = {CFG_CBOX, "Is show nsd in xtask enabled?", 0, 2};
//__root const int zajebalo2 = 1;
//__root const CFG_CBOX_ITEM cfgcbox3[2] = {"No", "Yes"};

//__root const CFG_HDR cfghdr2={CFG_STR_UTF8,"xtask key",0,60};
//__root const char aija[128]="11";

//__root const CFG_HDR cfghdr5 = {CFG_CBOX, "Check events", 0, 4};
//__root const int sudinji = 1;
//__root const CFG_CBOX_ITEM cfgcbox0[4] = {"All", "1", "2", "3"};

//__root const CFG_HDR cfghdr16={CFG_STR_UTF8,"wav",0,63};
//__root const char sound_wav[64]="4:\\wav.wav";
