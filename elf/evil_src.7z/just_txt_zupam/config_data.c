#include "..\inc\cfg_items.h"
//������������

__root const CFG_HDR cfghdr0 = {CFG_CBOX, "Show copyright text at startup", 0, 2};
__root const int msg = 1;
__root const CFG_CBOX_ITEM cfgcbox2[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr121 = {CFG_CBOX, "show text", 0, 2};
__root const int TEKSTS0 = 1;
__root const CFG_CBOX_ITEM cfgcbox4[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr91 = {CFG_COORDINATES,"Text position",0,0};
__root const unsigned int date_X0 = 30;
__root const unsigned int date_Y0 = 264;

__root const CFG_HDR cfghdr71={CFG_STR_WIN1251,"Text1",0,63};
__root const char txt0[64]="";

__root const CFG_HDR cfghdr122 = {CFG_CBOX, "show text", 0, 2};
__root const int TEKSTS1 = 1;
__root const CFG_CBOX_ITEM cfgcbox41[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr92 = {CFG_COORDINATES,"Text position",0,0};
__root const unsigned int date_X1 = 30;
__root const unsigned int date_Y1 = 264;

__root const CFG_HDR cfghdr72={CFG_STR_WIN1251,"Text2",0,63};
__root const char txt1[64]="";

__root const CFG_HDR cfghdr123 = {CFG_CBOX, "show text", 0, 2};
__root const int TEKSTS2 = 1;
__root const CFG_CBOX_ITEM cfgcbox42[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr93 = {CFG_COORDINATES,"Text position",0,0};
__root const unsigned int date_X2 = 30;
__root const unsigned int date_Y2 = 264;

__root const CFG_HDR cfghdr73={CFG_STR_WIN1251,"Text3",0,63};
__root const char txt2[64]="";

__root const CFG_HDR cfghdr124 = {CFG_CBOX, "show text", 0, 2};
__root const int TEKSTS3 = 1;
__root const CFG_CBOX_ITEM cfgcbox43[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr94 = {CFG_COORDINATES,"Text position",0,0};
__root const unsigned int date_X3 = 30;
__root const unsigned int date_Y3 = 264;

__root const CFG_HDR cfghdr74={CFG_STR_WIN1251,"Text4",0,63};
__root const char txt3[64]="";

__root const CFG_HDR cfghdr125 = {CFG_CBOX, "show text", 0, 2};
__root const int TEKSTS4 = 1;
__root const CFG_CBOX_ITEM cfgcbox44[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr95 = {CFG_COORDINATES,"Text position",0,0};
__root const unsigned int date_X4 = 30;
__root const unsigned int date_Y4 = 264;

__root const CFG_HDR cfghdr75={CFG_STR_WIN1251,"Text5",0,63};
__root const char txt4[64]="";

__root const CFG_HDR cfghdr126 = {CFG_CBOX, "show text", 0, 2};
__root const int TEKSTS5 = 1;
__root const CFG_CBOX_ITEM cfgcbox45[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr96 = {CFG_COORDINATES,"Text position",0,0};
__root const unsigned int date_X5 = 30;
__root const unsigned int date_Y5 = 264;

__root const CFG_HDR cfghdr76={CFG_STR_WIN1251,"Text6",0,63};
__root const char txt5[64]="";

__root const CFG_HDR cfghdr127 = {CFG_CBOX, "show text", 0, 2};
__root const int TEKSTS6 = 1;
__root const CFG_CBOX_ITEM cfgcbox46[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr97 = {CFG_COORDINATES,"Text position",0,0};
__root const unsigned int date_X6 = 30;
__root const unsigned int date_Y6 = 264;

__root const CFG_HDR cfghdr77={CFG_STR_WIN1251,"Text7",0,63};
__root const char txt6[64]="";

__root const CFG_HDR cfghdr128 = {CFG_CBOX, "show text", 0, 2};
__root const int TEKSTS7 = 1;
__root const CFG_CBOX_ITEM cfgcbox47[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr98 = {CFG_COORDINATES,"Text position",0,0};
__root const unsigned int date_X7 = 30;
__root const unsigned int date_Y7 = 264;

__root const CFG_HDR cfghdr78={CFG_STR_WIN1251,"Text8",0,63};
__root const char txt7[64]="";

__root const CFG_HDR cfghdr129 = {CFG_CBOX, "show text", 0, 2};
__root const int TEKSTS8 = 1;
__root const CFG_CBOX_ITEM cfgcbox48[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr99 = {CFG_COORDINATES,"Text position",0,0};
__root const unsigned int date_X8 = 30;
__root const unsigned int date_Y8 = 264;

__root const CFG_HDR cfghdr79={CFG_STR_WIN1251,"Text9",0,63};
__root const char txt8[64]="";

__root const CFG_HDR cfghdr120 = {CFG_CBOX, "show text", 0, 2};
__root const int TEKSTS9 = 1;
__root const CFG_CBOX_ITEM cfgcbox49[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr90 = {CFG_COORDINATES,"Text position",0,0};
__root const unsigned int date_X9 = 30;
__root const unsigned int date_Y9 = 264;

__root const CFG_HDR cfghdr70={CFG_STR_WIN1251,"Text10",0,63};
__root const char txt9[64]="";

__root const CFG_HDR cfghdr8 = {CFG_STR_UTF8, "font path", 0, 63};
__root const char fontpath[64] = "4:\\";

__root const CFG_HDR cfghdr11 = {CFG_CBOX, "fullfont use", 0, 2};
__root const int fullfont = 0;
__root const CFG_CBOX_ITEM cfgcbox3[2] = {"No", "Yes"};

__root const CFG_HDR cfghdr22 = {CFG_CBOX, "Align", 0, 3};
__root const int align = 0;
__root const CFG_CBOX_ITEM cfgcbox6[3] = {"Left", "Center", "Right"};

__root const CFG_HDR cfghdr2_2 = {CFG_UINT, "Pixels between letters", 0, 10};
__root const unsigned int space = 1;

