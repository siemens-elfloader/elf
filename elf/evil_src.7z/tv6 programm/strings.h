WSHDR *ascii2ws(char *s);
char *ws2ascii(WSHDR *ws);
