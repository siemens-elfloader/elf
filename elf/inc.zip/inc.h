#define IPC_DEBUG_NAME "Debug"
#define IPC_COUT_NAME "COUT"
#define IPC_COUT 1

void COUTs(char string[]);

void COUTi(int number);
