
#define IPC_PAINTT_NAME "Paintt_"
#define IPC_VIEWP_NAME "Viewp_"

#define IPC_CHECK_DOUBLERUN	1
#define IPC_SAVE_FINISHED	2
#define IPC_SAVE_PART		3
