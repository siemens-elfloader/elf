#include "..\inc\swilib.h"
#include "draw.c"
//#include "relocated.c"


//#pragma swi_number=0x80CF: RamAlarm
//__swi __arm int *RamAlarm;


const int minus11=-11;

unsigned short maincsm_name_body[140];

int Cross_x=50,Cross_y=50,i=0;
int N_MENU=0;
int bat_x=80;
int time_x=110,time_y=40, time=0;
int Pusk=0;
unsigned int MAINCSM_ID = 0;
unsigned int MAINGUI_ID = 0;
//static const char black[]={0xFF,0xFF,0xFF,0x60};
typedef struct
{
  CSM_RAM csm;
  int gui_id;
}MAIN_CSM;

typedef struct
{
  GUI gui;
  WSHDR *ws1;
  WSHDR *ws2;
  int i1;
}MAIN_GUI;

int fl[48]/*={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}*/;
#define FLAG_NET_STD fl[0]
#define FLAG_NET_ADV fl[1]
#define FLAG_NET_DB  fl[2]
#define FLAG_NET_EXT fl[3]

#define FLAG_BAT_STD  fl[4]
#define FLAG_BAT_EXT  fl[5]
#define FLAG_BAT_CAP  fl[6]
#define FLAG_BAT_VOLT fl[7]

#define FLAG_CSM fl[8]
//#define FLAG_NET_STD fl[9]
//#define FLAG_NET_STD fl[10]

int start(char name[128])
{//������ ������
 WSHDR *ws;
 ws=AllocWS(256);
 str_2ws(ws,name,256);
 ExecuteFile(ws,0,0);
 FreeWS(ws);
 return(1);
}

char *shortcut(char cut[15])//������ ���������
{
int (*p) (void);
 p=(int(*)(void))GetFunctionPointer(cut);
 if(p!=NULL)
  (*p)();
 else
   ShowMSG(1,(int)"NULL pointer function!");
return 0;
}

#pragma inline=forced

int toupper(int c)
{
  if ((c>='a')&&(c<='z')) c+='A'-'a';
  return(c);
}

int strncmp_nocase(const char *s1,const char *s2,unsigned int n)
{
  int i;
  int c;
  while(!(i=(c=toupper(*s1++))-toupper(*s2++))&&(--n)) if (!c) break;
  return(i);
}
int MAMORY=0;
char buf[2048];
void OnRedraw(MAIN_GUI *data)
{ DrawBG();
 // DrawNetExt(2,2);
//  DrawNetStd(2,22);
  DrawNetAdv(2,42);
  DrawNetDb(2,62);
  DrawClock(time_x,time_y);
  //DrawBattStd(100,2);
  DrawBattCap(bat_x,2);
  DrawBattVolt(2,100);  
  DrawDialogs(80, 140);
  //DrawMenu(N_MENU); 
  if(time) DrawCross(Cross_x,Cross_y,RED);
  else  DrawCross(Cross_x,Cross_y,white);
  if(!DrawPuskk){
  if(Cross_x<=17 && Cross_y<=121) DrawPanel_w();
  if(Cross_x>=40 && Cross_x<=132 && Cross_y<=17)DrawPanel_h();
  else GBS_DelTimer(&timer);
    
  //������ ����� � ������ �������
   if(Cross_x>=0 && Cross_x<=20 && Cross_y>=0 && Cross_y <=20)
   { DrawName(2,1,1);
     DrawContur_w(0);
   }
   else if(Cross_x>=0 && Cross_x<=17 && Cross_y>=20 && Cross_y <=40)
   { DrawName(20,2,1);
     DrawContur_w(20);
    }
   else if(Cross_x>=0 && Cross_x<=17 && Cross_y>=40 && Cross_y <=60)
   { DrawName(40,3,1);
     DrawContur_w(40);
   }
   else if(Cross_x>=0 && Cross_x<=17 && Cross_y>=60 && Cross_y <=80)
   {   DrawName(60,4,1);
       DrawContur_w(60);
   }
   else if(Cross_x>=0 && Cross_x<=17 && Cross_y>=80 && Cross_y <=100)
   {   DrawName(80,5,1);
       DrawContur_w(80);
   }
   else if(Cross_x>=0 && Cross_x<=17 && Cross_y>=100 && Cross_y <=120)
   { DrawName(100,6,1);
     DrawContur_w(100);
   }
   //��������������
   else if(Cross_x>=40 && Cross_x<=60 && Cross_y>=0 && Cross_y <=17)
   { DrawName(40,1,0);
     DrawContur_h(40);
   }
   else if(Cross_x>=60 && Cross_x<=80 && Cross_y>=0 && Cross_y <=17)
   {   DrawName(60,2,0);
       DrawContur_h(60);
   }
   else if(Cross_x>=80 && Cross_x<=100 && Cross_y>=0 && Cross_y <=17)
   {   DrawName(80,3,0);
       DrawContur_h(80);
   }
   else if(Cross_x>=100 && Cross_x<=120 && Cross_y>=0 && Cross_y <=17)
   { DrawName(100,4,0);
     DrawContur_h(100);
   }
  }//!DrawPuskk
   if(MAMORY){
     DrawFreeMamory("0:\\Java\\jam\\Applications",100);
     //DrawFreeMamory("0:\\Sound",140);
   }
if(Cross_x>=0 && Cross_x <=25 && Cross_y>=159 && Cross_y <=172)Pusk=1;
if(Pusk && Cross_x>=0 && Cross_x <=80 && Cross_y>=75 && Cross_y <=172)//0,80,75,158 
DrawPusk(85,1);
//else Pusk=0;
//else GBS_DelTimer(&timer);
/*DrawPusk(50,2);
DrawPusk(65,3);
DrawPusk(80,4);
DrawPusk(95,5);
DrawPusk(110,6);*/
}

void onCreate(MAIN_GUI *data, void *(*malloc_adr)(int))
{
  data->gui.state=1;
}

void onClose(MAIN_GUI *data, void (*mfree_adr)(void *))
{
  data->gui.state=0;
}

void onFocus(MAIN_GUI *data, void *(*malloc_adr)(int), void (*mfree_adr)(void *))
{
  data->gui.state=2;
  DisableIDLETMR();
}

void onUnfocus(MAIN_GUI *data, void (*mfree_adr)(void *))
{
  if (data->gui.state!=2) return;
  data->gui.state=1;
}

int OnKey(MAIN_GUI *data, GUI_MSG *msg)
{ DirectRedrawGUI();

  if (msg->gbsmsg->msg==KEY_DOWN)
  {
    switch(msg->gbsmsg->submess)
    {
    case RED_BUTTON:
    case '0': return(1);
    case '*': {for (int i=7; i!=MAINCSM_ID-1; i++){ if (FindCSMbyID(i)!=NULL) CloseCSM(i);} ShowMSG(1,(int)"Killed");}  break;
    case GREEN_BUTTON: MakeVoiceCall("0",0x10,0x20C0);   break;
    case RIGHT_SOFT:   MAMORY=0;break;
    case LEFT_SOFT:    MAMORY=1;break;
    case '4': case LEFT_BUTTON:  if(Cross_x>0)  Cross_x--;if(time)if(time_x>=0)time_x--;;break;
    case '6': case RIGHT_BUTTON: if(Cross_x<131)Cross_x++;if(time) if(time_x<=132)time_x++;break;
    case '2': case UP_BUTTON:    if(Cross_y>0)  Cross_y--;if(time)if(time_y>=0)time_y--;break;
    case '8': case DOWN_BUTTON:  if(Cross_y<172)Cross_y++;if(time)if(time_y<=172)time_y++;break;
    case '5': case ENTER_BUTTON://if(time==1)time=0;
       if(Cross_x>=0 && Cross_x<=20 && Cross_y>=0 && Cross_y <=20)
       { start("0:\\zbin\\mc\\mc.elf");GBS_DelTimer(&timer);
         //DrawName(2,1);
       }
       else if(Cross_x>=0 && Cross_x<=20 && Cross_y>=20 && Cross_y <=40)
       { start("0:\\zbin\\utilities\\CfgEdit.elf");GBS_DelTimer(&timer);
         //DrawName(20,2);
       }
       else if(Cross_x>=0 && Cross_x<=20 && Cross_y>=40 && Cross_y <=60)
       {  shortcut("ORGZ_CALENDERMV");GBS_DelTimer(&timer);
         //DrawName(40,3);
       }
       else if(Cross_x>=0 && Cross_x<=20 && Cross_y>=60 && Cross_y <=80)
       { shortcut("ELSE_DEVELP_MNU");GBS_DelTimer(&timer);
          //DrawName(60,4);
       }
       else if(Cross_x>=0 && Cross_x<=20 && Cross_y>=80 && Cross_y <=100)
       {  start("0:\\zbin\\naticq\\naticq.elf");
        //  DrawName(80,5);
          GBS_DelTimer(&timer);
        }
     else if(Cross_x>=0 && Cross_x<=20 && Cross_y>=100 && Cross_y <=120)
     {  shortcut("FLSH_FLEXPLORER");
      // DrawName(100,6);
         GBS_DelTimer(&timer);
     }break;
 //   case RIGHT_BUTTON:if(N_MENU<=6)N_MENU++; else N_MENU=0;break;
   // case LEFT_BUTTON:if(N_MENU>=6)N_MENU--;  else N_MENU=6;break;
    //case UP_BUTTON:
    //case DOWN_BUTTON:
    case '1':  if(Cross_x>0)  Cross_y-=18;break;
    case '7':  if(Cross_y<172)Cross_y+=18;break;
    case '3':  time=0;break;
     
    
  }
  }
  if (msg->gbsmsg->msg==LONG_PRESS)
  {
    switch(msg->gbsmsg->submess)
    {
    case '4': case LEFT_BUTTON: 
          if(Cross_x>0) Cross_x-=5;
          if(time)if(time_x>=0)time_x-=5;
          break;
    case '6': case RIGHT_BUTTON: 
          if(Cross_x<131)Cross_x+=5;
          if(time) if(time_x<=132)time_x+=5;
          break;
    case '2': case UP_BUTTON: if(Cross_y>0)     Cross_y-=5;if(time)if(time_y>=0)time_y-=5;break;
    case '8': case DOWN_BUTTON: if(Cross_y<172) Cross_y+=5;if(time)if(time_y<=172)time_y+=5;break;
    case ENTER_BUTTON: case '5':      
      if(Cross_x>=time_x && Cross_x<=time_x+35 && Cross_y>=time_y && Cross_y<=time_y+10)
        time=!time;break;
      //if(time==1)time=0;      
    }
    
  }  
  return(0);
}
#ifdef NEWSGOLD
void onDestroy(MAIN_GUI *data, void (*mfree_adr)(void *))
{
  mfree_adr(data);
}
#else
extern void kill_data(void *p, void (*func_p)(void *));
#endif
int method8(void){return(0);}
int method9(void){return(0);}
const void * const gui_methods[11]={
  (void *)OnRedraw,	
  (void *)onCreate,	
  (void *)onClose,	
  (void *)onFocus,	
  (void *)onUnfocus,
  (void *)OnKey,	
   0,
  (void *)kill_data,	//Destroy
  (void *)method8,
  (void *)method9,
  0
};

const RECT Canvas={0,0,131,172};
void maincsm_oncreate(CSM_RAM *data)
{
  MAIN_GUI *main_gui=malloc(sizeof(MAIN_GUI));
  MAIN_CSM*csm=(MAIN_CSM*)data;
  zeromem(main_gui,sizeof(MAIN_GUI));
  main_gui->gui.canvas=(void *)(&Canvas);
  main_gui->gui.flag30=2;
  main_gui->gui.methods=(void *)gui_methods;
  main_gui->gui.item_ll.data_mfree=(void (*)(void *))mfree_adr();
  csm->csm.state=0;
  csm->csm.unk1=0;
  csm->gui_id=CreateGUI(main_gui);
  MAINGUI_ID=csm->gui_id;
}

void ElfKiller(void)
{
  extern void kill_data(void *p, void (*func_p)(void *));
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}

void maincsm_onclose(CSM_RAM *csm)
{ GBS_DelTimer(&timer);
  SUBPROC((void *)ElfKiller);
}

int maincsm_onmessage(CSM_RAM *data, GBS_MSG *msg)
{
  MAIN_CSM *csm=(MAIN_CSM*)data;
  if ((msg->msg==MSG_GUI_DESTROYED)&&((int)msg->data0==csm->gui_id))
  {
    csm->csm.state=-3;
  }
  return(1);
}

const struct
{
  CSM_DESC maincsm;
  WSHDR maincsm_name;
}MAINCSM =
{
  {
  maincsm_onmessage,
  maincsm_oncreate,
#ifdef NEWSGOLD
  0,
  0,
  0,
  0,
#endif
  maincsm_onclose,
  sizeof(MAIN_CSM),
  1,
  &minus11
  },
  {
    maincsm_name_body,
    NAMECSM_MAGIC1,
    NAMECSM_MAGIC2,
    0x0,
    139
  }
};

void UpdateCSMname(void)
{
  WSHDR *ws=AllocWS(256);
  wsprintf((WSHDR *)(&MAINCSM.maincsm_name),"exe");
  FreeWS(ws);
}


int main(char *exename, char *fname)
{
  char dummy[sizeof(MAIN_CSM)];
  MAINCSM_ID = CreateCSM(&MAINCSM.maincsm,dummy,0);
  UpdateCSMname();
  return 0;
}
