void EngadeClock();

