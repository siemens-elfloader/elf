
#define PageSTACK_SIZE (32)

char *PushPageToStack(void);
char *PopPageFromStack(void);
char *ForwardPageFromStack(void);
void FreePageStack(void);
void UpPageStack(void);




