#define IPC_BALLETMINI_NAME "BalletMini"
#define IPC_DATA_ARRIVED (1)
#define IPC_GOTO_URL (2)
#define IPC_GOTO_FILE (3)
#define IPC_BREAKD (4)
