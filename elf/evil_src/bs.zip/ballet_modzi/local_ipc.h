#ifndef _BALLET_IPC_H_
#define _BALLET_IPC_H_

#define IPC_BALLETMINI_NAME "BalletMini"
#define IPC_DATA_ARRIVED (1)
#define IPC_GOTO_URL (2)
#define IPC_GOTO_FILE (3)
#define IPC_BREAKD (4)

#endif /* _BALLET_IPC_H_ */
