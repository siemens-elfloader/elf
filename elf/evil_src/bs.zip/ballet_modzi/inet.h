#ifndef _INET_H_
#define _INET_H_

void SmartREDRAW(void);
int ParseSocketMsg(GBS_MSG *msg);
void StartINET(const char *url, char *fncache);
void StopINET(void);

#endif /* _INET_H_ */
