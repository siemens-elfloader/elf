#ifndef _DESTRUCTORS_H_
#define _DESTRUCTORS_H_

void FreeREFCACHEentry(REFCACHE *p);
void FreeREFCACHEtotal(REFCACHE **t);
void FreeRawText(VIEWDATA *vd);
void FreeDynImgList(VIEWDATA *vd);
void FreeViewData(VIEWDATA *vd);

#endif /* _DESTRUCTORS_H_ */
