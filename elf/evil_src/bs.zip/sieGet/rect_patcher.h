#ifndef _RECT_PATCHER_H_
#define _RECT_PATCHER_H_

void patch_rect(RECT * rc, int x, int y, int x2, int y2);
void patch_header(HEADER_DESC * head, int * icon, int lgp_id);
void patch_header_small(HEADER_DESC * head);
void patch_input(INPUTDIA_DESC * inp);

#endif
