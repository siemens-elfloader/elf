#define IPC_FASTRUN_NAME "FastRun_Night"
#define IPC_UPDATE_STAT 1

