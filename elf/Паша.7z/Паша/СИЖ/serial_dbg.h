#ifndef _SERIAL_DBG_H_
  #define _SERIAL_DBG_H_


void tx_str(char *str);

#endif
