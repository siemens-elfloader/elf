#define LANG_RU
//#define LANG_UA
//#define LANG_EN
