#ifndef _MESSAGE_CMDS_H_
  #define _MESSAGE_CMDS_H_

void DispSelectMenu();

#endif
