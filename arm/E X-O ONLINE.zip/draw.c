#include "c:\arm\inc\swilib.h"
#include "externs.h"

extern int img_count;
extern const char PICTURES_PATH[128];

char IMG_ROOT[128],
     IMG_F[128],
     IMG_M_C[128],
     IMG_G_C[128],
     IMG_L[128],
     IMG_X[128],
     IMG_O[128],
     IMG_T[128];

volatile int total_img;

IMGHDR *fon,
       *menu_cursor,
       *game_cursor,
       *logo,
       *draw_x,
       *draw_o,
       *table;

const char per_s_s[]="%s%s";

int _done[8]={23,23,23,23,23,23,23,23};
int error_count;
//int done_1=0;
void Load_IMG(int flag)
{
  //FSTATS stat;
  unsigned int ul;
  int f;
  switch(flag)
  {
    case 1:
   // GetFileStats(IMG_O,&stat,&ul);
  sprintf(IMG_O,per_s_s,PICTURES_PATH,"o.png");    
  if ((f=fopen(IMG_O,A_ReadOnly,P_READ,&ul))!=-1)
  {
    //if(stat.size>0)
    //{
    fclose(f,&ul);
    _done[1]=1;
    //ShowMSG(1,(int)"����������");
    //done_1=1;
    draw_o=CreateIMGHDRFromPngFile( IMG_O , 0); 
     //

    }
    else
    {//ShowMSG(1,(int)"�� ����������");
     _done[1]=0;error_count++;
      //done_1=0;
    }
    break;
    case 2:
    //GetFileStats(IMG_X,&stat,&ul);
    sprintf(IMG_X,per_s_s,PICTURES_PATH,"x.png");   
    if ((f=fopen(IMG_X,A_ReadOnly,P_READ,&ul))!=-1)//if(stat.size>0)
    {
    fclose(f,&ul);  
    _done[2]=1;
    draw_x=CreateIMGHDRFromPngFile( IMG_X , 0); 
    //fclose(f,&ul);
    }
    else
    {
    _done[2]=0;error_count++;
    }
    break;
    case 3:
    //GetFileStats(IMG_G_C,&stat,&ul);
    sprintf(IMG_G_C,per_s_s,PICTURES_PATH,"game_cursor.png");     
    if ((f=fopen(IMG_G_C,A_ReadOnly,P_READ,&ul))!=-1)//if(stat.size>0)
    {
      fclose(f,&ul);
    _done[3]=1;
    game_cursor=CreateIMGHDRFromPngFile( IMG_G_C , 0); 
    //fclose(f,&ul);
    }
    else
    {
     _done[3]=0;error_count++;
    }
    break;
    
    case 4:
      //GetFileStats(IMG_M_C,&stat,&ul);
      sprintf(IMG_M_C,per_s_s,PICTURES_PATH,"menu_cursor.png");
      X_MENU_CURSOR = ScreenW()/2 - GetImgWidth((int)IMG_M_C)/2;
      if ((f=fopen(IMG_M_C,A_ReadOnly,P_READ,&ul))!=-1)//if(stat.size>0)
    {
      fclose(f,&ul);
    _done[4]=1;
            menu_cursor=CreateIMGHDRFromPngFile( IMG_M_C , 0);
           // fclose(f,&ul);
    }
    else
    {
    _done[4]=0;error_count++;
    }
      
    break;
    case 5: 
     //GetFileStats(IMG_L,&stat,&ul);
      sprintf(IMG_L,per_s_s,PICTURES_PATH,"logo.png");
      X_LOGO = ScreenW()/2 - GetImgWidth((int)IMG_L)/2;
      Y_LOGO = (ScreenH()-YDISP)/2 - GetImgHeight((int)IMG_L)/2;
      
       if ((f=fopen(IMG_L,A_ReadOnly,P_READ,&ul))!=-1)//if(stat.size>0)
    {
      fclose(f,&ul);
    _done[5]=1;
    logo=CreateIMGHDRFromPngFile( IMG_L , 0); 
    //fclose(f,&ul);
    }
    else
    {
    _done[5]=0;  error_count++;
    }
    break;
    case 6:
    sprintf(IMG_T,per_s_s,PICTURES_PATH,"table.png");
      //GetFileStats(IMG_T,&stat,&ul);
     if ((f=fopen(IMG_T,A_ReadOnly,P_READ,&ul))!=-1)//if(stat.size>0)
    {
      fclose(f,&ul);
    _done[6]=1;  
    table=CreateIMGHDRFromPngFile( IMG_T , 0); 
    //fclose(f,&ul);
    }
    else
    {
    _done[6]=0;  error_count++;
    }
    break;
    case 7:
       ///GetFileStats(IMG_F,&stat,&ul);
     sprintf(IMG_F,per_s_s,PICTURES_PATH,"fon.png"); 
     if ((f=fopen(IMG_F,A_ReadOnly,P_READ,&ul))!=-1)//if(stat.size>0)
    {
      fclose(f,&ul);
    _done[7]=1;   
    fon=CreateIMGHDRFromPngFile( IMG_F , 0);
   // fclose(f,&ul);
    }else
    {
      _done[7]=0;  error_count++;
    }
     
    break;
  }
  
   
}


void DrwImg(IMGHDR *img, int x, int y, char *pen, char *brush)
{
  RECT rc;
  DRWOBJ drwobj;
  StoreXYWHtoRECT(&rc,x,y,img->w,img->h);
  SetPropTo_Obj5(&drwobj,&rc,0,img);
  SetColor(&drwobj,pen,brush);
  DrawObject(&drwobj);
}


