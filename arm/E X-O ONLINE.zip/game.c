#include "c:/arm/inc/swilib.h"
#include "externs.h"



// �� ������ ������, ����� �� ������, ����� �������� ����������� �����

#define		L_EMPTY		0
#define		L_KRESTIK   1
#define		L_NOLIK		2

// ����, 3 �� 3. ��. ����, ����� ���������� ����������� ��������



// ���������� �������

int win_pos[5][2] = {
	0,0, 0,2, 2,0, 2,2, 1,1
};

// ������ �����, ������� ����� �������� � ����������� �� �������� TableXod

char lab[3] = {'+', 'X', '0' };



int vict = 0;						// ����������, ��������� �� ����
int vp=0;							// ����� ������-����������
int g_over = 0;						// ����� �� �������, ���� ���������



// ���������, ������������� ����� ��������� 3-� ��������� �������
//
int eval_sum(int arg[3])
{
	int ret = 0;
	for (int i=0; i<3; i++) ret += arg[i];
	return ret;
};

// ���������, �������������� ��� �������� ������� � ����
//
int clear_arr(int arg[3])
{
	for (int i=0; i<3; i++) arg[i] = 0;
	return 0;
};

// ���������, ������������ ����� �������� �������� �������
//
int find_empty(int arg[3])
{
	for (int i=0; i<3;i++) 
		if (arg[i]==0) return i;
	return -1;
};

// ��������� �������� ������ ������-���� ������
//
int check_victory(int arg[3])
{
	int ret=0;
	for (int i=0; i<3; i++) ret += arg[i];
	// ���� ��� ���������, �� - ������
	if (ret == 3) { vict=1; return 1; };
	return 0;
};

// ���������, ��������� �� ������� ������� ��� ���������� ��������
// (�.�. ��� ���������/����� ����� � ����� � ���� ������ ������
//
// ���������:
// l_pl			- ����� ����������
// l_comp		- "����" �����
//
int check_comp_danger(int l_pl, int l_comp)
{
	// ����� ��������� � ��������� 2 3-� ���������� �������
	// � ��� ����� �������� ����� ��� ������ ��������������� �����
	// �.�.: ���� n-� ������� ����� - ��������������� �����, ��
	// n-� ������� ������� = 1, ����� = 0.

	int c[3]; clear_arr(c); // ������ ��� "����"
	int p[3]; clear_arr(p); // ������ ��� "�����"
	int cnt=0; // ������� ����������� ������ � �����

	// �������� ���� �������������� �����
	//
	for (int i=0; i<3; i++) {
		for (int j=0; j<3; j++) {
			// ���� ��������������� ������ �������� �����, �� ��������� �������������� ������
			if (TableXod[i][j]==l_pl) p[cnt]=1;
			if (TableXod[i][j]==l_comp) c[cnt]=1;
			cnt++; // ��������� ������� �����
		};

		// ���������, �� ������� �� ���-����
		if ((check_victory(p))||(check_victory(c))) return 1;
		
		// ���������, ��� �� �������������� ��������
		if ((eval_sum(p)==0)&&(eval_sum(c)==2)) {
			int empt=find_empty(c);
			TableXod[i][empt] = l_comp;
			return 0;
		};
		
		// �����, ������ ��� ������� ��������
		if ((eval_sum(p)==2)&&(eval_sum(c)==0)) {
				
			int empt=find_empty(p);
			TableXod[i][empt] = l_comp;
			return 0;
		};

		cnt = 0; // ������� �� ����� �����
		clear_arr(c); 
		clear_arr(p);

	};

	// ��� �� ��, ������ ��� ������������ �����
	for (int i=0; i<3; i++) {
		for (int j=0; j<3; j++) {
			if (TableXod[j][i]==l_pl) p[cnt]=1;
			if (TableXod[j][i]==l_comp) c[cnt]=1;
			cnt++;
		};
		if ((check_victory(p))||(check_victory(c))) return 1;
		
		if ((eval_sum(p)==0)&&(eval_sum(c)==2)) {
			int empt=find_empty(c);
			TableXod[i][empt] = l_comp;
			return 0;
		};

		if ((eval_sum(p)==2)&&(eval_sum(c)==0)) {
				
			int empt=find_empty(p);
			TableXod[empt][i] = l_comp;
			return 0;
		};

		cnt = 0;
		clear_arr(c);
		clear_arr(p);

	};

        int i;
	// �� �� ��� ������ ���������
	for (i=0; i<3; i++) {
		if (TableXod[i][i]==l_pl) p[cnt]=1;
		if (TableXod[i][i]==l_comp) c[cnt]=1;
		cnt++;
		
	};

	if ((check_victory(p))||(check_victory(c))) return 1;
		
		if ((eval_sum(p)==0)&&(eval_sum(c)==2)) {
			int empt=find_empty(c);
			TableXod[i][empt] = l_comp;
			return 0;
		};

		if ((eval_sum(p)==2)&&(eval_sum(c)==0)) {
					
			int empt=find_empty(p);
			TableXod[empt][empt] = l_comp;
			return 0;
		};
		
	cnt=0;
	clear_arr(c);
	clear_arr(p);

	// �� �� ��� ������ ���������
	for (i=0; i<3; i++) {
		if (TableXod[i][2-i]==l_pl) p[cnt]=1;
		if (TableXod[i][2-i]==l_comp) c[cnt]=1;
		cnt++;
		
	};

	if ((check_victory(p))||(check_victory(c))) return 1;
		
		if ((eval_sum(p)==0)&&(eval_sum(c)==2)) {
			int empt=find_empty(c);
			TableXod[i][empt] = l_comp;
			return 0;
		};
	
		if ((eval_sum(p)==2)&&(eval_sum(c)==0)) {
				
			int empt=find_empty(p);
			TableXod[empt][2-empt] = l_comp;
			return 0;
		};
	return 1;
};

// ���������, ������� ���������, �� ��������� �� ��� ���������� �������
//
int check_win_pos()
{
	int cnt=0;
	for (int i=0; i<5; i++) 
		if (TableXod[win_pos[i][0]][win_pos[i][1]]!=0) cnt++;
	if (cnt==5) return 0;
	return 1;
};

// ���������, �����������, �� ��������� �� ��� ����
//
int check_game_over()
{
	int cnt=0;
	for (int i=0; i<3; i++) {
		for (int j=0; j<3; j++) {
			if (TableXod[i][j]!=0) cnt++;
		}
	};

	if (cnt==3*3) { g_over=1; return 1; };
	return 0;
};

// ���������� ����������� ����������� ���������� ���������� ��������
//
// ���������:
// l			- ����� ������
//
int check_corn_pos(int l)
{
	// ���� ��������� ����������� ������
	int c = (TableXod[1][1] == 0);

	// �������� ��� �������� ����
	// ���� ��� ������ ���� ������
	if ((TableXod[0][0]==l)&(TableXod[2][0]==l)&(TableXod[1][0]==0)) {
		// ��������� ������ �������
		if (TableXod[0][2]==0) { TableXod[0][2]=l; return 1; }
		// ��������� ������ �������
		if (TableXod[2][2]==0) { TableXod[2][2]=l; return 1; }
		// ��������� �����������
		if (c) { TableXod[1][1]=l; return 1; }
	};

	// �� �� ��� ������� ����
	if ((TableXod[0][2]==l)&(TableXod[2][2]==l)&(TableXod[1][2]==0)) {
		if (TableXod[0][0]==0) { TableXod[0][0]=l; return 1; }
		if (TableXod[2][0]==0) { TableXod[2][0]=l; return 1; }
	};

	// ... ��� �����
	if ((TableXod[0][0]==l)&(TableXod[0][2]==l)&(TableXod[0][1]==0)) {
		if (TableXod[2][0]==0) { TableXod[2][0]=l; return 1; }
		if (TableXod[2][2]==0) { TableXod[2][2]=l; return 1; }
		if (c) { TableXod[1][1]=l; return 1; }
	};

	// ... � �������.
	if ((TableXod[2][0]==l)&(TableXod[2][2]==l)&(TableXod[2][1]==0)) {
		if (TableXod[0][0]==0) { TableXod[0][0]=l; return 1; }
		if (TableXod[2][0]==0) { TableXod[2][0]=l; return 1; }
		if (c) { TableXod[1][1]=l; return 1; }
	};

	return 0;
};

	

// ���������, ����������� ��� ����������
//
// ���������:
// l_pl			- ����� ����������
// l_comp		- "����" �����
//
int comp_step(int l_pl, int l_comp)
{
	
	// ������ ����� ���� ��������� �� ������� �������/���������� ��������
	// ���� ������� ���������, �� ����� �� ���������
	//if (!check_comp_danger(l_pl, l_comp)) return 0;

	
	int b=0; // ���������� �����
	
	// ���� ���� - ��� ���������� �� ���� �� ������
	while (!b) {
	
		// ���� ��� ������ ��������� - �����
		//if (check_game_over()) break;
		
		// ���� ��� ���������� ������� ������...
		if (!check_win_pos()) 
			for (int x=0; x<3; x++)
				for (int y=0; y<3; y++)
					if (TableXod[x][y]==0) {
						// ...�������� �� ������ ���������� ��������� ������
						TableXod[x][y]=l_comp;
						return 0;
					};

		// ��������� ����������� ���������� ���������� ��������
		//if (check_corn_pos(l_comp)) return 0;

		// ������� ������� ����� ��� ��������� ����������. 
		// ! ����� ������ � �������������
                TDate date;
                TTime time;
                GetDateTime(&date,&time);
                
		// ������� ������� � �������
		int rnd_seed = 3600*time.hour+60*time.min+time.sec;
		
		// ������������� ���������
		//srand(rnd_seed);
		int id; // ����� ����� �������� ����� ���������� �������

		// �������� ��������� �����.
		// ���� - ��� ����, ����� �� ����� ������ ���������� ����� �������
		for (int i=0; i<10; i++) {
			id = (int)(rnd_seed/6000); // ��������
		};
	

		// ���� ������ ������� �������, ����������
		if (id>4) id=4;

		
		// ��������, �� ������ �� ����������� �������
		
		if (TableXod[win_pos[id][0]][win_pos[id][1]]==0) {
			TableXod[win_pos[id][0]][win_pos[id][1]] = l_comp; // ���������...
			b=1; // ... � ����� �� �����
		};
		

		// ���� ����� ������� �� ��� ���, ���� �� ����� ��������� ���������� �������
		// ���� �� ����� ���� ����������� ��� ���������� ������ ���������
	};
	
	
	


	return 1;
};
//��� �� ������ ������
int RandXod(int anti_flag)
{
  int i=0, j=0;
  for(i=1;i<=6;i++)
  {  for(j=1;j<=5;j++)
     {  if (TableXod[i][j]==0)
        {   TableXod[i][j]=anti_flag;
            DoFring();
            return 0;
	}
     }
  }
  return 0;
}

int ReturnDes(int a)
{
     int i=0, j=0;
     while(a>10) 
     { 
           i-=10; //�������� ���������� ������
           j++;   //�������� ���������� ��������
     }
     return j;
}

int ReturnEd(int a)
{
     int i=0, j=0;
     while(a>10) 
     { 
           i-=10; //�������� ���������� ������
           j++;   //�������� ���������� ��������
     }
     return i;
}
  /*int tx_o_1=ReturnDes(one), tx_o_2=ReturnEd(one),
      tx_t_1=ReturnDes(two), tx_t_2=ReturnEd(two), 
      tx_fr_1=ReturnDes(fre), tx_fr_2=ReturnEd(fre), 
      tx_fo_1=ReturnDes(four), tx_fo_2=ReturnEd(four);*/
;/*int one, int two, int fre, int four, */

int Step_1_2_3_4( int tx_o_1, int tx_o_2, int tx_t_1, int tx_t_2, int tx_fr_1, int tx_fr_2, int tx_fo_1, int tx_fo_2,int flag, int anti_flag)
{
  if( TableXod[tx_o_1][tx_o_2]==flag && TableXod[tx_t_1][tx_t_2]==flag && TableXod[tx_fr_1][tx_fr_2]==flag ) 
  {
       if (TableXod[tx_fo_1][tx_fo_2]==0)
       {
			TableXod[tx_fo_1][tx_fo_2]=anti_flag;
                        DoFring();
                        return 1;
       }
       //else
       //{
       //        RandXod(anti_flag);
       //}
  }
  return 0;
}
void DoFring()
{
  FringFig(1);
  FringFig(2);
}


int Step_3_4_5_2( int tx_o_1, int tx_o_2, int tx_t_1, int tx_t_2, int tx_fr_1, int tx_fr_2, int tx_fo_1, int tx_fo_2,int flag, int anti_flag)
{
  if( TableXod[tx_o_1][tx_o_2]==flag && TableXod[tx_t_1][tx_t_2]==flag && TableXod[tx_fr_1][tx_fr_2]==flag ) 
  {
       if (TableXod[tx_fo_1][tx_fo_2]==0)
       {
			TableXod[tx_fo_1][tx_fo_2]=anti_flag;
                        DoFring();
                        return 1;
       }
       //else
       //{
       //        RandXod(anti_flag);
       //}
  }
  return 0;
}

int Step_1_2_3( int tx_o_1, int tx_o_2, int tx_t_1, int tx_t_2, int tx_fr_1, int tx_fr_2,int flag, int anti_flag)
{
  if( TableXod[tx_o_1][tx_o_2]==flag && TableXod[tx_t_1][tx_t_2]==flag ) 
  {
       if (TableXod[tx_fr_2][tx_fr_2]==0)
       {
			TableXod[tx_fr_2][tx_fr_2]=anti_flag;
                        DoFring();
                        return 1;
       }
       //else
       //{
       //        RandXod(anti_flag);
       //}
  }
  return 0;
}

/*int SmallStep()
{
  int i=0, j=0;
  for(i=1;i<=6;i++)
  {  for(j=1;j<=5;j++)
     {  if (TableXod[i][j]==1)
        {   
          if(TableXod[i+1][j+1]==1)
          {
            if(TableXod[i+1][j+1]==0)
            {
              TableXod[i+1][j+1]=1;
              DoFring();
              return 1;
            }
            else
              if(TableXod[i-1][j-1]==0)
            {
              TableXod[tx_fo_1][tx_fo_2]=anti_flag;
              DoFring();
              return 1;
            }
          
            DoFring();
            return 0;
	}
        else
          if(TableXod[i-1][j-1]==0)
          {
     }
  }
  return 0;
}
*/
int A_I2(int flag, int anti_flag)
{
  //�����������
  /*if(Step_1_2_3(1,1, 1,2, 1,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,1, 2,2, 2,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,1, 3,2, 3,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(4,1, 4,2, 4,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(5,1, 5,2, 5,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(6,1, 6,2, 6,3,  anti_flag, anti_flag)); else 
    
  if(Step_1_2_3(1,3, 1,4, 1,5,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,3, 2,4, 2,5,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,3, 3,4, 3,5,  anti_flag, anti_flag)); else
  if(Step_1_2_3(4,3, 4,4, 4,5,  anti_flag, anti_flag)); else
  if(Step_1_2_3(5,3, 5,4, 5,5,  anti_flag, anti_flag)); else
  if(Step_1_2_3(6,3, 6,4, 6,5,  anti_flag, anti_flag)); else  
    
  if(Step_1_2_3(1,1, 1,2, 1,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,1, 2,2, 2,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,1, 3,2, 3,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(4,1, 4,2, 4,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(5,1, 5,2, 5,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(6,1, 6,2, 6,4,  anti_flag, anti_flag)); else 
    
  if(Step_1_2_3(1,2, 1,4, 1,5,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,2, 2,4, 2,5,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,2, 3,4, 3,5,  anti_flag, anti_flag)); else
  if(Step_1_2_3(4,2, 4,4, 4,5,  anti_flag, anti_flag)); else
  if(Step_1_2_3(5,2, 5,4, 5,5,  anti_flag, anti_flag)); else
  if(Step_1_2_3(6,2, 6,4, 6,5,  anti_flag, anti_flag)); else 
    
  if(Step_1_2_3(1,2, 1,3, 1,4,  anti_flag, anti_flag)); else    
  if(Step_1_2_3(2,2, 2,3, 2,4,  anti_flag, anti_flag)); else  
  if(Step_1_2_3(3,2, 3,3, 3,4,  anti_flag, anti_flag)); else 
  if(Step_1_2_3(4,2, 4,3, 4,4,  anti_flag, anti_flag)); else 
  if(Step_1_2_3(5,2, 5,3, 5,4,  anti_flag, anti_flag)); else 
  if(Step_1_2_3(6,2, 6,3, 6,4,  anti_flag, anti_flag)); else 
    
  //�������������  
  // 1 2 3 =4= //
  if(Step_1_2_3(1,1, 2,1, 3,1,  anti_flag, anti_flag)); else
  if(Step_1_2_3(1,2, 2,2, 3,2,  anti_flag, anti_flag)); else
  if(Step_1_2_3(1,3, 2,3, 3,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(1,4, 2,4, 3,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(1,5, 2,5, 3,5,  anti_flag, anti_flag)); else
  // 2 3 4 =5= //
  if(Step_1_2_3(2,1, 3,1, 4,1,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,2, 3,2, 4,2,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,3, 3,3, 4,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,4, 3,4, 4,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,5, 3,5, 4,5,  anti_flag, anti_flag)); else  
  // 3 4 5 =6= //
  if(Step_1_2_3(3,1, 4,1, 5,1,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,2, 4,2, 5,2,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,3, 4,3, 5,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,4, 4,4, 5,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,5, 4,5, 5,5,  anti_flag, anti_flag)); else
    
  // 4 5 6 =3= //  
  if(Step_1_2_3(4,1, 5,1, 6,1,  anti_flag, anti_flag)); else
  if(Step_1_2_3(4,2, 5,2, 6,2,  anti_flag, anti_flag)); else
  if(Step_1_2_3(4,3, 5,3, 6,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(4,4, 5,4, 6,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(4,5, 5,5, 6,5,  anti_flag, anti_flag)); else  
  // 3 4 5 =2= //
  if(Step_1_2_3(3,1, 4,1, 5,1,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,2, 4,2, 5,2,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,3, 4,3, 5,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,4, 4,4, 5,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,5, 4,5, 5,5,  anti_flag, anti_flag)); else
  // 2 3 4 =1= //
  if(Step_1_2_3(2,1, 3,1, 4,1,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,2, 3,2, 4,2,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,3, 3,3, 4,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,4, 3,4, 4,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,5, 3,5, 4,5,  anti_flag, anti_flag)); else
  // 1 2 4 =3= //  
  if(Step_1_2_3(1,1, 2,1, 4,1,  anti_flag, anti_flag)); else
  if(Step_1_2_3(1,2, 2,2, 4,2,  anti_flag, anti_flag)); else
  if(Step_1_2_3(1,3, 2,3, 4,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(1,4, 2,4, 4,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(1,5, 2,5, 4,5,  anti_flag, anti_flag)); else  
  // 3 5 6 =4= //
  if(Step_1_2_3(3,1, 5,1, 6,1,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,2, 5,2, 6,2,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,3, 5,3, 6,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,4, 5,4, 6,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(3,5, 5,5, 6,5,  anti_flag, anti_flag)); else   
  // 2 4 5 =3= //
  if(Step_1_2_3(2,1, 4,1, 5,1,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,2, 4,2, 5,2,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,3, 4,3, 5,3,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,4, 4,4, 5,4,  anti_flag, anti_flag)); else
  if(Step_1_2_3(2,5, 4,5, 5,5,  anti_flag, anti_flag)); else 

   //���������
   if(Step_1_2_3(1,2, 2,3, 3,4,  anti_flag, anti_flag)); else
   if(Step_1_2_3(2,3, 3,4, 4,5,  anti_flag, anti_flag)); else
   if(Step_1_2_3(1,2, 3,4, 4,5,  anti_flag, anti_flag)); else
   if(Step_1_2_3(1,2, 3,4, 4,5,  anti_flag, anti_flag)); else
     
   if(Step_1_2_3(1,1, 2,2, 3,3,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(2,2, 3,3, 4,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(3,3, 4,4, 5,5,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(2,2, 3,3, 4,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(1,1, 2,2, 4,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(2,2, 3,3, 5,5,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(1,1, 3,3, 4,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(2,2, 3,3, 5,5,  anti_flag, anti_flag)); else 
     
   if(Step_1_2_3(2,1, 3,2, 4,3,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(3,2, 4,3, 5,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(4,3, 5,4, 6,5,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(3,2, 4,3, 5,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(2,1, 3,2, 5,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(3,2, 4,3, 6,5,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(2,1, 4,3, 5,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(3,2, 4,3, 6,5,  anti_flag, anti_flag)); else
     
   if(Step_1_2_3(3,1, 4,2, 5,3,  anti_flag, anti_flag)); else
   if(Step_1_2_3(4,2, 5,3, 6,4,  anti_flag, anti_flag)); else
   if(Step_1_2_3(3,1, 5,3, 6,4,  anti_flag, anti_flag)); else
   if(Step_1_2_3(3,1, 5,3, 6,4,  anti_flag, anti_flag)); else  
   // 2-�� ��������� 
   if(Step_1_2_3(6,2, 5,3, 4,4,  anti_flag, anti_flag)); else
   if(Step_1_2_3(5,3, 4,4, 3,5,  anti_flag, anti_flag)); else
   if(Step_1_2_3(6,2, 4,4, 3,5,  anti_flag, anti_flag)); else
   if(Step_1_2_3(6,2, 4,4, 3,5,  anti_flag, anti_flag)); else
     
   if(Step_1_2_3(4,1, 3,2, 2,3,  anti_flag, anti_flag)); else
   if(Step_1_2_3(3,2, 2,3, 1,4,  anti_flag, anti_flag)); else
   if(Step_1_2_3(4,1, 2,3, 1,4,  anti_flag, anti_flag)); else
   if(Step_1_2_3(4,1, 2,3, 1,4,  anti_flag, anti_flag)); else
     
   if(Step_1_2_3(6,1, 5,2, 4,3,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(5,2, 4,3, 3,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(4,3, 3,4, 2,5,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(5,2, 4,3, 3,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(6,1, 5,2, 3,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(5,2, 4,3, 2,5,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(6,1, 4,3, 3,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(5,2, 4,3, 2,5,  anti_flag, anti_flag)); else
     
   if(Step_1_2_3(5,1, 4,2, 3,3,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(4,2, 3,3, 2,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(3,3, 2,4, 1,5,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(4,2, 3,3, 2,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(5,1, 4,2, 2,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(4,2, 3,3, 1,5,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(5,1, 3,3, 2,4,  anti_flag, anti_flag)); else 
   if(Step_1_2_3(4,2, 3,3, 1,5,  anti_flag, anti_flag)); else*/
     
     //�����������
  // 1 2  3
  if(Step_1_2_3(1,1, 1,2, 1,3,  flag, anti_flag)); else
  if(Step_1_2_3(2,1, 2,2, 2,3,  flag, anti_flag)); else
  if(Step_1_2_3(3,1, 3,2, 3,3,  flag, anti_flag)); else
  if(Step_1_2_3(4,1, 4,2, 4,3,  flag, anti_flag)); else
  if(Step_1_2_3(5,1, 5,2, 5,3,  flag, anti_flag)); else
  if(Step_1_2_3(6,1, 6,2, 6,3,  flag, anti_flag)); else 
  // 2 3  4  
  if(Step_1_2_3(1,2, 1,3, 1,4,  flag, anti_flag)); else    
  if(Step_1_2_3(2,2, 2,3, 2,4,  flag, anti_flag)); else  
  if(Step_1_2_3(3,2, 3,3, 3,4,  flag, anti_flag)); else 
  if(Step_1_2_3(4,2, 4,3, 4,4,  flag, anti_flag)); else 
  if(Step_1_2_3(5,2, 5,3, 5,4,  flag, anti_flag)); else 
  if(Step_1_2_3(6,2, 6,3, 6,4,  flag, anti_flag)); else   
  // 3 4  5  
  if(Step_1_2_3(1,3, 1,4, 1,5,  flag, anti_flag)); else
  if(Step_1_2_3(2,3, 2,4, 2,5,  flag, anti_flag)); else
  if(Step_1_2_3(3,3, 3,4, 3,5,  flag, anti_flag)); else
  if(Step_1_2_3(4,3, 4,4, 4,5,  flag, anti_flag)); else
  if(Step_1_2_3(5,3, 5,4, 5,5,  flag, anti_flag)); else
  if(Step_1_2_3(6,3, 6,4, 6,5,  flag, anti_flag)); else  
  // 4 5  3  
  if(Step_1_2_3(1,4, 1,5, 1,3,  flag, anti_flag)); else
  if(Step_1_2_3(2,4, 2,5, 2,3,  flag, anti_flag)); else
  if(Step_1_2_3(3,4, 3,5, 3,3,  flag, anti_flag)); else
  if(Step_1_2_3(4,4, 4,5, 4,3,  flag, anti_flag)); else
  if(Step_1_2_3(5,4, 5,5, 5,3,  flag, anti_flag)); else
  if(Step_1_2_3(6,4, 6,5, 6,3,  flag, anti_flag)); else 
  // 3 4  2  
  if(Step_1_2_3(1,3, 1,4, 1,2,  flag, anti_flag)); else
  if(Step_1_2_3(2,3, 2,4, 2,2,  flag, anti_flag)); else
  if(Step_1_2_3(3,3, 3,4, 3,2,  flag, anti_flag)); else
  if(Step_1_2_3(4,3, 4,4, 4,2,  flag, anti_flag)); else
  if(Step_1_2_3(5,3, 5,4, 5,2,  flag, anti_flag)); else
  if(Step_1_2_3(6,3, 6,4, 6,2,  flag, anti_flag)); else 
  // 2 3  1 
  if(Step_1_2_3(1,2, 1,3, 1,1,  flag, anti_flag)); else    
  if(Step_1_2_3(2,2, 2,3, 2,1,  flag, anti_flag)); else  
  if(Step_1_2_3(3,2, 3,3, 3,1,  flag, anti_flag)); else 
  if(Step_1_2_3(4,2, 4,3, 4,1,  flag, anti_flag)); else 
  if(Step_1_2_3(5,2, 5,3, 5,1,  flag, anti_flag)); else 
  if(Step_1_2_3(6,2, 6,3, 6,1,  flag, anti_flag)); else    

  //�������������  
  // 1 2  3 
  if(Step_1_2_3(1,1, 2,1, 3,1,  flag, anti_flag)); else
  if(Step_1_2_3(1,2, 2,2, 3,2,  flag, anti_flag)); else
  if(Step_1_2_3(1,3, 2,3, 3,3,  flag, anti_flag)); else
  if(Step_1_2_3(1,4, 2,4, 3,4,  flag, anti_flag)); else
  if(Step_1_2_3(1,5, 2,5, 3,5,  flag, anti_flag)); else
  // 2 3 4 
  if(Step_1_2_3(2,1, 3,1, 4,1,  flag, anti_flag)); else
  if(Step_1_2_3(2,2, 3,2, 4,2,  flag, anti_flag)); else
  if(Step_1_2_3(2,3, 3,3, 4,3,  flag, anti_flag)); else
  if(Step_1_2_3(2,4, 3,4, 4,4,  flag, anti_flag)); else
  if(Step_1_2_3(2,5, 3,5, 4,5,  flag, anti_flag)); else  
  // 3 4 5
  if(Step_1_2_3(3,1, 4,1, 5,1,  flag, anti_flag)); else
  if(Step_1_2_3(3,2, 4,2, 5,2,  flag, anti_flag)); else
  if(Step_1_2_3(3,3, 4,3, 5,3,  flag, anti_flag)); else
  if(Step_1_2_3(3,4, 4,4, 5,4,  flag, anti_flag)); else
  if(Step_1_2_3(3,5, 4,5, 5,5,  flag, anti_flag)); else
  // 4 5 6 
  if(Step_1_2_3(4,1, 5,1, 6,1,  flag, anti_flag)); else
  if(Step_1_2_3(4,2, 5,2, 6,2,  flag, anti_flag)); else
  if(Step_1_2_3(4,3, 5,3, 6,3,  flag, anti_flag)); else
  if(Step_1_2_3(4,4, 5,4, 6,4,  flag, anti_flag)); else
  if(Step_1_2_3(4,5, 5,5, 6,5,  flag, anti_flag)); else  
  // 5 6 4
  if(Step_1_2_3(5,1, 6,1, 4,1,  flag, anti_flag)); else
  if(Step_1_2_3(5,2, 6,2, 4,2,  flag, anti_flag)); else
  if(Step_1_2_3(5,3, 6,3, 4,3,  flag, anti_flag)); else
  if(Step_1_2_3(5,4, 6,4, 4,4,  flag, anti_flag)); else
  if(Step_1_2_3(5,5, 6,5, 4,5,  flag, anti_flag)); else
  // 5 4 3
  if(Step_1_2_3(5,1, 4,1, 3,1,  flag, anti_flag)); else
  if(Step_1_2_3(5,2, 4,2, 3,2,  flag, anti_flag)); else
  if(Step_1_2_3(5,3, 4,3, 3,3,  flag, anti_flag)); else
  if(Step_1_2_3(5,4, 4,4, 3,4,  flag, anti_flag)); else
  if(Step_1_2_3(5,5, 4,5, 3,5,  flag, anti_flag)); else  
  // 4 3 2
  if(Step_1_2_3(4,1, 3,1, 2,1,  flag, anti_flag)); else
  if(Step_1_2_3(4,2, 3,2, 2,2,  flag, anti_flag)); else
  if(Step_1_2_3(4,3, 3,3, 2,3,  flag, anti_flag)); else
  if(Step_1_2_3(4,4, 3,4, 2,4,  flag, anti_flag)); else
  if(Step_1_2_3(4,5, 3,5, 2,5,  flag, anti_flag)); else  
  // 3 2 1
  if(Step_1_2_3(3,1, 2,1, 1,1,  flag, anti_flag)); else
  if(Step_1_2_3(3,2, 2,2, 1,2,  flag, anti_flag)); else
  if(Step_1_2_3(3,3, 2,3, 1,3,  flag, anti_flag)); else
  if(Step_1_2_3(3,4, 2,4, 1,4,  flag, anti_flag)); else
  if(Step_1_2_3(3,5, 2,5, 1,5,  flag, anti_flag)); else
    
   //���������
   if(Step_1_2_3(1,4, 2,3, 3,2,  flag, anti_flag)); else
   if(Step_1_2_3(2,3, 3,2, 4,1,  flag, anti_flag)); else
   if(Step_1_2_3(4,1, 3,2, 2,3,  flag, anti_flag)); else
   if(Step_1_2_3(2,3, 3,2, 1,4,  flag, anti_flag)); else
     
   if(Step_1_2_3(1,5, 2,4, 3,3,  flag, anti_flag)); else 
   if(Step_1_2_3(2,4, 3,3, 4,2,  flag, anti_flag)); else 
   if(Step_1_2_3(3,6, 4,2, 5,1,  flag, anti_flag)); else 
   if(Step_1_2_3(4,2, 5,1, 3,3,  flag, anti_flag)); else 
   if(Step_1_2_3(4,2, 3,3, 2,4,  flag, anti_flag)); else 
   if(Step_1_2_3(2,4, 3,3, 1,5,  flag, anti_flag)); else 
     
   if(Step_1_2_3(2,5, 3,4, 4,3,  flag, anti_flag)); else 
   if(Step_1_2_3(2,4, 4,3, 5,2,  flag, anti_flag)); else 
   if(Step_1_2_3(3,6, 5,2, 6,1,  flag, anti_flag)); else 
   if(Step_1_2_3(5,2, 6,1, 4,3,  flag, anti_flag)); else 
   if(Step_1_2_3(5,2, 4,3, 2,4,  flag, anti_flag)); else 
   if(Step_1_2_3(2,4, 4,3, 2,5,  flag, anti_flag)); else 
     
   if(Step_1_2_3(3,5, 4,4, 5,3,  flag, anti_flag)); else
   if(Step_1_2_3(4,4, 5,3, 6,2,  flag, anti_flag)); else
   if(Step_1_2_3(6,2, 5,3, 4,4,  flag, anti_flag)); else
   if(Step_1_2_3(4,4, 5,3, 3,5,  flag, anti_flag)); else 
     
   // 2-�� ��������� 
   if(Step_1_2_3(6,4, 5,3, 4,2,  flag, anti_flag)); else
   if(Step_1_2_3(5,3, 3,2, 3,1,  flag, anti_flag)); else
   if(Step_1_2_3(3,1, 3,2, 5,3,  flag, anti_flag)); else
   if(Step_1_2_3(5,3, 3,2, 6,4,  flag, anti_flag)); else
     
   if(Step_1_2_3(4,5, 3,4, 2,3,  flag, anti_flag)); else
   if(Step_1_2_3(3,4, 3,2, 1,2,  flag, anti_flag)); else
   if(Step_1_2_3(1,2, 3,2, 3,4,  flag, anti_flag)); else
   if(Step_1_2_3(3,4, 3,2, 4,5,  flag, anti_flag)); else
     
   if(Step_1_2_3(6,5, 5,4, 4,3,  flag, anti_flag)); else 
   if(Step_1_2_3(5,4, 4,3, 3,2,  flag, anti_flag)); else 
   if(Step_1_2_3(3,6, 3,2, 2,1,  flag, anti_flag)); else 
   if(Step_1_2_3(3,2, 2,1, 4,3,  flag, anti_flag)); else 
   if(Step_1_2_3(3,2, 4,3, 5,4,  flag, anti_flag)); else 
   if(Step_1_2_3(5,4, 4,3, 6,5,  flag, anti_flag)); else  
     
   if(Step_1_2_3(5,5, 4,4, 3,3,  flag, anti_flag)); else 
   if(Step_1_2_3(4,4, 3,3, 2,2,  flag, anti_flag)); else 
   if(Step_1_2_3(3,6, 2,2, 1,1,  flag, anti_flag)); else 
   if(Step_1_2_3(2,2, 1,1, 3,3,  flag, anti_flag)); else 
   if(Step_1_2_3(2,2, 3,3, 4,4,  flag, anti_flag)); else 
   if(Step_1_2_3(4,4, 3,3, 5,5,  flag, anti_flag)); else  
   
  //�����������
  if(Step_1_2_3_4(1,1, 1,2, 1,3, 1,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,1, 2,2, 2,3, 2,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,1, 3,2, 3,3, 3,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(4,1, 4,2, 4,3, 4,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(5,1, 5,2, 5,3, 5,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(6,1, 6,2, 6,3, 6,4, anti_flag, anti_flag)); else 
    
  if(Step_1_2_3_4(1,3, 1,4, 1,5, 1,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,3, 2,4, 2,5, 2,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,3, 3,4, 3,5, 3,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(4,3, 4,4, 4,5, 4,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(5,3, 5,4, 5,5, 5,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(6,3, 6,4, 6,5, 6,2, anti_flag, anti_flag)); else  
    
  if(Step_1_2_3_4(1,1, 1,2, 1,4, 1,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,1, 2,2, 2,4, 2,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,1, 3,2, 3,4, 3,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(4,1, 4,2, 4,4, 4,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(5,1, 5,2, 5,4, 5,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(6,1, 6,2, 6,4, 6,3, anti_flag, anti_flag)); else 
    
  if(Step_1_2_3_4(1,2, 1,4, 1,5, 1,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,2, 2,4, 2,5, 2,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,2, 3,4, 3,5, 3,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(4,2, 4,4, 4,5, 4,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(5,2, 5,4, 5,5, 5,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(6,2, 6,4, 6,5, 6,3, anti_flag, anti_flag)); else 
    
  if(Step_1_2_3_4(1,2, 1,3, 1,4, 1,5, anti_flag, anti_flag)); else    
  if(Step_1_2_3_4(2,2, 2,3, 2,4, 2,5, anti_flag, anti_flag)); else  
  if(Step_1_2_3_4(3,2, 3,3, 3,4, 3,5, anti_flag, anti_flag)); else 
  if(Step_1_2_3_4(4,2, 4,3, 4,4, 4,5, anti_flag, anti_flag)); else 
  if(Step_1_2_3_4(5,2, 5,3, 5,4, 5,5, anti_flag, anti_flag)); else 
  if(Step_1_2_3_4(6,2, 6,3, 6,4, 6,5, anti_flag, anti_flag)); else 
    
  //�������������  
  // 1 2 3 =4= //
  if(Step_1_2_3_4(1,1, 2,1, 3,1, 4,1, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(1,2, 2,2, 3,2, 4,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(1,3, 2,3, 3,3, 4,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(1,4, 2,4, 3,4, 4,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(1,5, 2,5, 3,5, 4,5, anti_flag, anti_flag)); else
  // 2 3 4 =5= //
  if(Step_1_2_3_4(2,1, 3,1, 4,1, 5,1, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,2, 3,2, 4,2, 5,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,3, 3,3, 4,3, 5,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,4, 3,4, 4,4, 5,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,5, 3,5, 4,5, 5,5, anti_flag, anti_flag)); else  
  // 3 4 5 =6= //
  if(Step_1_2_3_4(3,1, 4,1, 5,1, 6,1, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,2, 4,2, 5,2, 6,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,3, 4,3, 5,3, 6,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,4, 4,4, 5,4, 6,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,5, 4,5, 5,5, 6,5, anti_flag, anti_flag)); else
    
  // 4 5 6 =3= //  
  if(Step_1_2_3_4(4,1, 5,1, 6,1, 3,1, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(4,2, 5,2, 6,2, 3,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(4,3, 5,3, 6,3, 3,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(4,4, 5,4, 6,4, 3,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(4,5, 5,5, 6,5, 3,5, anti_flag, anti_flag)); else  
  // 3 4 5 =2= //
  if(Step_1_2_3_4(3,1, 4,1, 5,1, 2,1, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,2, 4,2, 5,2, 2,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,3, 4,3, 5,3, 2,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,4, 4,4, 5,4, 2,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,5, 4,5, 5,5, 2,5, anti_flag, anti_flag)); else
  // 2 3 4 =1= //
  if(Step_1_2_3_4(2,1, 3,1, 4,1, 1,1, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,2, 3,2, 4,2, 1,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,3, 3,3, 4,3, 1,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,4, 3,4, 4,4, 1,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,5, 3,5, 4,5, 1,5, anti_flag, anti_flag)); else
  // 1 2 4 =3= //  
  if(Step_1_2_3_4(1,1, 2,1, 4,1, 3,1, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(1,2, 2,2, 4,2, 3,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(1,3, 2,3, 4,3, 3,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(1,4, 2,4, 4,4, 3,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(1,5, 2,5, 4,5, 3,5, anti_flag, anti_flag)); else  
  // 3 5 6 =4= //
  if(Step_1_2_3_4(3,1, 5,1, 6,1, 4,1, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,2, 5,2, 6,2, 4,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,3, 5,3, 6,3, 4,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,4, 5,4, 6,4, 4,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(3,5, 5,5, 6,5, 4,5, anti_flag, anti_flag)); else   
  // 2 4 5 =3= //
  if(Step_1_2_3_4(2,1, 4,1, 5,1, 3,1, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,2, 4,2, 5,2, 3,2, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,3, 4,3, 5,3, 3,3, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,4, 4,4, 5,4, 3,4, anti_flag, anti_flag)); else
  if(Step_1_2_3_4(2,5, 4,5, 5,5, 3,5, anti_flag, anti_flag)); else 

   //���������
   if(Step_1_2_3_4(1,2, 2,3, 3,4, 4,5, anti_flag, anti_flag)); else
   if(Step_1_2_3_4(2,3, 3,4, 4,5, 1,2, anti_flag, anti_flag)); else
   if(Step_1_2_3_4(1,2, 3,4, 4,5, 2,3, anti_flag, anti_flag)); else
   if(Step_1_2_3_4(1,2, 3,4, 4,5, 2,3, anti_flag, anti_flag)); else
     
   if(Step_1_2_3_4(1,1, 2,2, 3,3, 4,4, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(2,2, 3,3, 4,4, 5,5, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(3,3, 4,4, 5,5, 2,2, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(2,2, 3,3, 4,4, 1,1, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(1,1, 2,2, 4,4, 3,3, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(2,2, 3,3, 5,5, 4,4, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(1,1, 3,3, 4,4, 2,2, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(2,2, 3,3, 5,5, 4,4, anti_flag, anti_flag)); else 
     
   if(Step_1_2_3_4(2,1, 3,2, 4,3, 5,4, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(3,2, 4,3, 5,4, 6,5, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(4,3, 5,4, 6,5, 3,2, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(3,2, 4,3, 5,4, 2,1, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(2,1, 3,2, 5,4, 4,3, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(3,2, 4,3, 6,5, 5,4, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(2,1, 4,3, 5,4, 3,2, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(3,2, 4,3, 6,5, 5,4, anti_flag, anti_flag)); else
     
   if(Step_1_2_3_4(3,1, 4,2, 5,3, 6,4, anti_flag, anti_flag)); else
   if(Step_1_2_3_4(4,2, 5,3, 6,4, 3,1, anti_flag, anti_flag)); else
   if(Step_1_2_3_4(3,1, 5,3, 6,4, 4,2, anti_flag, anti_flag)); else
   if(Step_1_2_3_4(3,1, 5,3, 6,4, 4,2, anti_flag, anti_flag)); else  
   // 2-�� ��������� 
   if(Step_1_2_3_4(6,2, 5,3, 4,4, 3,5, anti_flag, anti_flag)); else
   if(Step_1_2_3_4(5,3, 4,4, 3,5, 6,2, anti_flag, anti_flag)); else
   if(Step_1_2_3_4(6,2, 4,4, 3,5, 5,3, anti_flag, anti_flag)); else
   if(Step_1_2_3_4(6,2, 4,4, 3,5, 5,3, anti_flag, anti_flag)); else
     
   if(Step_1_2_3_4(4,1, 3,2, 2,3, 1,4, anti_flag, anti_flag)); else
   if(Step_1_2_3_4(3,2, 2,3, 1,4, 4,1, anti_flag, anti_flag)); else
   if(Step_1_2_3_4(4,1, 2,3, 1,4, 3,2, anti_flag, anti_flag)); else
   if(Step_1_2_3_4(4,1, 2,3, 1,4, 3,2, anti_flag, anti_flag)); else
     
   if(Step_1_2_3_4(6,1, 5,2, 4,3, 3,4, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(5,2, 4,3, 3,4, 2,5, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(4,3, 3,4, 2,5, 5,2, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(5,2, 4,3, 3,4, 6,1, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(6,1, 5,2, 3,4, 4,3, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(5,2, 4,3, 2,5, 3,4, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(6,1, 4,3, 3,4, 5,2, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(5,2, 4,3, 2,5, 3,4, anti_flag, anti_flag)); else
     
   if(Step_1_2_3_4(5,1, 4,2, 3,3, 2,4, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(4,2, 3,3, 2,4, 1,5, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(3,3, 2,4, 1,5, 4,2, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(4,2, 3,3, 2,4, 5,1, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(5,1, 4,2, 2,4, 3,3, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(4,2, 3,3, 1,5, 2,4, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(5,1, 3,3, 2,4, 4,2, anti_flag, anti_flag)); else 
   if(Step_1_2_3_4(4,2, 3,3, 1,5, 2,4, anti_flag, anti_flag)); else
     
      
  //�����������
  if(Step_1_2_3_4(1,1, 1,2, 1,3, 1,4, flag, anti_flag)); else
  if(Step_1_2_3_4(2,1, 2,2, 2,3, 2,4, flag, anti_flag)); else
  if(Step_1_2_3_4(3,1, 3,2, 3,3, 3,4, flag, anti_flag)); else
  if(Step_1_2_3_4(4,1, 4,2, 4,3, 4,4, flag, anti_flag)); else
  if(Step_1_2_3_4(5,1, 5,2, 5,3, 5,4, flag, anti_flag)); else
  if(Step_1_2_3_4(6,1, 6,2, 6,3, 6,4, flag, anti_flag)); else 
    
  if(Step_1_2_3_4(1,3, 1,4, 1,5, 1,2, flag, anti_flag)); else
  if(Step_1_2_3_4(2,3, 2,4, 2,5, 2,2, flag, anti_flag)); else
  if(Step_1_2_3_4(3,3, 3,4, 3,5, 3,2, flag, anti_flag)); else
  if(Step_1_2_3_4(4,3, 4,4, 4,5, 4,2, flag, anti_flag)); else
  if(Step_1_2_3_4(5,3, 5,4, 5,5, 5,2, flag, anti_flag)); else
  if(Step_1_2_3_4(6,3, 6,4, 6,5, 6,2, flag, anti_flag)); else  
    
  if(Step_1_2_3_4(1,1, 1,2, 1,4, 1,3, flag, anti_flag)); else
  if(Step_1_2_3_4(2,1, 2,2, 2,4, 2,3, flag, anti_flag)); else
  if(Step_1_2_3_4(3,1, 3,2, 3,4, 3,3, flag, anti_flag)); else
  if(Step_1_2_3_4(4,1, 4,2, 4,4, 4,3, flag, anti_flag)); else
  if(Step_1_2_3_4(5,1, 5,2, 5,4, 5,3, flag, anti_flag)); else
  if(Step_1_2_3_4(6,1, 6,2, 6,4, 6,3, flag, anti_flag)); else 
    
  if(Step_1_2_3_4(1,2, 1,4, 1,5, 1,3, flag, anti_flag)); else
  if(Step_1_2_3_4(2,2, 2,4, 2,5, 2,3, flag, anti_flag)); else
  if(Step_1_2_3_4(3,2, 3,4, 3,5, 3,3, flag, anti_flag)); else
  if(Step_1_2_3_4(4,2, 4,4, 4,5, 4,3, flag, anti_flag)); else
  if(Step_1_2_3_4(5,2, 5,4, 5,5, 5,3, flag, anti_flag)); else
  if(Step_1_2_3_4(6,2, 6,4, 6,5, 6,3, flag, anti_flag)); else 
    
  if(Step_1_2_3_4(1,2, 1,3, 1,4, 1,5, flag, anti_flag)); else    
  if(Step_1_2_3_4(2,2, 2,3, 2,4, 2,5, flag, anti_flag)); else  
  if(Step_1_2_3_4(3,2, 3,3, 3,4, 3,5, flag, anti_flag)); else 
  if(Step_1_2_3_4(4,2, 4,3, 4,4, 4,5, flag, anti_flag)); else 
  if(Step_1_2_3_4(5,2, 5,3, 5,4, 5,5, flag, anti_flag)); else 
  if(Step_1_2_3_4(6,2, 6,3, 6,4, 6,5, flag, anti_flag)); else 
    
  //�������������  
  // 1 2 3 =4= //
  if(Step_1_2_3_4(1,1, 2,1, 3,1, 4,1, flag, anti_flag)); else
  if(Step_1_2_3_4(1,2, 2,2, 3,2, 4,2, flag, anti_flag)); else
  if(Step_1_2_3_4(1,3, 2,3, 3,3, 4,3, flag, anti_flag)); else
  if(Step_1_2_3_4(1,4, 2,4, 3,4, 4,4, flag, anti_flag)); else
  if(Step_1_2_3_4(1,5, 2,5, 3,5, 4,5, flag, anti_flag)); else
  // 2 3 4 =5= //
  if(Step_1_2_3_4(2,1, 3,1, 4,1, 5,1, flag, anti_flag)); else
  if(Step_1_2_3_4(2,2, 3,2, 4,2, 5,2, flag, anti_flag)); else
  if(Step_1_2_3_4(2,3, 3,3, 4,3, 5,3, flag, anti_flag)); else
  if(Step_1_2_3_4(2,4, 3,4, 4,4, 5,4, flag, anti_flag)); else
  if(Step_1_2_3_4(2,5, 3,5, 4,5, 5,5, flag, anti_flag)); else  
  // 3 4 5 =6= //
  if(Step_1_2_3_4(3,1, 4,1, 5,1, 6,1, flag, anti_flag)); else
  if(Step_1_2_3_4(3,2, 4,2, 5,2, 6,2, flag, anti_flag)); else
  if(Step_1_2_3_4(3,3, 4,3, 5,3, 6,3, flag, anti_flag)); else
  if(Step_1_2_3_4(3,4, 4,4, 5,4, 6,4, flag, anti_flag)); else
  if(Step_1_2_3_4(3,5, 4,5, 5,5, 6,5, flag, anti_flag)); else
    
  // 4 5 6 =3= //  
  if(Step_1_2_3_4(4,1, 5,1, 6,1, 3,1, flag, anti_flag)); else
  if(Step_1_2_3_4(4,2, 5,2, 6,2, 3,2, flag, anti_flag)); else
  if(Step_1_2_3_4(4,3, 5,3, 6,3, 3,3, flag, anti_flag)); else
  if(Step_1_2_3_4(4,4, 5,4, 6,4, 3,4, flag, anti_flag)); else
  if(Step_1_2_3_4(4,5, 5,5, 6,5, 3,5, flag, anti_flag)); else  
  // 3 4 5 =2= //
  if(Step_1_2_3_4(3,1, 4,1, 5,1, 2,1, flag, anti_flag)); else
  if(Step_1_2_3_4(3,2, 4,2, 5,2, 2,2, flag, anti_flag)); else
  if(Step_1_2_3_4(3,3, 4,3, 5,3, 2,3, flag, anti_flag)); else
  if(Step_1_2_3_4(3,4, 4,4, 5,4, 2,4, flag, anti_flag)); else
  if(Step_1_2_3_4(3,5, 4,5, 5,5, 2,5, flag, anti_flag)); else
  // 2 3 4 =1= //
  if(Step_1_2_3_4(2,1, 3,1, 4,1, 1,1, flag, anti_flag)); else
  if(Step_1_2_3_4(2,2, 3,2, 4,2, 1,2, flag, anti_flag)); else
  if(Step_1_2_3_4(2,3, 3,3, 4,3, 1,3, flag, anti_flag)); else
  if(Step_1_2_3_4(2,4, 3,4, 4,4, 1,4, flag, anti_flag)); else
  if(Step_1_2_3_4(2,5, 3,5, 4,5, 1,5, flag, anti_flag)); else
  // 1 2 4 =3= //  
  if(Step_1_2_3_4(1,1, 2,1, 4,1, 3,1, flag, anti_flag)); else
  if(Step_1_2_3_4(1,2, 2,2, 4,2, 3,2, flag, anti_flag)); else
  if(Step_1_2_3_4(1,3, 2,3, 4,3, 3,3, flag, anti_flag)); else
  if(Step_1_2_3_4(1,4, 2,4, 4,4, 3,4, flag, anti_flag)); else
  if(Step_1_2_3_4(1,5, 2,5, 4,5, 3,5, flag, anti_flag)); else  
  // 3 5 6 =4= //
  if(Step_1_2_3_4(3,1, 5,1, 6,1, 4,1, flag, anti_flag)); else
  if(Step_1_2_3_4(3,2, 5,2, 6,2, 4,2, flag, anti_flag)); else
  if(Step_1_2_3_4(3,3, 5,3, 6,3, 4,3, flag, anti_flag)); else
  if(Step_1_2_3_4(3,4, 5,4, 6,4, 4,4, flag, anti_flag)); else
  if(Step_1_2_3_4(3,5, 5,5, 6,5, 4,5, flag, anti_flag)); else   
  // 2 4 5 =3= //
  if(Step_1_2_3_4(2,1, 4,1, 5,1, 3,1, flag, anti_flag)); else
  if(Step_1_2_3_4(2,2, 4,2, 5,2, 3,2, flag, anti_flag)); else
  if(Step_1_2_3_4(2,3, 4,3, 5,3, 3,3, flag, anti_flag)); else
  if(Step_1_2_3_4(2,4, 4,4, 5,4, 3,4, flag, anti_flag)); else
  if(Step_1_2_3_4(2,5, 4,5, 5,5, 3,5, flag, anti_flag)); else 

   //���������
   if(Step_1_2_3_4(1,2, 2,3, 3,4, 4,5, flag, anti_flag)); else
   if(Step_1_2_3_4(2,3, 3,4, 4,5, 1,2, flag, anti_flag)); else
   if(Step_1_2_3_4(1,2, 3,4, 4,5, 2,3, flag, anti_flag)); else
   if(Step_1_2_3_4(1,2, 3,4, 4,5, 2,3, flag, anti_flag)); else
     
   if(Step_1_2_3_4(1,1, 2,2, 3,3, 4,4, flag, anti_flag)); else 
   if(Step_1_2_3_4(2,2, 3,3, 4,4, 5,5, flag, anti_flag)); else 
   if(Step_1_2_3_4(3,3, 4,4, 5,5, 2,2, flag, anti_flag)); else 
   if(Step_1_2_3_4(2,2, 3,3, 4,4, 1,1, flag, anti_flag)); else 
   if(Step_1_2_3_4(1,1, 2,2, 4,4, 3,3, flag, anti_flag)); else 
   if(Step_1_2_3_4(2,2, 3,3, 5,5, 4,4, flag, anti_flag)); else 
   if(Step_1_2_3_4(1,1, 3,3, 4,4, 2,2, flag, anti_flag)); else 
   if(Step_1_2_3_4(2,2, 3,3, 5,5, 4,4, flag, anti_flag)); else 
     
   if(Step_1_2_3_4(2,1, 3,2, 4,3, 5,4, flag, anti_flag)); else 
   if(Step_1_2_3_4(3,2, 4,3, 5,4, 6,5, flag, anti_flag)); else 
   if(Step_1_2_3_4(4,3, 5,4, 6,5, 3,2, flag, anti_flag)); else 
   if(Step_1_2_3_4(3,2, 4,3, 5,4, 2,1, flag, anti_flag)); else 
   if(Step_1_2_3_4(2,1, 3,2, 5,4, 4,3, flag, anti_flag)); else 
   if(Step_1_2_3_4(3,2, 4,3, 6,5, 5,4, flag, anti_flag)); else 
   if(Step_1_2_3_4(2,1, 4,3, 5,4, 3,2, flag, anti_flag)); else 
   if(Step_1_2_3_4(3,2, 4,3, 6,5, 5,4, flag, anti_flag)); else
     
   if(Step_1_2_3_4(3,1, 4,2, 5,3, 6,4, flag, anti_flag)); else
   if(Step_1_2_3_4(4,2, 5,3, 6,4, 3,1, flag, anti_flag)); else
   if(Step_1_2_3_4(3,1, 5,3, 6,4, 4,2, flag, anti_flag)); else
   if(Step_1_2_3_4(3,1, 5,3, 6,4, 4,2, flag, anti_flag)); else  
   // 2-�� ��������� 
   if(Step_1_2_3_4(6,2, 5,3, 4,4, 3,5, flag, anti_flag)); else
   if(Step_1_2_3_4(5,3, 4,4, 3,5, 6,2, flag, anti_flag)); else
   if(Step_1_2_3_4(6,2, 4,4, 3,5, 5,3, flag, anti_flag)); else
   if(Step_1_2_3_4(6,2, 4,4, 3,5, 5,3, flag, anti_flag)); else
     
   if(Step_1_2_3_4(4,1, 3,2, 2,3, 1,4, flag, anti_flag)); else
   if(Step_1_2_3_4(3,2, 2,3, 1,4, 4,1, flag, anti_flag)); else
   if(Step_1_2_3_4(4,1, 2,3, 1,4, 3,2, flag, anti_flag)); else
   if(Step_1_2_3_4(4,1, 2,3, 1,4, 3,2, flag, anti_flag)); else
     
   if(Step_1_2_3_4(6,1, 5,2, 4,3, 3,4, flag, anti_flag)); else 
   if(Step_1_2_3_4(5,2, 4,3, 3,4, 2,5, flag, anti_flag)); else 
   if(Step_1_2_3_4(4,3, 3,4, 2,5, 5,2, flag, anti_flag)); else 
   if(Step_1_2_3_4(5,2, 4,3, 3,4, 6,1, flag, anti_flag)); else 
   if(Step_1_2_3_4(6,1, 5,2, 3,4, 4,3, flag, anti_flag)); else 
   if(Step_1_2_3_4(5,2, 4,3, 2,5, 3,4, flag, anti_flag)); else 
   if(Step_1_2_3_4(6,1, 4,3, 3,4, 5,2, flag, anti_flag)); else 
   if(Step_1_2_3_4(5,2, 4,3, 2,5, 3,4, flag, anti_flag)); else
     
   if(Step_1_2_3_4(5,1, 4,2, 3,3, 2,4, flag, anti_flag)); else 
   if(Step_1_2_3_4(4,2, 3,3, 2,4, 1,5, flag, anti_flag)); else 
   if(Step_1_2_3_4(3,3, 2,4, 1,5, 4,2, flag, anti_flag)); else 
   if(Step_1_2_3_4(4,2, 3,3, 2,4, 5,1, flag, anti_flag)); else 
   if(Step_1_2_3_4(5,1, 4,2, 2,4, 3,3, flag, anti_flag)); else 
   if(Step_1_2_3_4(4,2, 3,3, 1,5, 2,4, flag, anti_flag)); else 
   if(Step_1_2_3_4(5,1, 3,3, 2,4, 4,2, flag, anti_flag)); else 
   if(Step_1_2_3_4(4,2, 3,3, 1,5, 2,4, flag, anti_flag)); else
     
    RandXod(anti_flag);
  
 /*if( TableXod[1][2]==flag && TableXod[1][3]==flag && TableXod[1][4]==flag ) 
 {
       if (TableXod[1][5]==0)
       {
			TableXod[1][5]=anti_flag;
                        return 0;
       }
       else
       {
                RandXod(anti_flag);
       }
 }
 else
 if( TableXod[1][3]==flag && TableXod[1][4]==flag && TableXod[1][5]==flag ) 
 {
       if (TableXod[1][2]==0)
       {
			TableXod[1][2]=anti_flag;
                        return 0;
       }
       else
       {
                RandXod(anti_flag);
       }
 } 
 else
 {
         RandXod(anti_flag);
 }*/
    
 DoFring();
 
 return 0;
}

int A_I(int flag, int anti_flag)
{
 int i=0, j=0;
 if( TableXod[1][1]==flag && TableXod[1][2]==flag && TableXod[1][3]==flag ) TableXod[1][4]=anti_flag ; else
 
 if(  TableXod[1][2]==flag && TableXod[1][3]==flag && TableXod[1][4]==flag ) TableXod[1][5]=anti_flag ; else
 if(  TableXod[2][1]==flag && TableXod[2][2]==flag && TableXod[2][3]==flag ) TableXod[2][4]=anti_flag ; else
 if(  TableXod[2][2]==flag && TableXod[2][3]==flag && TableXod[2][4]==flag ) TableXod[2][5]=anti_flag ; else  
   
 if(  TableXod[3][1]==flag && TableXod[3][2]==flag && TableXod[3][3]==flag ) TableXod[3][4]=anti_flag ; else   
 if(  TableXod[3][2]==flag && TableXod[3][3]==flag && TableXod[3][4]==flag ) TableXod[3][5]=anti_flag ; else   
   
 if(  TableXod[4][1]==flag && TableXod[4][2]==flag && TableXod[4][3]==flag ) TableXod[4][4]=anti_flag ; else   
 if(  TableXod[4][2]==flag && TableXod[4][3]==flag && TableXod[4][4]==flag ) TableXod[4][5]=anti_flag ; else   
   
 if(  TableXod[5][1]==flag && TableXod[5][2]==flag && TableXod[5][3]==flag ) TableXod[5][4]=anti_flag ; else   
 if(  TableXod[5][2]==flag && TableXod[5][3]==flag && TableXod[5][4]==flag ) TableXod[5][5]=anti_flag ; else 
   
 if(  TableXod[6][1]==flag && TableXod[6][2]==flag && TableXod[6][3]==flag ) TableXod[6][4]=anti_flag ; else   
 if(  TableXod[6][2]==flag && TableXod[6][3]==flag && TableXod[6][4]==flag ) TableXod[6][5]=anti_flag ; else   
 //------------------------------------------------------------------------------   
 if(  TableXod[1][1]==flag && TableXod[2][1]==flag && TableXod[3][1]==flag ) TableXod[4][1]=anti_flag ; else
 if(  TableXod[2][1]==flag && TableXod[3][1]==flag && TableXod[4][1]==flag ) TableXod[5][1]=anti_flag ; else
 if(  TableXod[3][1]==flag && TableXod[4][1]==flag && TableXod[5][1]==flag ) TableXod[6][1]=anti_flag ; else
   
 if(  TableXod[1][2]==flag && TableXod[2][2]==flag && TableXod[3][2]==flag ) TableXod[4][2]=anti_flag ; else  
 if(  TableXod[2][2]==flag && TableXod[3][2]==flag && TableXod[4][2]==flag ) TableXod[5][2]=anti_flag ; else   
 if(  TableXod[3][2]==flag && TableXod[4][2]==flag && TableXod[5][2]==flag ) TableXod[6][2]=anti_flag ; else   
   
 if(  TableXod[1][3]==flag && TableXod[2][3]==flag && TableXod[3][3]==flag ) TableXod[4][3]=anti_flag ; else  
 if(  TableXod[2][3]==flag && TableXod[3][3]==flag && TableXod[4][3]==flag ) TableXod[5][3]=anti_flag ; else  
 if(  TableXod[3][3]==flag && TableXod[4][3]==flag && TableXod[5][3]==flag ) TableXod[6][3]=anti_flag ; else      
     
 if(  TableXod[1][4]==flag && TableXod[2][4]==flag && TableXod[3][4]==flag ) TableXod[4][4]=anti_flag ; else  
 if(  TableXod[2][4]==flag && TableXod[3][4]==flag && TableXod[4][4]==flag ) TableXod[5][4]=anti_flag ; else  
 if(  TableXod[3][4]==flag && TableXod[4][4]==flag && TableXod[5][4]==flag ) TableXod[6][4]=anti_flag ; else  
      
 if(  TableXod[1][5]==flag && TableXod[2][5]==flag && TableXod[3][5]==flag ) TableXod[4][5]=anti_flag ; else  
 if(  TableXod[2][5]==flag && TableXod[3][5]==flag && TableXod[4][5]==flag ) TableXod[5][5]=anti_flag ; else  
 if(  TableXod[3][5]==flag && TableXod[4][5]==flag && TableXod[5][5]==flag ) TableXod[6][5]=anti_flag ; else
 //------------------------------------------------------------------------------     
 if(  TableXod[1][2]==flag && TableXod[2][3]==flag && TableXod[3][4]==flag ) TableXod[4][5]=anti_flag ; else
 if(  TableXod[1][1]==flag && TableXod[2][2]==flag && TableXod[3][3]==flag ) TableXod[4][4]=anti_flag ; else
 if(  TableXod[2][2]==flag && TableXod[3][3]==flag && TableXod[4][4]==flag ) TableXod[5][5]=anti_flag ; else
 if(  TableXod[2][1]==flag && TableXod[3][2]==flag && TableXod[4][3]==flag ) TableXod[5][4]=anti_flag ; else
 if(  TableXod[3][2]==flag && TableXod[4][3]==flag && TableXod[5][4]==flag ) TableXod[6][5]=anti_flag ; else
 if(  TableXod[3][1]==flag && TableXod[4][2]==flag && TableXod[5][3]==flag ) TableXod[6][4]=anti_flag ; else
   
 if(  TableXod[6][2]==flag && TableXod[5][3]==flag && TableXod[4][4]==flag ) TableXod[3][5]=anti_flag ; else   
 if(  TableXod[6][1]==flag && TableXod[5][2]==flag && TableXod[4][3]==flag ) TableXod[3][4]=anti_flag ; else    
 if(  TableXod[5][2]==flag && TableXod[4][3]==flag && TableXod[3][4]==flag ) TableXod[2][5]=anti_flag ; else    
 if(  TableXod[5][1]==flag && TableXod[4][2]==flag && TableXod[3][3]==flag ) TableXod[2][4]=anti_flag ; else    
 if(  TableXod[4][2]==flag && TableXod[3][3]==flag && TableXod[2][4]==flag ) TableXod[1][5]=anti_flag ; else       
 if(  TableXod[4][1]==flag && TableXod[3][2]==flag && TableXod[2][3]==flag ) TableXod[1][4]=anti_flag ; else
 {
 //LAB:
   for(i=1;i<=6;i++)
   {
      for(j=1;j<=6;j++)
      {
           if (TableXod[i][j]==0 && TableXod[i][j]!=1 && TableXod[i][j]!=2) 
           {
			TableXod[i][j]=anti_flag;
                        return 0;
	   }
           else
           {
             i++;
             j++;
             if (TableXod[i][j]==0 && TableXod[i][j]!=1 && TableXod[i][j]!=2) 
             {
			TableXod[i][j]=anti_flag;
                        return 0;
	     }
             
           }
      }
   }
 }
 return 0; 
}



void KompXod()
{
  /*TDate date;
  TTime time;
  GetDateTime(&date,&time);
  int x,y,counter=0;
  int num=(time.hour+time.min+time.sec)%9;
  x=num/3; y=num-3*x;
  while(TableXod[x+1][y+1]!=0 && counter<15)
  {
    counter++;
    if(num>=15) num=-1;
    num=(num+5)%9;
    x=num/5; y=num-5*x;
  }
  if (counter==15) return;
  DoFring();
  if(MODE_FIGURE==1)
  {
    //DoFring();
    TableXod[x+1][y+1]=2;
  }
  else 
  if(MODE_FIGURE==2)
  {
    //DoFring();
    TableXod[x+1][y+1]=1;
  }
 */
  
  // ���������� �����
  
        //comp_step(1, 2);
	//comp_step(l_comp, l_pl);
	
  
  //count++;
   //DoFring();
   if(end_game==0 || nich==0)
   {
   switch(MODE_FIGURE)
   {
                  case 1: A_I2(1, 2); break;
                  case 2: A_I2(2, 1); break;
   }
   count++;
   }
  
  
}



// ������ ������� ��� �����
void DrawXorO(int flag,int x_p, int y_p)
{
  //int x=5; y=70;
  switch(flag)
  {
    case 1:// X
    {
     //DrwImg(draw_x, x+ 20*x_p, y+20*y_p, NULL,NULL);
      DrwImg(draw_x, x_p, y_p, NULL,NULL);
    }
    break;
   case 2: // O
   {
      DrwImg(draw_o, x_p,y_p, NULL,NULL);
   }
    break;
  }

}

void Count_1_gamer()
{
    if(summ_count1)
      {
      count_gamer_num_1++;
      summ_count1=0;
      }
}

void Count_2_gamer()
{
    if(summ_count2)
      {
      count_gamer_num_2++;
      summ_count2=0;
      }
}

void DrawIsGamerStatus(int flag)
{
  WSHDR *ws_res = AllocWS(128);
  ena_two_g=0, end_game=1;
  GBS_StopTimer(&timer);
  switch(flag)
  {
    case 1:
          if(MODE_GAME==2)
          {
                   if(MODE_FIGURE==1)
                   {
                           Count_1_gamer();
                           wsprintf(ws_res,perc_t,"������ ����� �������!");
                   }
                   else 
                   if(MODE_FIGURE==2)
                   {
                           Count_2_gamer();
                           wsprintf(ws_res,perc_t,"������ ����� �������!");
                   }
           }
           else
           {
                   switch(MODE_FIGURE)
                   {
                   case 1: Count_1_gamer();
                           wsprintf(ws_res,perc_t,"�� ��������!");
                           break;
                   case 2: Count_2_gamer();
                           wsprintf(ws_res,perc_t,"�� ���������!");
                           break;
                   }
            }
   break;
   case 2:
         if(MODE_GAME==2)
         {
                   switch(MODE_FIGURE)
                   {
                   case 1:  Count_2_gamer();
                            wsprintf(ws_res,perc_t,"������ ����� �������!");
                            break;
                   case 2:  Count_1_gamer();
                            wsprintf(ws_res,perc_t,"������ ����� �������!");
                            break;
                   }
         }
         else
         {
                   switch(MODE_FIGURE)
                   {
                   case 1:  Count_2_gamer();
                            wsprintf(ws_res,perc_t,"�� ���������!");
                            break;
                   case 2:  Count_1_gamer();
                            wsprintf(ws_res,perc_t,"�� ��������!");
                            break;
                   }
         }
   }   
  DrawString(ws_res,0,35,132,132,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
  FreeWS(ws_res);
}

int DrRF_R_U(int flag,int x,int y)
{
  isDrawFring=1;
  DrawIsGamerStatus(flag);
  for(int i=0;i<=3;i++)
  {
    DrawRoundedFrame(x+20*i, y+20*i, x+20*i+20, y+20*i + 20,0,0,0,GetPaletteAdrByColorIndex(1),FON_FRINF);

  }
     return 0;
}

int DrRF_R_D(int flag,int x,int y)
{
  isDrawFring=1;
  DrawIsGamerStatus(flag);
  for(int i=0;i<=3;i++)
  {
    DrawRoundedFrame(x-20*i, y+20*i, x-20*i+20, y+20*i + 20,0,0,0,GetPaletteAdrByColorIndex(1),FON_FRINF);

  }
     return 0;
}




int DrRF_DOWN(int flag,int x, int y)
{
  isDrawFring=1;
  DrawIsGamerStatus(flag);
  for(int i=0;i<=3;i++)
  {
    DrawRoundedFrame(x, y+20*i,x+20, y+20*i+20,0,0,0,GetPaletteAdrByColorIndex(1),FON_FRINF);

  }
     return 0;
}

int DrRF_LEFT(int flag,int x, int y)
{
  isDrawFring=1;
  DrawIsGamerStatus(flag);
  for(int i=0;i<=3;i++)
  {
    DrawRoundedFrame(x+20*i, y ,x+20*i+20, y+20,0,0,0,GetPaletteAdrByColorIndex(1),FON_FRINF);

  }
     return 0;
}


void FringFig(int flag)
{
 if(  TableXod[1][1]==flag && TableXod[1][2]==flag && TableXod[1][3]==flag && TableXod[1][4]==flag ) DrRF_DOWN(flag,5,70); else
 if(  TableXod[1][2]==flag && TableXod[1][3]==flag && TableXod[1][4]==flag && TableXod[1][5]==flag ) DrRF_DOWN(flag,5,90); else
   
 if(  TableXod[2][1]==flag && TableXod[2][2]==flag && TableXod[2][3]==flag && TableXod[2][4]==flag ) DrRF_DOWN(flag,25,70); else
 if(  TableXod[2][2]==flag && TableXod[2][3]==flag && TableXod[2][4]==flag && TableXod[2][5]==flag ) DrRF_DOWN(flag,25,90); else  
   
 if(  TableXod[3][1]==flag && TableXod[3][2]==flag && TableXod[3][3]==flag && TableXod[3][4]==flag ) DrRF_DOWN(flag,45,70); else   
 if(  TableXod[3][2]==flag && TableXod[3][3]==flag && TableXod[3][4]==flag && TableXod[3][5]==flag ) DrRF_DOWN(flag,45,90); else   
   
 if(  TableXod[4][1]==flag && TableXod[4][2]==flag && TableXod[4][3]==flag && TableXod[4][4]==flag ) DrRF_DOWN(flag,65,70); else   
 if(  TableXod[4][2]==flag && TableXod[4][3]==flag && TableXod[4][4]==flag && TableXod[4][5]==flag ) DrRF_DOWN(flag,65,90); else   
   
 if(  TableXod[5][1]==flag && TableXod[5][2]==flag && TableXod[5][3]==flag && TableXod[5][4]==flag ) DrRF_DOWN(flag,85,70); else   
 if(  TableXod[5][2]==flag && TableXod[5][3]==flag && TableXod[5][4]==flag && TableXod[5][5]==flag ) DrRF_DOWN(flag,85,90); else 
   
 if(  TableXod[6][1]==flag && TableXod[6][2]==flag && TableXod[6][3]==flag && TableXod[6][4]==flag ) DrRF_DOWN(flag,105,70); else   
 if(  TableXod[6][2]==flag && TableXod[6][3]==flag && TableXod[6][4]==flag && TableXod[6][5]==flag ) DrRF_DOWN(flag,105,90); else   
 //------------------------------------------------------------------------------   
 if(  TableXod[1][1]==flag && TableXod[2][1]==flag && TableXod[3][1]==flag && TableXod[4][1]==flag ) DrRF_LEFT(flag,5,70); else
 if(  TableXod[2][1]==flag && TableXod[3][1]==flag && TableXod[4][1]==flag && TableXod[5][1]==flag ) DrRF_LEFT(flag,25,70); else
 if(  TableXod[3][1]==flag && TableXod[4][1]==flag && TableXod[5][1]==flag && TableXod[6][1]==flag ) DrRF_LEFT(flag,45,70); else
   
 if(  TableXod[1][2]==flag && TableXod[2][2]==flag && TableXod[3][2]==flag && TableXod[4][2]==flag ) DrRF_LEFT(flag,5,90); else  
 if(  TableXod[2][2]==flag && TableXod[3][2]==flag && TableXod[4][2]==flag && TableXod[5][2]==flag ) DrRF_LEFT(flag,25,90); else   
 if(  TableXod[3][2]==flag && TableXod[4][2]==flag && TableXod[5][2]==flag && TableXod[6][2]==flag ) DrRF_LEFT(flag,45,90); else   
   
 if(  TableXod[1][3]==flag && TableXod[2][3]==flag && TableXod[3][3]==flag && TableXod[4][3]==flag ) DrRF_LEFT(flag,5,110); else  
 if(  TableXod[2][3]==flag && TableXod[3][3]==flag && TableXod[4][3]==flag && TableXod[5][3]==flag ) DrRF_LEFT(flag,25,110); else  
 if(  TableXod[3][3]==flag && TableXod[4][3]==flag && TableXod[5][3]==flag && TableXod[6][3]==flag ) DrRF_LEFT(flag,45,110); else      
     
 if(  TableXod[1][4]==flag && TableXod[2][4]==flag && TableXod[3][4]==flag && TableXod[4][4]==flag ) DrRF_LEFT(flag,5,130); else  
 if(  TableXod[2][4]==flag && TableXod[3][4]==flag && TableXod[4][4]==flag && TableXod[5][4]==flag ) DrRF_LEFT(flag,25,130); else  
 if(  TableXod[3][4]==flag && TableXod[4][4]==flag && TableXod[5][4]==flag && TableXod[6][4]==flag ) DrRF_LEFT(flag,45,130); else  
      
 if(  TableXod[1][5]==flag && TableXod[2][5]==flag && TableXod[3][5]==flag && TableXod[4][5]==flag ) DrRF_LEFT(flag,5,150); else  
 if(  TableXod[2][5]==flag && TableXod[3][5]==flag && TableXod[4][5]==flag && TableXod[5][5]==flag ) DrRF_LEFT(flag,25,150); else  
 if(  TableXod[3][5]==flag && TableXod[4][5]==flag && TableXod[5][5]==flag && TableXod[6][5]==flag ) DrRF_LEFT(flag,45,150); else
 //------------------------------------------------------------------------------     
 if(  TableXod[1][2]==flag && TableXod[2][3]==flag && TableXod[3][4]==flag && TableXod[4][5]==flag ) DrRF_R_U(flag,5,90); else
 if(  TableXod[1][1]==flag && TableXod[2][2]==flag && TableXod[3][3]==flag && TableXod[4][4]==flag ) DrRF_R_U(flag,5,70); else
 if(  TableXod[2][2]==flag && TableXod[3][3]==flag && TableXod[4][4]==flag && TableXod[5][5]==flag ) DrRF_R_U(flag,25,90); else
 if(  TableXod[2][1]==flag && TableXod[3][2]==flag && TableXod[4][3]==flag && TableXod[5][4]==flag ) DrRF_R_U(flag,25,70); else
 if(  TableXod[3][2]==flag && TableXod[4][3]==flag && TableXod[5][4]==flag && TableXod[6][5]==flag ) DrRF_R_U(flag,45,90); else
 if(  TableXod[3][1]==flag && TableXod[4][2]==flag && TableXod[5][3]==flag && TableXod[6][4]==flag ) DrRF_R_U(flag,45,70); else
   
 if(  TableXod[6][2]==flag && TableXod[5][3]==flag && TableXod[4][4]==flag && TableXod[3][5]==flag ) DrRF_R_D(flag,105,90); else   
 if(  TableXod[6][1]==flag && TableXod[5][2]==flag && TableXod[4][3]==flag && TableXod[3][4]==flag ) DrRF_R_D(flag,105,70); else    
 if(  TableXod[5][2]==flag && TableXod[4][3]==flag && TableXod[3][4]==flag && TableXod[2][5]==flag ) DrRF_R_D(flag,85,90); else    
 if(  TableXod[5][1]==flag && TableXod[4][2]==flag && TableXod[3][3]==flag && TableXod[2][4]==flag ) DrRF_R_D(flag,85,70); else    
 if(  TableXod[4][2]==flag && TableXod[3][3]==flag && TableXod[2][4]==flag && TableXod[1][5]==flag ) DrRF_R_D(flag,65,90); else       
 if(  TableXod[4][1]==flag && TableXod[3][2]==flag && TableXod[2][3]==flag && TableXod[1][4]==flag ) DrRF_R_D(flag,65,70); 
   
 //KompXod(); 
 
 
   
}


void WRITE_STEP(int flag){ TableXod[x_n_poz][y_n_poz]= flag;  }



void OXod(int flag)
{
  if(TableXod[1][1]==flag)DrawXorO(flag,5,70);// 1 1
  if(TableXod[1][2]==flag)DrawXorO(flag,5,90);// 1 2
  if(TableXod[1][3]==flag)DrawXorO(flag,5,110);// 1 3
  if(TableXod[1][4]==flag)DrawXorO(flag,5,130);// 1 4
  if(TableXod[1][5]==flag)DrawXorO(flag,5,150);// 1 4
  
  if(TableXod[2][1]==flag)DrawXorO(flag,25,70);// 2 1
  if(TableXod[2][2]==flag)DrawXorO(flag,25,90);// 2 2
  if(TableXod[2][3]==flag)DrawXorO(flag,25,110);// 2 3
  if(TableXod[2][4]==flag)DrawXorO(flag,25,130);// 2 4
  if(TableXod[2][5]==flag)DrawXorO(flag,25,150);// 2 4
  
  if(TableXod[3][1]==flag)DrawXorO(flag,45,70);// 3 1
  if(TableXod[3][2]==flag)DrawXorO(flag,45,90);// 3 2
  if(TableXod[3][3]==flag)DrawXorO(flag,45,110);// 3 3
  if(TableXod[3][4]==flag)DrawXorO(flag,45,130);// 3 4
  if(TableXod[3][5]==flag)DrawXorO(flag,45,150);// 3 4
  
  if(TableXod[4][1]==flag)DrawXorO(flag,65,70);// 4 1
  if(TableXod[4][2]==flag)DrawXorO(flag,65,90);// 4 2
  if(TableXod[4][3]==flag)DrawXorO(flag,65,110);// 4 3
  if(TableXod[4][4]==flag)DrawXorO(flag,65,130);// 4 4
  if(TableXod[4][5]==flag)DrawXorO(flag,65,150);// 4 4
  
  if(TableXod[5][1]==flag)DrawXorO(flag,85,70);// 5 1
  if(TableXod[5][2]==flag)DrawXorO(flag,85,90);// 5 2
  if(TableXod[5][3]==flag)DrawXorO(flag,85,110);// 5 3
  if(TableXod[5][4]==flag)DrawXorO(flag,85,130);// 5 4
  if(TableXod[5][5]==flag)DrawXorO(flag,85,150);// 5 4  
  
  if(TableXod[6][1]==flag)DrawXorO(flag,105,70);// 5 1
  if(TableXod[6][2]==flag)DrawXorO(flag,105,90);// 5 2
  if(TableXod[6][3]==flag)DrawXorO(flag,105,110);// 5 3
  if(TableXod[6][4]==flag)DrawXorO(flag,105,130);// 5 4
  if(TableXod[6][5]==flag)DrawXorO(flag,105,150);// 5 4   
}

  




void NullGame()
{
      for(int i=1;i<=6;i++)
      {
            for(int j=1;j<=6;j++)
            {
                    TableXod[i][j]=0;
            }
      }
}

