#define _WRITEMGS_H_
#ifdef _WRITEMGS_H_



#endif
