#include "C:\ARM\inc\swilib.h"
#include "externs.h"
#include "language.h"


typedef struct
{
  GUI gui;
}GAMEMENU_GUI;

unsigned int GAMEMENU_ID = 0;
//short shcr_w, shcr_h;


typedef struct
{
  CSM_RAM csm;
  int gui_id;
  char doscreen;
}GAMEMENU_CSM;

//int x8 ,y8;

extern void kill_data(void *p, void (*func_p)(void *));

#pragma inline
void patch_rect(RECT*rc,int x,int y, int x2, int y2)
{
  rc->x=x;
  rc->y=y;
  rc->x2=x2;
  rc->y2=y2;
}

/*IMGHDR screen_game={0,0,8,""};
void doscreen()
{
	char *ms=RamScreenBuffer();
	screen_game.w=scr_w+1;
	screen_game.h=scr_h+3;
	//mfn.bpnum=8;
	//if(mfn.bitmap) mfree(mfn.bitmap);
	screen_game.bitmap=malloc(scr_w*scr_h*2);
	memcpy(screen_game.bitmap, ms, scr_w*scr_h*2);
}
*/



void ShowRecMSG(char *msg)
{
   DrawRectangle(0, 0, 132 ,176,0,
		   black40,
		   black40);
  
   WSHDR *ws_shw_rec_msg = AllocWS(128);
    
   wsprintf(ws_shw_rec_msg,perc_t, msg );
   DrawString(ws_shw_rec_msg,0, 20 ,scr_w, scr_h, FONT, 2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
   
   wsprintf(ws_shw_rec_msg,perc_t, "�������" );
   DrawString(ws_shw_rec_msg,0, 165 ,scr_w, scr_h, FONT, 4,GetPaletteAdrByColorIndex(22),GetPaletteAdrByColorIndex(23));
       
   FreeWS(ws_shw_rec_msg);
  
}









//1 - �������
//2 - �����


void TimeGame()
{
  if (++theme_tick>2)
  {
    theme_tick=0;
    theme_time++;
    game_time_m_sec++;
    if(game_time_m_sec==60)game_time_m_sec=0;
    //DirectRedrawGUI();
    REDRAW();
  }
  GBS_StartTimerProc(&timer, 216/2, TimeGame);
}


void DrawWhoIsXod()
{
   WSHDR *ws_who = AllocWS(128);
   switch(MODE_GAME)
   {
   case 1:  
    if(!end_game)
          {
              wsprintf(ws_who,perc_t,"��� ���");
           }
     else
     if(!end_game) 
             wsprintf(ws_who,perc_t,"��� ���������");
   break;
   case 2:
   if(ena_two_g==1)
   {
         if(!end_game)
         {
            switch(MODE_FIGURE)
            {
                  case 1: wsprintf(ws_who,perc_t,"��� ������� ������ (�)"); break;
                  case 2: wsprintf(ws_who,perc_t,"��� ������� ������ (O)"); break;
            }
         }
   }
   else
   if(ena_two_g==2)
   {
         if(!end_game)
         {     
            switch(MODE_FIGURE)
            {
                  case 1: wsprintf(ws_who,perc_t,"��� ������� ������ (O)"); break;
                  case 2: wsprintf(ws_who,perc_t,"��� ������� ������ (X)"); break;
            }
         }
   }  
   break;

//case 1: 
     case 3:
     if(Online2xod==1)
     {
          if(!end_game)
          {
              wsprintf(ws_who,perc_t,"��� ���");
           }
     }
     else
     if(!end_game) 
             wsprintf(ws_who,perc_t,"��� ���������");
      
break;
   }
   
   DrawString(ws_who,2, 45 ,132,176,FONT,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));  
   
   FreeWS(ws_who);
}


void EndGame()
{
  WSHDR *ws_end = AllocWS(128);
  //if(MODE_GAME==2 || MODE_GAME==3)
  //{
    if( DrawXoid+count==30 || DrawXoid+DrawOoid==30 || DrawXoid+OnlainGameXod==30)
    {
      nich=end_game=1;
      GBS_StopTimer(&timer);  //���������� ������ ������� ����
      //count_gamer_num_1=count_gamer_num_2=0;
      wsprintf(ws_end,perc_t,"���� ���������! �����!");
    }
 // }
  DrawString(ws_end,2,45 ,132,132,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
  
FreeWS(ws_end);

}

/*int DrawTime()
{
  if(MODE_GAME!=3)
  {
  WSHDR *ws_time = AllocWS(128);  
  wsprintf(ws_time,"%t%d%t%d","�����: ",theme_time/60, ":", game_time_m_sec);
  DrawString(ws_time,2, 15 ,132,132,FONT,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
  FreeWS(ws_time);
  }
  return 0;
}*/
void DrawCount()
{
WSHDR *ws_info = AllocWS(128);

switch(MODE_GAME)
{
case 1: wsprintf(ws_info,mda_perc_tdtdtd,"�����: ",DrawXoid+count, " ����: ",count_gamer_num_1,":", count_gamer_num_2); break ;
case 2: wsprintf(ws_info,mda_perc_tdtdtd,"�����: ",DrawXoid+DrawOoid, "; ����: ",count_gamer_num_1,":", count_gamer_num_2); break;
case 3: wsprintf(ws_info,mda_perc_tdtdtd,"�����: ",DrawXoid+OnlainGameXod, " ����: ",count_gamer_num_1,":", count_gamer_num_2);
}
DrawString(ws_info,2, 5 ,132,132,FONT,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));

  wsprintf(ws_info,"%t%d%t%d","�����: ",theme_time/60, ":", game_time_m_sec);
  DrawString(ws_info,2, 15 ,132,132,FONT,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));


FreeWS(ws_info);
}

int DrawLevel()
{
  DrwImg(table, 5,70, NULL,NULL);
  //DrawSetka();
  //DrawSetka10x10();
  //DrawGameCur();
  DrawCount();
  //DrawTime();
  EndGame();
  
  return 0;
}



static int DrawFonCyr()
{
    int y=35 + 15*POZ_GMC;
    DrawRectangle(0, 0, 132 ,176,0,
		   black40,
		   black40);
    
    DrawRectangle(21, 48, 111 ,128,0,
		   grey0,
		   black0);
       
    DrawRoundedFrame( 23, y , 109 ,y+15,0,0,0,grey0,grey0);
    return 0;
}

/*int FreeIMG()
{
  if(screen_game)
  { 
       mfree(screen_game->bitmap);
       mfree(screen_game);
  }
  return 0;
}*/
//Redraw
static void OnRedraw(GAMEMENU_GUI *data)
{
  
  //main_gui->doscreen=1;
  
  /*if(data->doscreen)
  {
		mfree(screen_game.bitmap);
		doscreen();
		data->doscreen=0;
  }*/
  if (data->gui.state==2)
  {
    
    DrwImg(fon, 0,0, NULL,NULL);
    
    if(NewGame)
    {
  
   int X_G_C=20*x_n_poz -15;
   int Y_G_C=50+ 20*y_n_poz;
     
    //game_cur_x=45,
    //game_cur_y=150;  
   DrawLevel();
   //if(MODE_GAME==2 || MODE_GAME==3)
   DrawWhoIsXod();
   //Read_XOD(1);
   //Read_XOD(2);
   OXod(1);
   OXod(2);
   if(isDrawFring)
   {
    DoFring();
   }
   DrwImg(game_cursor, X_G_C, Y_G_C, NULL,NULL);
   //DrawG_Menu();
 
    }
    
    if(DrawGameMenu)
    {
    
       WSHDR *ws_g_menu = AllocWS(128);
       
      // DrwImg(&screen_game, 0,0, NULL,NULL);
       //DrawGameMenu=0;
       DrawFonCyr();
       
       if(nich==1 || end_game==1)
       {
         wsprintf(ws_g_menu,perc_t,"������� ���"); 
       }else
       wsprintf(ws_g_menu,perc_t,"����������"); 
       
       DrawString(ws_g_menu,0, 50 ,132,176,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));

       wsprintf(ws_g_menu,perc_t,"����������"); 
       DrawString(ws_g_menu,0, 65 ,132,176,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
       
       if(IsOnLineGame) wsprintf(ws_g_menu,perc_t,"�����������"); else
       wsprintf(ws_g_menu,perc_t,"��������� ����");
       DrawString(ws_g_menu,0, 80 ,132,176,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
       
       if(IsOnLineGame) wsprintf(ws_g_menu,perc_t,"���������"); else
       wsprintf(ws_g_menu,perc_t,"<�����>");
       DrawString(ws_g_menu,0, 95 ,132,176,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
       
       FreeWS(ws_g_menu);

   }
   /*if(ShowREC_MSG)
   {
     ShowRecMSG(recmsg);
   }*/
 }
}




 //Create
static void OnCreate(GAMEMENU_GUI *data,void *(*malloc_adr)(int))
{
      //GAMEMENU_CSM *csm=(GAMEMENU_CSM*)data;
       //data->doscreen=0;
       data->gui.state=1;
      //REDRAW();
}

//Close
void OnClose(GAMEMENU_GUI *data,void (*mfree_adr)(void *))
{
	data->gui.state=0;
}

//Focus
static void OnFocus(GAMEMENU_GUI *data,void *(*malloc_adr)(int),void (*mfree_adr)(void *))
{
	#ifdef ELKA
	DisableIconBar(1);
	#endif
	DisableIDLETMR();
	data->gui.state=2;
}

//Unfocus
static void OnUnfocus(GAMEMENU_GUI *data,void (*mfree_adr)(void *))
{
	#ifdef ELKA
	DisableIconBar(0);
	#endif
        if (data->gui.state!=2) return;
        data->gui.state=1;
}


void AntiXod()
{
  if((TableXod[x_n_poz][y_n_poz]==1)||(TableXod[x_n_poz][y_n_poz]==2))
  {
     WSHDR *ws_anti = AllocWS(128);
     wsprintf(ws_anti,perc_t,"�� �����!");
     DrawString(ws_anti,0,20,scr_w, scr_h, FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
     FreeWS(ws_anti);
           
  }
  else
  {
    switch(MODE_GAME)
    {
       case 1:  
                DrawXoid++;
                DoXod();
                
                if(end_game==0 || nich==0)KompXod();
        break;
        case 2:
        if(ena_two_g==1)
        {
                  DoXod();
                  DrawXoid++;
                  DoFring();
                  ena_two_g=2;
        }
        else
        if(ena_two_g==2)
        {
                  DoInvertXod();
                  DrawOoid++;
                  DoFring();
                  ena_two_g=1;
        } break;
        
        case 3:
        if(Online2xod==1)
        {
                 Online1xod=1;
                 DrawXoid++;
                 //Write_XOD(1);
                 WRITE_STEP(1);
                 SendXod(x_n_poz, y_n_poz);
                 Online2xod=0;
                 DoFring();
       } break;
  }
 }
}



 //OnKey
static int OnKey(GAMEMENU_GUI *data, GUI_MSG *msg)
{
if(Quit_Game_Giu)return 1;  
int sh=msg->gbsmsg->msg;
switch(sh)
 {
  case KEY_DOWN:
   switch(msg->gbsmsg->submess)
     {
      case RIGHT_SOFT:  if(DrawGameMenu) DrawGameMenu=0; else DrawGameMenu=1;  break;
      case LEFT_SOFT:   if(DrawGameMenu) DrawGameMenu=0; else DrawGameMenu=1;  break;
      case UP_BUTTON: case '2': 
      if(NewGame)
      {
               if(DrawGameMenu)
               { 
                        if(POZ_GMC==1)POZ_GMC=5;else POZ_GMC--;
               }
               else
               {
                        if(y_n_poz==1)y_n_poz=5;else y_n_poz--;
               }
      }
      break;
      case DOWN_BUTTON: case '8': 
      if(NewGame==1)
      {
               if(DrawGameMenu)
               { 
                        if(POZ_GMC==5)POZ_GMC=1;else POZ_GMC++;
               }
               else
               {
                        if(y_n_poz==5)y_n_poz=1;else y_n_poz++;
               }
      }
      break;
      case RIGHT_BUTTON:
      case '6':
      if(NewGame)
      {
               if(!DrawGameMenu)
               { 
                       if(x_n_poz    == 6)   x_n_poz=1;    else x_n_poz++;
               }
      }
      break;
      case LEFT_BUTTON:
      case '4':
      if(NewGame==1)
      {
              if(!DrawGameMenu)
              { 
                      if(x_n_poz    == 1) x_n_poz=6;      else x_n_poz--;
              }
      } 
      break;
      case ENTER_BUTTON: case '5':
       if(NewGame==1)
       {
           
          if(DrawGameMenu)
          {
               
          switch(POZ_GMC)
          {
          case 1: ResumeGame(); break;
          case 2: QuestResGame(); break;
          case 3: CloseGame();   break;
          case 4: if(IsOnLineGame)
          {
            DrawGameMenu=0; 
            WriteMsg();
          }
          break;
            
          }
        }
        else
        if(!end_game)AntiXod();
       }
       break;
      case '3':
	if(NewGame)
        {
              if(!DrawGameMenu)
              { 
                      
                      if(y_n_poz == 1) y_n_poz=5; else y_n_poz--;
                      if(x_n_poz == 6) x_n_poz=1; else x_n_poz++;
              }
        }
        break;
     case '9':
       if(NewGame)
        {
              if(!DrawGameMenu)
              { 
                      
                      if(y_n_poz==5)y_n_poz=1;else y_n_poz++;
                      if(x_n_poz == 6) x_n_poz=1; else x_n_poz++;
              }
        }
       break;
     case '1':
       if(NewGame)
        {
              if(!DrawGameMenu)
              { 
                      
                      if(y_n_poz==1)y_n_poz=5;else y_n_poz--;
                      if(x_n_poz    == 1) x_n_poz=6;      else x_n_poz--;
              }
        }
       break;
     case '7':
        if(NewGame)
        {
              if(!DrawGameMenu)
              { 
                      
                      if(y_n_poz==5)y_n_poz=1;else y_n_poz++;
                     if(x_n_poz    == 1) x_n_poz=6;      else x_n_poz--;
              }
        }
       
	//DirectRedrawGUI();
	//break;
        
  /* case KEY_UP:
	//movcr.st=1;
	switch(msg->gbsmsg->submess)
	{
         case '5': 
         case ENTER_BUTTON:
        
         break;  
         
	 case UP_BUTTON:
	 case DOWN_BUTTON:
	 case '2':
	 case '8':
		
	   break;
	 case RIGHT_BUTTON:
	 case LEFT_BUTTON:
         case '4':
	 case '6':
		
	   break;
          
	}*/
	//DirectRedrawGUI();
	break;
  }
  DirectRedrawGUI();
  
 }
return 0;
}

 // ����� �����-��
static int met0(void){return(0);}
static const void * const GAMEMENU_GUI_methods[11]={
  (void *)OnRedraw,
  (void *)OnCreate,
  (void *)OnClose,
  (void *)OnFocus,
  (void *)OnUnfocus,
  (void *)OnKey,
  0,
  (void *)kill_data, //method7, //Destroy
  (void *)met0,
  (void *)met0,
  0
};





void GAME_MENU_GUI()
{
  static const RECT Canvas={0,0,0,0};
  patch_rect((RECT*)&Canvas,0,0,ScreenW()-1,ScreenH()-1);
  StoreXYXYtoRECT((RECT*)&Canvas,0,0,ScreenW()-1,ScreenH()-1);
  GAMEMENU_GUI *main_gui=malloc(sizeof(GAMEMENU_GUI));
  zeromem(main_gui,sizeof(GAMEMENU_GUI));
  main_gui->gui.canvas=(void *)(&Canvas);
  main_gui->gui.methods=(void *)GAMEMENU_GUI_methods;
  main_gui->gui.item_ll.data_mfree=(void (*)(void *))mfree_adr();
  CreateGUI(main_gui);
      
}
