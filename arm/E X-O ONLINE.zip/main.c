#include "c:/arm/inc/swilib.h"
#include "c:/arm/inc/cfg_items.h"
#include "c:/arm/inc/pnglist.h"
#include "ints.h"
#include "NatICQ.h"
//#include "history.h"
#include "conf_loader.h"
//#include "mainmenu.h"
#include "main.h"
#include "language.h"
#include "e_x-o_ipc.h"
#include "c:/arm/inc/xtask_ipc.h"
#include "strings.h"
#include "cl_work.h"
#include "revision.h"
#include "externs.h"
#include "onkey.h"

#pragma inline
void patch_header(const HEADER_DESC* head)
{
  ((HEADER_DESC*)head)->rc.x=0;
  ((HEADER_DESC*)head)->rc.y=YDISP;
  ((HEADER_DESC*)head)->rc.x2=ScreenW()-1;
  ((HEADER_DESC*)head)->rc.y2=HeaderH()+YDISP-1;
}
#pragma inline
void patch_input(const INPUTDIA_DESC* inp)
{
  ((INPUTDIA_DESC*)inp)->rc.x=0;
  ((INPUTDIA_DESC*)inp)->rc.y=HeaderH()+1+YDISP;
  ((INPUTDIA_DESC*)inp)->rc.x2=ScreenW()-1;
  ((INPUTDIA_DESC*)inp)->rc.y2=ScreenH()-SoftkeyH()-1;
}

#ifndef NEWSGOLD
#define SEND_TIMER
#endif




#define USE_MLMENU

#define TMR_SECOND 216

//IPC
const char ipc_my_name[32]=IPC_EXO_NAME;
const char ipc_xtask_name[]=IPC_XTASK_NAME;
IPC_REQ gipc;




unsigned int MAINCSM_ID = 0;

unsigned int MAINGUI_ID = 0;

unsigned short maincsm_name_body[140];

extern volatile int total_img;




char elf_path[256];
int maincsm_id;
int maingui_id;

void SMART_REDRAW(void)
{
  int f;
  LockSched();
  f=IsGuiOnTop(maingui_id);
  UnlockSched();
  if (f) REDRAW();
}

//�� 10 ������
#define ACTIVE_TIME 360

//������������ ���������� ��������� � ����
#define MAXLOGMSG (20)


volatile int SENDMSGCOUNT;

int IsActiveUp=0;

//int Is_Vibra_Enabled;
unsigned int Is_Sounds_Enabled;
int Is_Show_Offline;
int Is_Show_Groups;



#define EOP -10
int CurrentStatus;
int CurrentXStatus;

WSHDR *ews;






const char percent_t[]="%t";
const char percent_d[]="%d";
const char empty_str[]="";
const char I_str[]="I";
const char x_status_change[]="X-Status change";

char logmsg[256];



volatile int silenthide;    //by BoBa 25.06.07
volatile int disautorecconect;	//by BoBa 10.07

extern const int Is_Vibra_Enabled;
unsigned int Is_Sounds_Enabled;
int Is_Show_Offline;
int Is_Show_Groups;
int CurrentStatus;
//int CurrentXStatus;
//int CurrentPrivateStatus;

//===================================================================
const char def_setting[]="%sdef_settings_%d";

void ReadDefSettings(void)
{
    //Is_Vibra_Enabled=0;
    Is_Sounds_Enabled=0;
    Is_Show_Offline=0;
    Is_Show_Groups=0;
    CurrentStatus=IS_ONLINE;
    //CurrentXStatus=0;
  
}
//==============================================================================
GBSTMR tmr_vibra;
volatile int vibra_count;

void start_vibra(void)
{
  extern const int VIBR_TYPE;
  void stop_vibra(void);
  if((Is_Vibra_Enabled)&&(!IsCalling()))
  {
    extern const unsigned int vibraPower;
    SetVibration(vibraPower);
    if(VIBR_TYPE)
      GBS_StartTimerProc(&tmr_vibra,TMR_SECOND>>2,stop_vibra);
    else
      GBS_StartTimerProc(&tmr_vibra,TMR_SECOND>>1,stop_vibra);
  }
}

void stop_vibra(void)
{
  extern const int VIBR_TYPE;
  SetVibration(0);
  if (--vibra_count)
  {
    if(VIBR_TYPE)
      GBS_StartTimerProc(&tmr_vibra,TMR_SECOND>>5,start_vibra);
    else
      GBS_StartTimerProc(&tmr_vibra,TMR_SECOND>>1,start_vibra);
  }
}



//=============================================================================================================================
//int cur_x=20; //cur_y=176/4-2, 
    //game_cur_x=45,
    //game_cur_y=150;
int count=0;  
int ena_msg=1, ena_msg_fal=1;
int DrawXoid=0,DrawOoid=0;
int eDrawInfo=0;
//int one_gamer=1,two_gamer=0, on_line_game=0;



int TableXod[7] [8]=
{
   {0,0,0,0,0,0,0,0},
   {0,0,0,0,0,0,0,0},
   {0,0,0,0,0,0,0,0},
   {0,0,0,0,0,0,0,0},
   {0,0,0,0,0,0,0,0},
   {0,0,0,0,0,0,0,0},   
   {0,0,0,0,0,0,0,0}
};

 
      


//==============================================================================
#define SCR 200
#define SCH 132

void DrawMainMenu(void)
{
     int y=22 + 20*POZ_MENU_CUR;
     DrwImg(menu_cursor,  X_MENU_CURSOR, y, NULL,NULL);
     WSHDR *ws_menu = AllocWS(128);

     if(MODE_GAME==3) 
     {
              if(IsOnLineGame)wsprintf(ws_menu,perc_t,"�����������");
              else wsprintf(ws_menu,perc_t,"�����������");
     }        else wsprintf(ws_menu,perc_t,"����� ����");
     DrawString(ws_menu,0,y_s_n_g ,SCH,SCR,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));

     if(SetFigure)
     {
              WSHDR *ws_figure = AllocWS(128);
              
              DrawRoundedFrame( 15, 44, 117 ,58,5,5,0, grey0, black0);
              
              DrawRoundedFrame( m_x, 44 , m_x+51 ,58,5,5,0,grey0,grey0);
              
              wsprintf(ws_figure,perc_t,"�������");
              
              DrawString(ws_figure,18,45 ,SCH,SCR,FONT,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
              
              wsprintf(ws_figure,perc_t,"�����");
              
              DrawString(ws_figure,70,45 ,SCH,SCR,FONT,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
              
             FreeWS(ws_figure);
 }
 
switch(MODE_GAME)
{
case 1: wsprintf(ws_menu,perc_t,"< ��������� >");    break;
case 2: wsprintf(ws_menu,perc_t,"< ��� ������ >");   break;
case 3: wsprintf(ws_menu,perc_t,"< ��-���� ���� >"); break;
}
DrawString(ws_menu,0,176/4+20 ,SCH,SCR,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,"���������");
DrawString(ws_menu,0,176/4+40 ,SCH,SCR,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,"� ����");
DrawString(ws_menu,0,176/4+60 ,SCH,SCR,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,"�����");
DrawString(ws_menu,0,176/4+80 ,SCH,SCR,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
FreeWS(ws_menu);
}




extern void Load_IMG(int flag);

void T_Load_IMG()
{
  img_count++;
  Load_IMG(img_count);
  DirectRedrawGUI();
  if(img_count>8)
  {
    GBS_DelTimer(&load_img);
    IsLoadGraph=0;
  }
  
  GBS_StartTimerProc(&load_img, 216/6, T_Load_IMG);
}



void DrawAbout()
{
   
   WSHDR *ws_about = AllocWS(256);
   DrwImg(fon, 0,0, NULL,NULL);
      
   wsprintf(ws_about,perc_t, LGP_ABOUT_ELF );
   DrawString(ws_about,0, 2 ,scr_w,scr_h,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
   
   wsprintf(ws_about,perc_t, LG_SHOWMSG_Ok );
   DrawString(ws_about,2, 165 ,scr_w,scr_h,FONT,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
   
   wsprintf(ws_about,perc_t, LGP_CLOSE );
   DrawString(ws_about,0, 165 ,scr_w,scr_h,FONT,4,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
   
   FreeWS(ws_about);
   
}






  



int SendXod(int x, int y)
{
  int xy;
  TPKT *p;
  if (connect_state==3)
  {
    xy=x*10+y;
    char send_txt[2];
    
    sprintf(send_txt, percent_d, xy);
    
    p=malloc(sizeof(PKT)+strlen(send_txt)+1);
    p->pkt.uin=UIN_2;
    p->pkt.type=T_SENDMSG;
    p->pkt.data_len=strlen(send_txt);
    strcpy(p->data,send_txt);
    SENDMSGCOUNT++;
    SUBPROC((void *)SendAnswer,0,p);
  }
  return 0;
}

int SendQuest(char *quest, int flag)
{
  TPKT *p;
  if (connect_state==3)
  {
    p=malloc(sizeof(PKT)+strlen(quest)+1);
    p->pkt.uin=UIN_2;
    p->pkt.type=T_SENDMSG;
    p->pkt.data_len=strlen(quest);
    strcpy(p->data,quest);
    SENDMSGCOUNT++;
    SUBPROC((void *)SendAnswer,0,p);
    switch(flag)
    {
    case 1: //ShowMSG(1,(int)"������ ���������� ���������!"); 
      ShowWMSG(0, "E X-O:\n\n������:\n\n'����������'\n\n���������!" ,11, GetPaletteAdrByColorIndex(0), GetPaletteAdrByColorIndex(23), 1);
    break;
    case 2:
      ShowWMSG(0, "E X-O:\n\n������:\n\n'������� ���'\n\n���������!" ,11, GetPaletteAdrByColorIndex(0), GetPaletteAdrByColorIndex(23), 1);
      break;
    }
    
  }
  return 0;
}



void DoXod()
{
        if(MODE_FIGURE==1)WRITE_STEP(1);
          //Write_XOD(1);
        else 
        if(MODE_FIGURE==2)WRITE_STEP(2);
          //Write_XOD(2);
}
void DoInvertXod()
{
        if(MODE_FIGURE==1)WRITE_STEP(2);//Write_XOD(2);
        else 
        if(MODE_FIGURE==2)WRITE_STEP(1);//Write_XOD(1);
}



void InitParametres()
{
  isDrawFring=0;
  TimeGame();
  Quit_Game_Giu=0;
  IsMenu=0, 
  NewGame=1,

  DrawXoid=0,
  DrawOoid=0,
  count=0,
  
  end_game=0,
  nich=0,
  isDrawFring=0;
  x_n_poz=3 , 
  y_n_poz=5,

  ena_two_g=1,
  ena_msg_fal=1,
  ena_msg=1,

  theme_tick=0, 
  theme_time=0, 
  
  draw_logo=0,
  game_time_m_sec=0;
}

void NullTableXod() // �������� ������� ����
{
  for(int i=1;i<=7;i++)
  for(int j=1;j<=8;j++)
  TableXod[i][j]=0;
}
//=============================================================================================================================

typedef struct
{
  CSM_RAM csm;
  int gui_id;
}MAIN_CSM;

typedef struct
{
  GUI gui;
  WSHDR *ws1;
  WSHDR *ws2;
  int i1;
}MAIN_GUI;



int RXstate=EOP; //-sizeof(RXpkt)..-1 - receive header, 0..RXpkt.data_len - receive data

TPKT RXbuf;
TPKT TXbuf;

int connect_state=0;

int sock=-1;

volatile unsigned long TOTALRECEIVED;
volatile unsigned long TOTALSENDED;
volatile unsigned long ALLTOTALRECEIVED;	//by BoBa 10.07
volatile unsigned long ALLTOTALSENDED;

volatile int sendq_l=0; //������ ������� ��� send
volatile void *sendq_p=NULL; //��������� �������

volatile int is_gprs_online=1;

GBSTMR reconnect_tmr;

extern void kill_data(void *p,void (*func_p)(void *));

void ElfKiller(void)
{
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}

int total_unread;

//===============================================================================================
#pragma inline
void patch_rect(RECT*rc,int x,int y, int x2, int y2)
{
  rc->x=x;
  rc->y=y;
  rc->x2=x2;
  rc->y2=y2;
}



volatile CLIST *cltop;

volatile unsigned int GROUP_CACHE; //������� ������ ��� ����������

volatile int contactlist_menu_id;

GBSTMR tmr_active;

volatile int edchat_id;


//GBSTMR tmr_ping;
int tenseconds_to_ping;

LOGQ *NewLOGQ(const char *s)
{
  LOGQ *p=malloc(sizeof(LOGQ)+1+strlen(s));
  zeromem(p,sizeof(LOGQ));
  strcpy(p->text,s);
  return p;
}

LOGQ *LastLOGQ(LOGQ **pp)
{
  LOGQ *q=*pp;
  if (q)
  {
    while(q->next) q=q->next;
  }
  return(q);
}

//���������� ���
void FreeLOGQ(LOGQ **pp)
{
  LOGQ *p=*pp;
  *pp=NULL; //����� �������
  while(p)
  {
    LOGQ *np=p->next;
    mfree(p);
    p=np;
  }
}




LOGQ *FindContactLOGQByAck(TPKT *p)
{
  CLIST *t;
  LockSched();
  t=FindContactByUin(p->pkt.uin);
  UnlockSched();
  unsigned int id=*((unsigned short*)(p->data));
  LOGQ *q;
  if (!t) return NULL;
  LockSched();
  q=t->log;
  while(q)
  {
    if (q->ID==id) break;
    q=q->next;
  }
  UnlockSched();
  return q;
}


/*void GetOnTotalContact(int group_id,int *_onlinetotal)
{
  CLIST *t;
  t=(CLIST *)&cltop;
  int online=0,total=0;
  while((t=t->next))
  {
    if(t->group==group_id && !t->isgroup)
    {
      total++;
      if (t->state!=0xFFFF) online++;
    }
  }
  _onlinetotal[0]=online;
  _onlinetotal[1]=total;
}*/


//===============================================================================================
int DNR_ID=0;
int DNR_TRIES=3;

extern const char NATICQ_HOST[];
extern const unsigned int NATICQ_PORT;

char hostname[128];
int host_counter = 0;

//---------------------------------------------------------------------------
const char *GetHost(int cnt, const char *str, char *buf)
{
  const char *tmp = str, *begin, *end;
  if(cnt)
  {
    for(;cnt;cnt--)
    {
      for(;*str!=';' && *str!=' ' && *str!='\x0D' && *str!='\x0A' && *str; str++);
      if(!*str) str = tmp;
      for(;(*str==';' || *str==' ' || *str=='\x0D' || *str=='\x0A') && *str; str++);
      if(!*str) str = tmp;
    }
  }
  tmp = buf;
  begin = str;
  for(;*str!=';' && *str!=':' && *str!=' ' && *str!='\x0D' && *str!='\x0A' && *str; str++);
  end = str;
  for(;begin<end; *buf = *begin, begin++, buf++);
  *buf = 0;
  return tmp;
}
//---------------------------------------------------------------------------
int atoi(char *attr)
{
  int ret=0;
  int neg=1;
  for (int k=0; ; k++)
  {
    if ( attr[k]>0x2F && attr[k]<0x3A) {ret=ret*10+attr[k]-0x30;} else { if ( attr[k]=='-') {neg=-1;} else {return(ret*neg);}}
  }
}
//---------------------------------------------------------------------------
int GetPort(int cnt, const char *str)
{
  const char *tmp = str;
  char numbuf[6], numcnt = 0;
  if(cnt)
  {
    for(;cnt;cnt--)
    {
      for(;*str!=';' && *str!=' ' && *str!='\x0D' && *str!='\x0A' && *str; str++);
      if(!*str) str = tmp;
      for(;(*str==';' || *str==' ' || *str=='\x0D' || *str=='\x0A') && *str; str++);
      if(!*str) str = tmp;
    }
  }
  for(;*str!=';' && *str!=':' && *str!=' ' && *str!='\x0D' && *str!='\x0A' && *str; str++);
  if(*str!=':') return NATICQ_PORT;
  str++;
  numbuf[5] = 0;
  for(;*str!=';' && *str!=' ' && *str!='\x0D' && *str!='\x0A' && *str && numcnt<5; numbuf[numcnt] = *str, str++, numcnt++);
  numbuf[numcnt] = 0;
  return atoi(numbuf);

}
//---------------------------------------------------------------------------
int GetHostsCount(const char *str)
{
  char cnt = 1;
  for(;cnt;cnt++)
  {
    for(;*str!=';' && *str!=' ' && *str!='\x0D' && *str!='\x0A' && *str; str++);
    if(!*str) return cnt;
    for(;(*str==';' || *str==' ' || *str=='\x0D' || *str=='\x0A') && *str; str++);
    if(!*str) return cnt;
  }
  return 0;

}
//---------------------------------------------------------------------------

void create_connect(void)
{
  char hostbuf[128];
  int hostport;
  int ***p_res=NULL;
  void do_reconnect(void);
  SOCK_ADDR sa;
  //������������� ����������
  connect_state = 0;
  int err;
  unsigned int ip;
  GBS_DelTimer(&reconnect_tmr);
  if (!IsGPRSEnabled())
  {
    is_gprs_online=0;
    strcpy(logmsg,LG_GRWAITFORGPRS);
    SMART_REDRAW();
    return;
  }
  DNR_ID=0;
  *socklasterr()=0;

  if(host_counter > GetHostsCount(NATICQ_HOST)-1) host_counter = 0;
  GetHost(host_counter, NATICQ_HOST, hostbuf);
  hostport = GetPort(host_counter, NATICQ_HOST);
  host_counter++;

  sprintf(hostname, "%s:%d", hostbuf, hostport);

  SMART_REDRAW();

  ip=str2ip(hostbuf);
  if (ip!=0xFFFFFFFF)
  {
    sa.ip=ip;
    strcpy(logmsg,"\nConnect by IP!");
    SMART_REDRAW();
    goto L_CONNECT;
  }
  strcpy(logmsg,LG_GRSENDDNR);
  SMART_REDRAW();
  err=async_gethostbyname(hostbuf,&p_res,&DNR_ID); //03461351 3<70<19<81
  if (err)
  {
    if ((err==0xC9)||(err==0xD6))
    {
      if (DNR_ID)
      {
        host_counter--;
	return; //���� ���������� DNR
      }
    }
    else
    {
      snprintf(logmsg,255,LG_GRDNRERROR,err);
      SMART_REDRAW();
      GBS_StartTimerProc(&reconnect_tmr,TMR_SECOND*10,do_reconnect);
      return;
    }
  }
  if (p_res)
  {
    if (p_res[3])
    {
      strcpy(logmsg,LG_GRDNROK);
      SMART_REDRAW();
      DNR_TRIES=0;
      sa.ip=p_res[3][0][0];
    L_CONNECT:
      sock=socket(1,1,0);
      if (sock!=-1)
      {
	sa.family=1;
	sa.port=htons(hostport);
	//    sa.ip=htonl(IP_ADDR(82,207,89,182));
	if (connect(sock,&sa,sizeof(sa))!=-1)
	{
	  connect_state=1;
	  TOTALRECEIVED=0;
	  TOTALSENDED=0;
	  SMART_REDRAW();
	}
	else
	{
	  closesocket(sock);
	  sock=-1;
	  LockSched();
	  ShowMSG(1,(int)LG_MSGCANTCONN);
	  UnlockSched();
	  GBS_StartTimerProc(&reconnect_tmr,TMR_SECOND*10,do_reconnect);
	}
      }
      else
      {
	LockSched();
	ShowMSG(1,(int)LG_MSGCANTCRSC);
	UnlockSched();
	//�� ������� �������� ������, ��������� GPRS-������
	GPRS_OnOff(0,1);
      }
    }
  }
  else
  {
    DNR_TRIES--;
    LockSched();
    ShowMSG(1,(int)LG_MSGHOSTNFND);
    UnlockSched();
  }
}

#ifdef SEND_TIMER
GBSTMR send_tmr;
#endif

void ClearSendQ(void)
{
  mfree((void *)sendq_p);
  sendq_p=NULL;
  sendq_l=NULL;
#ifdef SEND_TIMER
  GBS_DelTimer(&send_tmr);
#endif
}

void end_socket(void)
{
  if (sock>=0)
  {
    shutdown(sock,2);
    closesocket(sock);
  }
#ifdef SEND_TIMER
  GBS_DelTimer(&send_tmr);
#endif
}

#ifdef SEND_TIMER
static void resend(void)
{
  void SendAnswer(int dummy, TPKT *p);
  SUBPROC((void*)SendAnswer,0,0);
}
#endif

void SendAnswer(int dummy, TPKT *p)
{
  int i;
  int j;
  if (connect_state<2)
  {
    mfree(p);
    return;
  }
  if (p)
  {
    j=sizeof(PKT)+p->pkt.data_len; //������ ������
    TOTALSENDED+=j;
    ALLTOTALSENDED+=j;			//by BoBa 10.07
    //���������, �� ���� �� �������� � �������
    if (sendq_p)
    {
      //���� �������, ��������� � ���
      sendq_p=realloc((void *)sendq_p,sendq_l+j);
      memcpy((char *)sendq_p+sendq_l,p,j);
      mfree(p);
      sendq_l+=j;
      return;
    }
    sendq_p=p;
    sendq_l=j;
  }
  //���������� ��� ������������ � �������
  while((i=sendq_l)!=0)
  {
    if (i>0x400) i=0x400;
    j=send(sock,(void *)sendq_p,i,0);
    snprintf(logmsg,255,"send res %d",j);
    SMART_REDRAW();
    if (j<0)
    {
      j=*socklasterr();
      if ((j==0xC9)||(j==0xD6))
      {
	//�������� ��� ������
	strcpy(logmsg,"Send delayed...");
	return; //������, ���� ����� ��������� ENIP_BUFFER_FREE
      }
      else
      {
	//������
	LockSched();
	ShowMSG(1,(int)"Send error!");
	UnlockSched();
	end_socket();
	return;
      }
    }
    memcpy((void *)sendq_p,(char *)sendq_p+j,sendq_l-=j); //������� ����������
    if (j<i)
    {
      //�������� ������ ��� ����������
#ifdef SEND_TIMER
      GBS_StartTimerProc(&send_tmr,216*5,resend);
#endif
      return; //���� ��������� ENIP_BUFFER_FREE1
    }
    tenseconds_to_ping=0; //����-�� �������, ����� �������� ������ ������� �� ����� ������
    
  }
  mfree((void *)sendq_p);
  sendq_p=NULL;
}

void send_login(int dummy, TPKT *p)
{
  connect_state=2;
  char rev[16];
  //��� ����� ������ � ���� ����� ������������� �������, ���� ������ �� ������ �������!!!
  //� ���� ����� ������ �� ������!
  snprintf(rev,9,"Sie_%04d",__SVN_REVISION__);

  TPKT *p2=malloc(sizeof(PKT)+8);
  p2->pkt.uin=UIN;
  p2->pkt.type=T_SETCLIENT_ID;
  p2->pkt.data_len=8;
  memcpy(p2->data,rev,8);
  SendAnswer(0,p2);
  SendAnswer(dummy,p);
  RXstate=-(int)sizeof(PKT);
}

void do_ping(void)
{
  TPKT *pingp=malloc(sizeof(PKT));
  pingp->pkt.uin=UIN;
  pingp->pkt.type=0;
  pingp->pkt.data_len=0;
  SendAnswer(0,pingp);
}

void SendMSGACK(int i)
{
  TPKT *ackp=malloc(sizeof(PKT));
  ackp->pkt.uin=i;
  ackp->pkt.type=T_MSGACK;
  ackp->pkt.data_len=0;
  SendAnswer(0,ackp);
}
//x ������, � �����

void ParseRecMsg(char *recmsg)
{

  int j=0, i=0;
  i = atoi (recmsg);
  if(i <= 65 && i >=11)      // ����� <= 65 ��� >=11, ����� �������� �������� ��� ���������� ������� ��� ����� ����� ����� �����
  {
    if(!nich || !end_game)
    {
    if(Online2xod==0)  //������� �� ���������� ����, ���� ��� ��������
    {
     //ShowMSG(1,(int)"�����");
     while(i>10) 
     { 
           i-=10; //�������� ���������� ������
           j++;   //�������� ���������� ��������
     }

     //if(j<=6 && i <=5)   // ����������� ����� ������( ���� ���-�� � ����� ������ �������� 99, �� ������� ���)  (��������)
     //{
        if(TableXod[j][i]==0)  // �������� �� ����������� ������   (��������)
        {
               TableXod[j][i]=2;
               Online2xod=1;    // ��� ���������
               OnlainGameXod++; // ���������� �����
               DoFring();
                 if(ena_vibr)
                 {
                       vibra_count=1;
                       start_vibra();
                 }
               //ShowMSG(1,(int)"��� ���������� ���������");
        }
        //else
        //goto SHW_MSG;
    }
   }
  }
  else
  {
    //ShowMSG(1,(int)"�����");
    
    if( recmsg==strstr(recmsg,"RG") )
    {
      //ShowMSG(1,(int)"������");
      ShowWMSG(1, "E X-O:\n\n������� ������:\n'����������'\n\n����������?" , FONT, GetPaletteAdrByColorIndex(0), GetPaletteAdrByColorIndex(23), 1);
      //MsgBoxYesNo(1, (int)"������� ������ ����������.\n����������?", AnswerResGame);
    }
    else
    if( recmsg==strstr(recmsg,"Y_rg") )
    {
      //ShowMSG(1,(int)"������");
      ShowWMSG(0, "E X-O:\n\n������:\n'����������'\n\n������!" , FONT, GetPaletteAdrByColorIndex(0), GetPaletteAdrByColorIndex(23), 1);
      RestoreGame();
    }
    else
      if( recmsg==strstr(recmsg,"e_y_g") )
      {
        ShowWMSG(2, "E X-O:\n\n��������� ����������!\n\n����������� � ����� � ����?" , FONT , GetPaletteAdrByColorIndex(0), GetPaletteAdrByColorIndex(23), 1);
        
        //MsgBoxYesNo(1, (int)"����������� � ����� � ����?", AnswerExitGame);
        //ShowMSG(1,(int)"��������� ����������!");
      }
    else
      if( recmsg==strstr(recmsg,"N_rg") )
      {
        //ShowMSG(1,(int)"������ ����������\n��������!");
        ShowWMSG(0, "E X-O:\n\n������:\n\n'����������'\n\n��������!" , FONT, GetPaletteAdrByColorIndex(0), GetPaletteAdrByColorIndex(23), 1);
        //DrawGameMenu=0;
      }
    else
    if( recmsg==strstr(recmsg,"NG") )
    {
      ShowWMSG(3, "E X-O:\n\n������� ������:\n'������� ���'\n\n������� ��� ���?" , FONT, GetPaletteAdrByColorIndex(0), GetPaletteAdrByColorIndex(23), 1);
      //DrawGameMenu=0;
    }
    else
    if( recmsg==strstr(recmsg,"Y_ng") )
    {
      ShowWMSG(0, "E X-O:\n\n������:\n\n'������� ���'\n\n������!" , FONT, GetPaletteAdrByColorIndex(0), GetPaletteAdrByColorIndex(23), 1);
      NGame();
    }
    else
    if( recmsg==strstr(recmsg,"N_ng") )
    {
      ShowWMSG(0, "E X-O:\n\n������:\n\n'C������ ���'\n\n��������!" , FONT, GetPaletteAdrByColorIndex(0), GetPaletteAdrByColorIndex(23), 1);
        //DrawGameMenu=0;
    }
    else
    {
  //ShowREC_MSG=1;
  //ShowRecMSG(recmsg);//++++++++++++++++++++++++++++++++++
  //ShowMSG(1,(int)recmsg);
     //MsgBoxError(1, (int)recmsg);
      //goto SHW_MSG;
      //strcpy(messagen,recmsg);
      //SHW_MSG:  
        ShowWMSG(0, recmsg , FONT, GetPaletteAdrByColorIndex(0), GetPaletteAdrByColorIndex(23), 1);
    }
    
  }
   
  /*if( recmsg==strstr(recmsg,"11") )TableXod[1][1]=2;
  if( recmsg==strstr(recmsg,"12") )TableXod[1][2]=2;    
  if( recmsg==strstr(recmsg,"13") )TableXod[1][3]=2;
  if( recmsg==strstr(recmsg,"14") )TableXod[1][4]=2;  
  if( recmsg==strstr(recmsg,"15") )TableXod[1][5]=2; 
      
  if( recmsg==strstr(recmsg,"21") )TableXod[2][1]=2;
  if( recmsg==strstr(recmsg,"22") )TableXod[2][2]=2;    
  if( recmsg==strstr(recmsg,"23") )TableXod[2][3]=2;
  if( recmsg==strstr(recmsg,"24") )TableXod[2][4]=2;  
  if( recmsg==strstr(recmsg,"25") )TableXod[2][5]=2;     
  
  if( recmsg==strstr(recmsg,"31")) TableXod[3][1]=2;
  if( recmsg==strstr(recmsg,"32") )TableXod[3][2]=2;    
  if( recmsg==strstr(recmsg,"33") )TableXod[3][3]=2;
  if( recmsg==strstr(recmsg,"34") )TableXod[3][4]=2;  
  if( recmsg==strstr(recmsg,"35") )TableXod[3][5]=2;  
      
  if( recmsg==strstr(recmsg,"41") )TableXod[4][1]=2;
  if( recmsg==strstr(recmsg,"42") )TableXod[4][2]=2;    
  if( recmsg==strstr(recmsg,"43") )TableXod[4][3]=2;
  if( recmsg==strstr(recmsg,"44") )TableXod[4][4]=2;  
  if( recmsg==strstr(recmsg,"45") )TableXod[4][5]=2;
      
  if( recmsg==strstr(recmsg,"51") )TableXod[5][1]=2;
  if( recmsg==strstr(recmsg,"52") )TableXod[5][2]=2;    
  if( recmsg==strstr(recmsg,"53") )TableXod[5][3]=2;
  if( recmsg==strstr(recmsg,"54") )TableXod[5][4]=2;  
  if( recmsg==strstr(recmsg,"55") )TableXod[5][5]=2; 
      
  if( recmsg==strstr(recmsg,"61") )TableXod[6][1]=2;
  if( recmsg==strstr(recmsg,"62") )TableXod[6][2]=2;    
  if( recmsg==strstr(recmsg,"63") )TableXod[6][3]=2;
  if( recmsg==strstr(recmsg,"64") )TableXod[6][4]=2;  
  if( recmsg==strstr(recmsg,"65") )TableXod[6][5]=2;     
    */  
      
}
void get_answer(void)
{
  void *p;
  int i=RXstate;
  int j;
  int n;
  char rb[1024];
  char *rp=rb;
  if (connect_state<2) return;
  if (i==EOP) return;
  j=recv(sock,rb,sizeof(rb),0);
  while(j>0)
  {
    if (i<0)
    {
      //��������� ���������
      n=-i; //��������� ���������� ����
      if (j<n) n=j; //����������<���������?
      memcpy(RXbuf.data+i,rp,n); //��������
      i+=n;
      j-=n;
      rp+=n;
    }
    if (i>=0)
    {
      //��������� ������ ;)
      n=RXbuf.pkt.data_len; //����� � ������
      if (n>16383)
      {
	//������� �����
	strcpy(logmsg,LG_GRBADPACKET);
	end_socket();
	RXstate=EOP;
	return;
      }
      n-=i; //���������� ��������� ���� (����� ������ ������-������� �������)
      if (n>0)
      {
	if (j<n) n=j; //����������<���������?
	memcpy(RXbuf.data+i,rp,n);
	i+=n;
	j-=n;
	rp+=n;
      }
      if (RXbuf.pkt.data_len==i)
      {
	//����� ��������� �������
	TOTALRECEIVED+=(i+8);
	ALLTOTALRECEIVED+=(i+8);			//by BoBa 10.07
	//����� ������ ������, ����� ���������...
	RXbuf.data[i]=0; //����� ������
	switch(RXbuf.pkt.type)
	{
	case T_LOGIN:
	  //������ ������������
	  //�������� � MMI
	  n=i+sizeof(PKT)+1;
	  p=malloc(n);
	  memcpy(p,&RXbuf,n);
	  GBS_SendMessage(MMI_CEPID,MSG_HELPER_TRANSLATOR,0,p,sock);
	  //Play(sndStartup);
	  //        GBS_StartTimerProc(&tmr_ping,120*TMR_SECOND,call_ping);
	  snprintf(logmsg,255,LG_GRLOGINMSG,RXbuf.data);
	  connect_state=3;
          host_counter--; //���� �� ��������������, ����� ������ �� ���� �������
	  SMART_REDRAW();
	  break;
	case T_XTEXT_ACK:
	case T_GROUPID:
	case T_GROUPFOLLOW:
	case T_CLENTRY:
	  //�������� � MMI
	  n=i+sizeof(PKT)+1;
	  p=malloc(n);
	  memcpy(p,&RXbuf,n);
	  GBS_SendMessage(MMI_CEPID,MSG_HELPER_TRANSLATOR,0,p,sock);
	  //snprintf(logmsg,255,"CL: %s",RXbuf.data);
	  break;
	case T_STATUSCHANGE:
	  n=i+sizeof(PKT);
	  p=malloc(n);
	  memcpy(p,&RXbuf,n);
	  snprintf(logmsg,255,LG_GRSTATUSCHNG,RXbuf.pkt.uin,*((unsigned short *)(RXbuf.data)));
	  GBS_SendMessage(MMI_CEPID,MSG_HELPER_TRANSLATOR,0,p,sock);
	  break;
	case T_ERROR:
	  snprintf(logmsg,255,LG_GRERROR,RXbuf.data);
	  SMART_REDRAW();
	  break;
	case T_RECVMSG:
	  n=i+sizeof(PKT)+1;
	  p=malloc(n);
	  memcpy(p,&RXbuf,n);
	  {
	    char *s=p;
	    s+=sizeof(PKT);
	    int c;
	    while((c=*s))
	    {
	      if (c<3) *s=' ';
	      s++;
	    }
	  }
          //ShowMSG(1,(int)RXbuf.data);
          if(MODE_GAME==3)
          {
            ParseRecMsg( RXbuf.data);
          }
	  snprintf(logmsg,255,LG_GRRECVMSG,RXbuf.pkt.uin,RXbuf.data);
	  SendMSGACK(TOTALRECEIVED);
	  GBS_SendMessage(MMI_CEPID,MSG_HELPER_TRANSLATOR,0,p,sock);
	  SMART_REDRAW();
	  //Play(sndMsg);
	  break;
	case T_SSLRESP:
	  LockSched();
	  ShowMSG(1,(int)RXbuf.data);
	  UnlockSched();
	  break;
	/*case T_SRV_ACK:
	  if (FindContactLOGQByAck(&RXbuf)) Play(sndMsgSent);*/
	case T_CLIENT_ACK:
	  p=malloc(sizeof(PKT)+2);
	  memcpy(p,&RXbuf,sizeof(PKT)+2);
	  GBS_SendMessage(MMI_CEPID,MSG_HELPER_TRANSLATOR,0,p,sock);
	  break;
	case T_ECHORET:
	  {
	    TDate d;
	    TTime t;
	    TTime *pt=(TTime *)(RXbuf.data);
	    int s1;
	    int s2;
	    GetDateTime(&d,&t);
	    s1=t.hour*3600+t.min*60+t.sec;
	    s2=pt->hour*3600+pt->min*60+pt->sec;
	    s1-=s2;
	    if (s1<0) s1+=86400;
	    snprintf(logmsg,255,"Ping %d-%d seconds!",s1,s1+1);
	    LockSched();
	    ShowMSG(1,(int)logmsg);
	    UnlockSched();
	  }
	  break;
        case T_LASTPRIVACY:
          n=i+sizeof(PKT);
          p=malloc(n);
          memcpy(p,&RXbuf,n);
	  GBS_SendMessage(MMI_CEPID,MSG_HELPER_TRANSLATOR,0,p,sock);
	  break;
	}
	i=-(int)sizeof(PKT); //� ����� ��� ���� ������
      }
    }
  }
  RXstate=i;
  //  GBS_StartTimerProc(&tmr_dorecv,3000,dorecv);
  //  SMART_REDRAW();
}




int time_to_stop_t9;





void ask_my_info(void)
{
}



void to_develop(void)
{
  if (silenthide) return;
  gipc.name_to=ipc_xtask_name;
  gipc.name_from=ipc_my_name;
  gipc.data=(void *)maincsm_id;
  GBS_SendMessage(MMI_CEPID,MSG_IPC,IPC_XTASK_SHOW_CSM,&gipc);
}

int i_count;
void create_contactlist_menu(void)
{
  i_count=CountContacts();
  CONNECT_GUI();
}
  
  
ProcessPacket(TPKT *p)
{
  extern const int VIBR_TYPE, VIBR_ON_CONNECT;
  CLIST *t;
  LOGQ *q;
  
  switch(p->pkt.type)
  {
  //case T_LOGIN: break;
  case T_CLENTRY:
    draw_logo=0;
    IsConnectProcess=0;
    IsOnLineGame=1;
    IsMenu=0, 
    NewGame=1;
    InitParametres();
    GAME_MENU_GUI();
    REDRAW();
    
       if(VIBR_ON_CONNECT)
      {
        vibra_count=1;
        start_vibra();
      }
      
    //create_contactlist_menu();
    break;
  

  case T_RECVMSG:
    t=FindContactByUin(UIN_2);

    
    if(VIBR_TYPE)
      vibra_count=2;
    else
      vibra_count=1;
    start_vibra();
    
    if (t->name[0]=='#')
    {
      //���� ��� �����������, ������ ���
      char *s=strchr(p->data,'>');
      //���� ����� ������ > � ����� ���� ������ � ��� ������ 16 ��������
      if (s)
      {
	if ((s[1]==' ')&&((s-p->data)<16))
	{
	  *s=0; //����� ������
	  //AddStringToLog(t,0x02,s+2,p->data,0xFFFFFFFF); //��������� ��� �� ������ ���������
	 // goto L1;
	}
      }
    }
    
    
    break;
  case T_SRV_ACK:
  case T_CLIENT_ACK:
    q=FindContactLOGQByAck(p);
    if (q)
    {
      q->acked=p->pkt.type==T_SRV_ACK?1:2;
      t=FindContactByUin(p->pkt.uin);
      if (edchat_id)
      {
	void *data=FindGUIbyId(edchat_id,NULL);
	if (data)
	{
	  EDCHAT_STRUCT *ed_struct;
	  ed_struct=EDIT_GetUserPointer(data);
	  if (ed_struct)
	  {
	    if (ed_struct->ed_contact==t)
	    {
	      if (EDIT_IsBusy(data))
	      {
		t->req_drawack=1;
		time_to_stop_t9=3;
	      }
	      else 
              {
		
              }
	    }
	  }
	}
      }
    }
    break;
   }
  mfree(p);
}


IPC_REQ tmr_gipc;
void process_active_timer(void)
{
  if (connect_state>2)
  {
    if (++tenseconds_to_ping>12)
    {
      tenseconds_to_ping=0;
      SUBPROC((void *)do_ping);
    }
  }
  tmr_gipc.name_to=ipc_my_name;
  tmr_gipc.name_from=ipc_my_name;
  tmr_gipc.data=NULL;
  GBS_SendMessage(MMI_CEPID,MSG_IPC,IPC_TENSECONDS,&tmr_gipc);
  GBS_StartTimerProc(&tmr_active,TMR_SECOND*10,process_active_timer);
}

//===============================================================================================
int color_frame[8]={23,23,23,23,23,23,23,23};


extern int _done[8];
extern int error_count;
int DRE(int x, int color)
{
  DrawRectangle(x , 160, x + 5,170, 0, GetPaletteAdrByColorIndex(22), GetPaletteAdrByColorIndex(color));
  return 0;
}
int exit_ungraf=0;



static int method0(MAIN_GUI *data)//------------------------------------------
{
  DrawRectangle(0,YDISP,scr_w-1,scr_h-1,0,
		   GetPaletteAdrByColorIndex(1),
		   GetPaletteAdrByColorIndex(1));
   
  DrwImg(fon, 0,0, NULL,NULL);

if(IsConnectProcess)
{
  
   
  unsigned long RX=ALLTOTALRECEIVED; unsigned long TX=ALLTOTALSENDED;			//by BoBa 10.07
  wsprintf(data->ws1,LG_GRSTATESTRING,connect_state,RXstate,RX,TX,sendq_l,hostname,logmsg);

 
  DrawString(data->ws1,3,3+YDISP,scr_w-4,scr_h-4-GetFontYSIZE(FONT_MEDIUM_BOLD),
	     FONT_SMALL,0,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
  wsprintf(data->ws2,percent_t,cltop?LG_GRSKEYCLIST:empty_str);
  DrawString(data->ws2,(scr_w >> 1),scr_h-4-GetFontYSIZE(FONT_MEDIUM_BOLD),
	     scr_w-4,scr_h-4,FONT_MEDIUM_BOLD,TEXT_ALIGNRIGHT,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
  wsprintf(data->ws2,percent_t,LG_GRSKEYEXIT);
  DrawString(data->ws2,3,scr_h-4-GetFontYSIZE(FONT_MEDIUM_BOLD),
	     scr_w>>1,scr_h-4,FONT_MEDIUM_BOLD,TEXT_ALIGNLEFT,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
}
else
{
if(IsLoadGraph==1)
{
  WSHDR *ws_load = AllocWS(128);
  int dlina=7*img_count;
  
   DrawRectangle(33,scr_h/3+20,101,scr_h/3+30,0,
		   GetPaletteAdrByColorIndex(0),
		   GetPaletteAdrByColorIndex(23));
   
   DrawRectangle(35,scr_h/3+22,36+dlina,scr_h/3+28,0,
		   GetPaletteAdrByColorIndex(0),
		   GetPaletteAdrByColorIndex(22));
  
   
   DRE(33,color_frame[1]);
   DRE(43,color_frame[2]);
   DRE(53,color_frame[3]);
   DRE(63,color_frame[4]);
   DRE(73,color_frame[5]);
   DRE(83,color_frame[6]);
   DRE(93,color_frame[7]);
   
   wsprintf(ws_load,perc_t,"E X-O");
   DrawString(ws_load,0, scr_h/5 ,132,176,1,2,GetPaletteAdrByColorIndex(22),GetPaletteAdrByColorIndex(23));
   
   if(img_count!=7){
   wsprintf(ws_load,perc_t,"��������...");
   DrawString(ws_load,0, scr_h/3 ,132,176,FONT,2,GetPaletteAdrByColorIndex(22),GetPaletteAdrByColorIndex(23));
   }
  
   
   switch(img_count)
   {
    case 1:
          if(_done[1]==1)
      {
    
     wsprintf(ws_load,perc_t,"5% / 100%\no.png : ��������");  
     color_frame[1]=4;
      }
      else
        {
       color_frame[1]=2;
       wsprintf(ws_load,perc_t,"5% / 100%\no.png : �� ������!");  
      }
   
    break;
    case 2:
     
      if(_done[2]==1)
      {
      color_frame[2]=4;  
      wsprintf(ws_load,perc_t,"10% / 100%\nx.png : ��������"); 
      }
      else
      {
      color_frame[2]=2;
      wsprintf(ws_load,perc_t,"10% / 100%\nx.png : �� ������!"); 
      }
  
    break;
    case 3:
            if(_done[3]==1)
      {
      color_frame[3]=4;  
    wsprintf(ws_load,perc_t,"20% / 100%\ngame_cursor.png : ��������");
      }
      else
      {
     color_frame[3]=2;  
    wsprintf(ws_load,perc_t,"20% / 100%\ngame_cursor.png : �� ������!");
      }
    
    break;
    case 4:
               if(_done[4]==1)
      {
      color_frame[4]=4;  
      wsprintf(ws_load,perc_t,"30% / 100%\nmenu_cursor.png : ��������");  
      }
      else
      {
        color_frame[4]=2;  
      wsprintf(ws_load,perc_t,"30% / 100%\nmenu_cursor.png : �� ������!");
      }
   
    break;
    case 5:
      if(_done[5]==1)
      {
      color_frame[5]=4;  
      wsprintf(ws_load,perc_t,"45% / 100%\nlogo.png : ��������");    
      }
      else
      {
      color_frame[5]=2;  
      wsprintf(ws_load,perc_t,"45% / 100%\nlogo.png : �� ������!");    
      }
    break;
    case 6:
     if(_done[6]==1)
      {
      color_frame[6]=4;  
      wsprintf(ws_load,perc_t,"70% / 100%\ntable.png : ��������");  
      }
     else
     {
       color_frame[6]=2;  
      wsprintf(ws_load,perc_t,"70% / 100%\ntable.png : �� ������!");
     }
   
    break;
    case 7:
      if(_done[7]==1)
      {
      color_frame[7]=4;  
     wsprintf(ws_load,perc_t,"100% / 100%\nfon.png : ��������"); 
      }
      else
      {
      color_frame[7]=2;  
       wsprintf(ws_load,perc_t,"100% / 100%\nfon.png : �� ������"); 
      }
    break;
    default:
      if(error_count==7)
      {
        wsprintf(ws_load,perc_t,"������!����������� �������!"); 
        exit_ungraf=1;
        IsLoadGraph=1;
      }
      else
      {
      wsprintf(ws_load,perc_t,"���� ���������");
      }
}
   DrawString(ws_load,0, 90 ,132,176,FONT,2,GetPaletteAdrByColorIndex(22),GetPaletteAdrByColorIndex(23));
   FreeWS(ws_load);

}
else
{
  DrawRectangle(0,YDISP,scr_w-1,scr_h-1,0,
		   GetPaletteAdrByColorIndex(1),
		   GetPaletteAdrByColorIndex(1));
  
  
  DrwImg(fon, 0,0, NULL,NULL);
if(draw_logo==1)DrwImg(logo, X_LOGO,Y_LOGO, NULL,NULL);
 if(IsMenu)
 {
  
   DrawMainMenu();
   if(eDrawInfo==1)DrawAbout();
 }
 
 /*if(NewGame)
 {
  
   int X_G_C=20*x_n_poz -15;
   int Y_G_C=50+ 20*y_n_poz;
     
    //game_cur_x=45,
    //game_cur_y=150;  
   DrawLevel();
   if(MODE_GAME==2)DrawWhoIsXod();
   Read_XOD(1);
   Read_XOD(2);
   OXod(1);
   OXod(2);
   FringFig(1);
   FringFig(2);
   DrwImg(game_cursor, X_G_C, Y_G_C, NULL,NULL);
   //DrawG_Menu();

  }
  */
  
}
if(exit_ungraf==1)
{
   WSHDR *ws_err = AllocWS(128);
   
  DrawRectangle(0,YDISP,scr_w-1,scr_h-1,0,
		   GetPaletteAdrByColorIndex(2),
		   GetPaletteAdrByColorIndex(2));
  wsprintf(ws_err,perc_tt,"������!\n����������� �������!\n��������� ������������ ������!\n\n��������� ����:\n\n",PICTURES_PATH); 
  DrawString(ws_err,0, 30 ,132,176,FONT,2,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
  
   wsprintf(ws_err,perc_t,"�����");
   DrawString(ws_err,0, 160 ,132,176,FONT,4,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23)); 
  
  
   FreeWS(ws_err);
}

}
return 0;
}

 


 


void method1(MAIN_GUI *data,void *(*malloc_adr)(int))
{
  
  data->ws1=AllocWS(256);
  data->ws2=AllocWS(256);
  data->gui.state=1;
}

void method2(MAIN_GUI *data,void (*mfree_adr)(void *))
{

  if(fon)
  { 
   mfree(fon->bitmap);
   mfree(fon);
  }
  if(table)
  { 
   mfree(table->bitmap);
   mfree(table);
  }
   if(game_cursor)
  { 
   mfree(game_cursor->bitmap);
   mfree(game_cursor);
  }
   if(menu_cursor)
  { 
   mfree(menu_cursor->bitmap);
   mfree(menu_cursor);
  }
   if(draw_x)
  { 
   mfree(draw_x->bitmap);
   mfree(draw_x);
  }
     if(draw_o)
  { 
   mfree(draw_o->bitmap);
   mfree(draw_o);
  }
       if(logo)
  { 
   mfree(logo->bitmap);
   mfree(logo);
  }
  
  
  FreeWS(data->ws1);
  FreeWS(data->ws2);
  data->gui.state=0;

}

void method3(MAIN_GUI *data,void *(*malloc_adr)(int),void (*mfree_adr)(void *))
{
  DisableIDLETMR();
  data->gui.state=2;
}

void method4(MAIN_GUI *data,void (*mfree_adr)(void *))
{
  if (data->gui.state!=2)
    return;
  data->gui.state=1;
}





int method5(MAIN_GUI *data, GUI_MSG *msg)// �����
{
 DirectRedrawGUI();
  if (msg->gbsmsg->msg==KEY_DOWN)
  {
   switch(msg->gbsmsg->submess)
   {
    case GREEN_BUTTON:           ENTER_GREEN_BUTTON();        break;
    case RIGHT_SOFT:             ENTER_RIGHT_SOFT();          break;
    case LEFT_SOFT:              ENTER_LEFT_SOFT();           break;
    case LEFT_BUTTON:  case '4': ENTER_LEFT_BUTTON_OR_4();    break;
    case RIGHT_BUTTON: case '6': ENTER_RIGHT_BUTTON_OR_6();   break;
    case DOWN_BUTTON:  case '8': ENTER_DOWN_BUTTON_OR_8();    break;
    case UP_BUTTON:    case '2': ENTER_UP_BUTTON_OR_2();      break; 
    case ENTER_BUTTON: case '5': ENTER_ENTER_BUTTON_OR_5();   break;
    case RED_BUTTON:  if(exit_ungraf==1)CloseCSM(MAINCSM_ID); break;
                       case '0': ENTER_0();                   break;
    }           
  }
 return(0);
}


int method8(void){return(0);}

int method9(void){return(0);}

const void * const gui_methods[11]={
  (void *)method0,  //Redraw
  (void *)method1,  //Create
  (void *)method2,  //Close
  (void *)method3,  //Focus
  (void *)method4,  //Unfocus
  (void *)method5,  //OnKey
  0,
  (void *)kill_data, //method7, //Destroy
  (void *)method8,
  (void *)method9,
  0
};

const RECT Canvas={0,0,0,0};

void maincsm_oncreate(CSM_RAM *data)
{
  MAIN_GUI *main_gui=malloc(sizeof(MAIN_GUI));
  MAIN_CSM*csm=(MAIN_CSM*)data;
  zeromem(main_gui,sizeof(MAIN_GUI));
  patch_rect((RECT*)&Canvas,0,0,ScreenW()-1,ScreenH()-1);
  main_gui->gui.canvas=(void *)(&Canvas);
//  main_gui->gui.flag30=2;
  main_gui->gui.methods=(void *)gui_methods;
  main_gui->gui.item_ll.data_mfree=(void (*)(void *))mfree_adr();
  csm->csm.state=0;
  csm->csm.unk1=0;
  maingui_id=csm->gui_id=CreateGUI(main_gui);
  ews=AllocWS(16384);
  //  MutexCreate(&contactlist_mtx);
  DNR_TRIES=3;
  //  SUBPROC((void *)InitSmiles);
  //  SUBPROC((void *)create_connect);
  GBS_StartTimerProc(&tmr_active,TMR_SECOND*10,process_active_timer);
  sprintf((char *)ipc_my_name+6,percent_d,UIN);
  gipc.name_to=ipc_my_name;
  gipc.name_from=ipc_my_name;
  gipc.data=(void *)-1;
  
}



void maincsm_onclose(CSM_RAM *csm)
{

  //GBS_DelTimer(&tmr_dorecv);
  GBS_DelTimer(&tmr_active);
  //GBS_DelTimer(&tmr_ping);
  GBS_DelTimer(&tmr_vibra);
  GBS_DelTimer(&reconnect_tmr);
  GBS_DelTimer(&timer);
  GBS_DelTimer(&load_img);
  
  FreeCLIST();
  FreeWS(ews);

  SUBPROC((void *)end_socket);
  SUBPROC((void *)ClearSendQ);
  SUBPROC((void *)ElfKiller);
}

void do_reconnect(void)
{
  if (is_gprs_online)
  {
    DNR_TRIES=3;
    SUBPROC((void*)create_connect);
  }
}


int maincsm_onmessage(CSM_RAM *data,GBS_MSG *msg)
{
  extern const int VIBR_ON_CONNECT;

  
  MAIN_CSM *csm=(MAIN_CSM*)data;
  {
    //IPC
    if (msg->msg==MSG_IPC)
    {
      IPC_REQ *ipc;
      if ((ipc=(IPC_REQ*)msg->data0))
      {
	if (strcmp_nocase(ipc->name_to,ipc_my_name)==0)
	{
	  switch (msg->submess)
	  {
	  case IPC_TENSECONDS:
	    //������ ���� ���������
	    if (ipc->name_from==ipc_my_name)
	    {
	      CLIST *t=(CLIST *)cltop;
	      int f=0;
	      while(t)
	      {
		if (t->isactive)
		{
		  if (!(--(t->isactive))) f=1; //���� ����� �� 0 ���� �� ���� ��� - ���� ������������ ����
		}
		t=(CLIST *)(t->next);
	      }
	      if (f)
	      {
		
		
	      }
	      if (time_to_stop_t9)
	      {
		if (!(--time_to_stop_t9))
		{
		  if (IsGuiOnTop(edchat_id)) RefreshGUI();
		}
	      }
	    }
	    break;
     	  /*case IPC_SENDMSG: ;                                   //IPC_SENDMSG by BoBa 26.06.07
            int l=strlen(((IPCMsg *)(ipc->data))->msg);
            TPKT *msg=malloc(sizeof(PKT)+l);
            msg->pkt.uin=((IPCMsg *)(ipc->data))->uin;
            msg->pkt.type=T_SENDMSG;
            msg->pkt.data_len=l;
            memcpy(msg->data,((IPCMsg *)(ipc->data))->msg,l);
            //slientsend=1;
	    SENDMSGCOUNT++; //����� ���������
            SUBPROC((void *)SendAnswer,0,msg);
            break;*/
	  }
	}
      }
    }
  }
  if (msg->msg==MSG_RECONFIGURE_REQ)
  {
    extern const char *successed_config_filename;
    if (strcmp_nocase(successed_config_filename,(char *)msg->data0)==0)
    {
      ShowMSG(1,(int)"E X-O config updated!");
      InitConfig();
    }
  }
  if (msg->msg==MSG_GUI_DESTROYED)
  {
    if ((int)msg->data0==csm->gui_id)
    {
      csm->csm.state=-3;
    }
    if ((int)msg->data0==contactlist_menu_id)
    {
      contactlist_menu_id=0;
      
    }
    if ((int)msg->data0==edchat_id)
    {
      edchat_id=0;
    }
  }
 if(MODE_GAME==3)
 {

  if (msg->msg==MSG_HELPER_TRANSLATOR)
  {
    switch((int)msg->data0)
    {
    case LMAN_DISCONNECT_IND:
      is_gprs_online=0;
      return(1);
    case LMAN_CONNECT_CNF:
     vibra_count=1;
      start_vibra();
      is_gprs_online=1;
      strcpy(logmsg,LG_GRGPRSUP);
      //ShowMSG(1,(int)logmsg);
      GBS_StartTimerProc(&reconnect_tmr,TMR_SECOND*10,do_reconnect);
      return(1);
    case ENIP_DNR_HOST_BY_NAME:
      if ((int)msg->data1==DNR_ID)
      {
	if (DNR_TRIES) SUBPROC((void *)create_connect);
      }
      return(1);
    }
    if ((int)msg->data1==sock)
    {
      //���� ��� �����
      if ((((unsigned int)msg->data0)>>28)==0xA)
      {
	//������ �����
	ProcessPacket((TPKT *)msg->data0);
	return(0);
      }
      switch((int)msg->data0)
      {
      case ENIP_SOCK_CONNECTED:
	if (connect_state==1)
	{
	  if(VIBR_ON_CONNECT)
           vibra_count=2;
          else
          vibra_count=1;
	 start_vibra();
         
	 //���������� ������������, �������� ����� login
	  strcpy(logmsg, LG_GRTRYLOGIN);
	  {
	    int i=strlen(PASS);
	    TPKT *p=malloc(sizeof(PKT)+i);
	    p->pkt.uin=UIN;
	    p->pkt.type=T_REQLOGIN;
	    p->pkt.data_len=i;
	    memcpy(p->data,PASS,i);
	    SUBPROC((void *)send_login,0,p);
	  }
	  GROUP_CACHE=0;
	  SENDMSGCOUNT=0; //�������� ������
	  SMART_REDRAW();
	}
	else
	{
	  ShowMSG(1,(int)LG_MSGILLEGMSGCON);
	}
	break;
      case ENIP_SOCK_DATA_READ:
	if (connect_state>=2)
	{
	  //���� �������� send
	  SUBPROC((void *)get_answer);
	  SMART_REDRAW();
	}
	else
	{
	  ShowMSG(1,(int)LG_MSGILLEGMSGREA);
	}
	break;
      case ENIP_BUFFER_FREE:
      case ENIP_BUFFER_FREE1:
	SUBPROC((void *)SendAnswer,0,0);
	break;
      case ENIP_SOCK_REMOTE_CLOSED:
	//������ �� ������� �������
	if (connect_state)
	  SUBPROC((void *)end_socket);
	break;
      case ENIP_SOCK_CLOSED:
	//strcpy(logmsg, "No connection");
	//Dump not received
/*	if (RXstate>(-(int)sizeof(PKT)))
	{
	  unsigned int err;
	  int f=fopen("4:\\NATICQ.dump",A_ReadWrite+A_Create+A_Truncate+A_BIN,P_READ+P_WRITE,&err);
	  if (f!=-1)
	  {
	    fwrite(f,&RXbuf,RXstate+sizeof(PKT),&err);
	    fclose(f,&err);
	  }
	}*/
	
	
	connect_state=0;
	sock=-1;
        if(VIBR_ON_CONNECT) vibra_count=4; else vibra_count=1;
        start_vibra();
	if (sendq_p)
	{
	  snprintf(logmsg,255,"Disconnected, %d bytes not sended!",sendq_l);
	}
	SMART_REDRAW();
	SUBPROC((void *)ClearSendQ);
	if (!disautorecconect)
        {
          GBS_StartTimerProc(&reconnect_tmr,TMR_SECOND*10,do_reconnect);
          snprintf(logmsg,255,"%s\nReconect after %d second...",logmsg, 10);
        }
	break;
      }
    }
  }
  }
  return(1);
}


const int minus11=-11;

unsigned short maincsm_name_body[140];

const struct
{
  CSM_DESC maincsm;
  WSHDR maincsm_name;
}MAINCSM =
{
  {
    maincsm_onmessage,
    maincsm_oncreate,
#ifdef NEWSGOLD
0,
0,
0,
0,
#endif
maincsm_onclose,
sizeof(MAIN_CSM),
1,
&minus11
  },
  {
    maincsm_name_body,
    NAMECSM_MAGIC1,
    NAMECSM_MAGIC2,
    0x0,
    139
  }
};

void UpdateCSMname(void)
{
  wsprintf((WSHDR *)(&MAINCSM.maincsm_name), "E X-O ONLINE");
}


int main(char *filename)
{
  scr_w=ScreenW();
  scr_h=ScreenH();
  MAIN_CSM main_csm;
  char *s;
  int len;
  

  InitConfig();
  s=strrchr(filename,'\\');
  len=(s-filename)+1;
  strncpy(elf_path,filename,len);
  elf_path[len]=0;
  
  ReadDefSettings();

  T_Load_IMG();
  
  UpdateCSMname();
  LockSched();
  MAINCSM_ID=CreateCSM(&MAINCSM.maincsm,&main_csm,0);
  UnlockSched();
  return 0;
}



GUI *ggui=0;
void edchat_ghook(GUI *gui, int cmd)
 {
   if(cmd==0xA)
   {
     DisableIDLETMR();
   }
   if(cmd==0x03)
   {
     FreeWS(ews);
     ews = NULL;
   }
 }

#define wslen(ws) ws->wsbody[0]
int itemnum, wd_id;
void SendMsg(void)
{
  TPKT *p;
  EDITCONTROL ec;
  ExtractEditControl(ggui, 2, &ec);     
  char *text=ws2ascii(ec.pWS);
 
  if (connect_state==3)
  {
    //sprintf(send_msg, perc_t,text);
    p=malloc(sizeof(PKT)+strlen(text)+1);
    p->pkt.uin=UIN_2;
    p->pkt.type=T_SENDMSG;
    p->pkt.data_len=strlen(text);
    strcpy(p->data,text);
    SENDMSGCOUNT++;
    SUBPROC((void *)SendAnswer,0,p);
  }
  
  //ShowMSG(1,(int) text);
}


int edchat_onkey(GUI *data, GUI_MSG *msg)
{
  ggui=data;
  switch (msg->gbsmsg->submess)
  {
    
    
    case GREEN_BUTTON:
    //case LEFT_SOFT:
      
    SendMsg();
    
    return 1;
    
    //break;
 }
  return 0;
}

void edchat_locret(void){};

HEADER_DESC edchat_hdr={0,0,0,0,NULL,(int)"���������:",LGP_NULL};

static const SOFTKEY_DESC menu_sk[] =
{
  {0x0018, 0x0000, (int)"Options"},
  {0x0001, 0x0000, (int)"Close"},
  {0x003D, 0x0000, (int)LGP_DOIT_PIC}
};

const SOFTKEYSTAB menu_skt =
{
  menu_sk, 0
};

static const INPUTDIA_DESC edchat_desc =
{
  1,
  edchat_onkey,
  edchat_ghook,
  (void *)edchat_locret,
  0,
  &menu_skt,
  {0,NULL,NULL,NULL},
  FONT_SMALL,
  100,
  101,
  0,
  //  0x00000001 - ��������� �� ������� ����
  //0x00000002,// - ��������� �� ������
  //  0x00000004 - �������� ���������
  //  0x00000008 - UnderLine
  //  0x00000020 - �� ���������� �����
  //  0x00000200 - bold
  0,
  //  0x00000002 - ReadOnly
  //  0x00000004 - �� ��������� ������
  //  0x40000000 - �������� ������� ����-������
  0x40000000
};
////////////////////////////////////////////////////////////////////////////////


///���� ���������//////////////////////////////////////////////////////////////////
int WriteMsg()
 {
  
  EDITCONTROL ec;
  void *ma=malloc_adr();
  void *eq;
  WSHDR *ws;
  PrepareEditControl(&ec);
  eq=AllocEQueue(ma,mfree_adr());  
  ws=AllocWS(128);
  
  ConstructEditControl(&ec,1,0x40,ws,wslen(ws));
  AddEditControlToEditQend(eq,&ec,ma); 
  ConstructEditControl(&ec,3,ECF_APPEND_EOL,ws,256);
  AddEditControlToEditQend(eq,&ec,ma);  
  FreeWS(ws);
  patch_header(&edchat_hdr);
  patch_input(&edchat_desc);    
  return wd_id=CreateInputTextDialog(&edchat_desc,&edchat_hdr,eq,1,0);
 }


/*void Seng_Msg()
{
  TPKT *p;
  EDITCONTROL ec;
  ExtractEditControl(ggui, 2, &ec);     
  char *text=ws2ascii(ec.pWS);
  //volatile int hFile;
  //unsigned int io_error = 0;
  //char send_msg[256];
  
  
  if (connect_state==3)
  {
    //sprintf(send_msg, perc_t,text);
    p=malloc(sizeof(PKT)+strlen(text)+1);
    p->pkt.uin=UIN_2;
    p->pkt.type=T_SENDMSG;
    p->pkt.data_len=strlen(text);
    strcpy(p->data,text);
    SENDMSGCOUNT++;
    SUBPROC((void *)SendAnswer,0,p);
  }
  
  free(text);
}
*/





























