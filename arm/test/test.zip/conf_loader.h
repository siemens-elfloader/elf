/*
* Ping-Pong 2009 - 2010
* keys
* (c) Danil_e71
*/
#ifndef _CONFLOADER_H_
#define _CONFLOADER_H_
void InitConfig();
#endif
