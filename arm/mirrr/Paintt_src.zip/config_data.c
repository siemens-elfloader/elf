#include "..\inc\cfg_items.h"

#ifdef NEWSGOLD
#define DEFAULT_DISK "4"
#else
#define DEFAULT_DISK "0"
#endif

__root const CFG_HDR cfghdr0={CFG_CBOX,"Default bitmap quality",0,3};
#ifdef NEWSGOLD
__root const int DEF_PICT_MOD=2;
#else
__root const int DEF_PICT_MOD=1;
#endif
__root const CFG_CBOX_ITEM cfgcbox0[]={"8���","16���","24���+�����"};


__root const CFG_HDR cfghdr1={CFG_CBOX,"Default zoom mod",0,2};
__root const int DEF_ZOOM_MOD=0;
__root const CFG_CBOX_ITEM cfgcbox1[]={"1x","2x"};

__root const CFG_HDR cfghdr2={CFG_STR_UTF8,"Save bmp to",0,63};
__root const char SAVE_PATH[64]=DEFAULT_DISK ":\\ZBin\\Paintt\\save\\";

