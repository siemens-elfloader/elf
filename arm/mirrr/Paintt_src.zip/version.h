#include "rect_patcher.h"

#define TMR_SECOND 216

		IMGHDR pic1;
static const char perc_t[]="%t", map_mod[6]={5,8,10,1,2,4};
unsigned short scr_h,scr_w, sk_h,
						pic_w=40,pic_h=40,
						pic_ww,pic_hh,col,ots_h,
						cur_x,cur_y, cur_x1, cur_y1;
unsigned int msz, premsz;
char *picmap, *premap;
char Quit=0, start=1, startt=1, zoom_mod, inst_type=0, inst_mod=0, open, pic_modd, crp, gst,
		COL[4][4]={{0,0,0,255},{255,0,0,255},{255,255,255,255},{0,0,0,0}},
		dop_col[2][4]={{0,0,0,200},{255,0,0,55}}, dop_col0[3][4]={{0,0,0,200},{0,0,0,255},{255,255,255,255}},
		pic_mod;
extern const int DEF_PICT_MOD, DEF_ZOOM_MOD;
extern const char SAVE_PATH[];
//IMGHDR picr,picg,picb,picrez;

void ExitProc(int decision)
{
  if(!decision)Quit = 1;
}



char *ver="0.03.1b";
