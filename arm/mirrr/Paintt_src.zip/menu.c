//unsigned int mmod;



void menu_ghook(void *data, int cmd)
{
}

int menusoftkeys[]={0,1,2};

int S_ICONS[];

SOFTKEY_DESC menu_sk[]=
{
  {0x0018,0x0000,(int)"�����"},
  {0x0001,0x0000,(int)"�����"},
  {0x003D,0x0000,(int)LGP_DOIT_PIC}
};

SOFTKEYSTAB menu_skt=
{
  menu_sk,0
};

SOFTKEY_DESC save_sk[]=
{
  {0x0018,0x0000,(int)"����."},
  {0x0001,0x0000,(int)"�����"},
  {0x003D,0x0000,(int)LGP_DOIT_PIC}
};

SOFTKEYSTAB save_skt=
{
  save_sk,0
};


//���� ������ �����:
const char *scmitem[]={"red","green","blue"};
const char scmcnt=3;

HEADER_DESC scmhdr={0,0,131,21,NULL,(int)"����� �����",LGP_NULL};

void scm_ghook(void *data, int cmd)
{
	DrawRectangle(20,scr_h-sk_h-40,scr_w-21,scr_h-sk_h-10,0,GetPaletteAdrByColorIndex(0),edcl);
}

void scm_iconhndl(void *data, int curitem, void *unk)
{
  void *item=AllocMenuItem(data);
  WSHDR *ws=AllocMenuWS(data,30);
  wsprintf(ws,"<%d %t>",edcl[curitem],scmitem[curitem]);
  SetMenuItemText(data,item,ws,curitem);
}

int scm_onkey(void *data, GUI_MSG *msg)
{
	if (msg->keys==0x18)
	{
		colset();
		//if(ednm==2) cangefon();
		return(1);
	}
	if (msg->keys==0x3D)
	{
		return(-1);
	}
	if ((msg->gbsmsg->msg==KEY_DOWN))
	{
		switch(msg->gbsmsg->submess)
		{
			case '6':
			#ifdef NEWSGOLD
			case RIGHT_BUTTON:
			#endif
				edcl[GetCurMenuItem(data)]++;
				RefreshGUI();
				break;
			case '4':
			#ifdef NEWSGOLD
			case LEFT_BUTTON:
			#endif
				edcl[GetCurMenuItem(data)]--;
				RefreshGUI();
				break;
		}
	}
	if ((msg->gbsmsg->msg==LONG_PRESS))
	{
		switch(msg->gbsmsg->submess)
		{
			case '6':
			#ifdef NEWSGOLD
			case RIGHT_BUTTON:
			#endif
				edcl[GetCurMenuItem(data)]+=10;
				RefreshGUI();
				break;
			case '4':
			#ifdef NEWSGOLD
			case LEFT_BUTTON:
			#endif
				edcl[GetCurMenuItem(data)]-=10;
				RefreshGUI();
				break;
		}
	}
	return(0);
}

MENU_DESC scm=
{
  8,scm_onkey,scm_ghook,NULL,
  menusoftkeys,
  &save_skt,
  0x10,		//0x11
  scm_iconhndl,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};

int create_scm()
{
	edcl[0]=COL[ednm][0];
	edcl[1]=COL[ednm][1];
	edcl[2]=COL[ednm][2];
		COL[3][0]=COL[2][0];
		COL[3][1]=COL[2][1];
		COL[3][2]=COL[2][2];
	//ednm=y;
	patch_header(&scmhdr);
	return(CreateMenu(0,0,&scm,&scmhdr,0,scmcnt,0,0));
}





// �������� ����:
const char *colmitem[]={"���� 1","���� 2","���"};
const char colmcnt=3;

HEADER_DESC colmhdr={0,0,131,21,NULL,(int)"���� ������",LGP_NULL};

void colm_iconhndl(void *data, int curitem, void *unk)
{
  void *item=AllocMenuItem(data);
  WSHDR *ws=AllocMenuWS(data,30);
  wsprintf(ws,perc_t,colmitem[curitem]);
  //SetMenuItemIconArray(data,item,S_ICONS);
  SetMenuItemText(data,item,ws,curitem);
  //SetMenuItemIcon(data,curitem,0);
}

int colm_onkey(void *data, GUI_MSG *msg)
{
  if ((msg->keys==0x18)||(msg->keys==0x3D))
  {
	ednm=GetCurMenuItem(data);
	create_scm();//ShowMSG(1,(int)"��� :)");
	
    return(-1);
  }
  return(0);
}

MENU_DESC colm=
{
  8,colm_onkey,menu_ghook,NULL,
  menusoftkeys,
  &menu_skt,
  0x10,		//0x11
  colm_iconhndl,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};

int create_colm()
{
	patch_header(&colmhdr);
	return(CreateMenu(0,0,&colm,&colmhdr,0,colmcnt,0,0));
}





// ���� ��������:
const char *picmitem[]={"������","������"}, *pictype[]={"8���","16���","24���+�����"};
const char picmcnt=3;

HEADER_DESC picmhdr={0,0,131,21,NULL,(int)"���� ��������",LGP_NULL};

void picm_iconhndl(void *data, int curitem, void *unk)
{
  void *item=AllocMenuItem(data);
  WSHDR *ws=AllocMenuWS(data,30);
  switch(curitem)
  {
	case 0: wsprintf(ws,"<%d %t>",pic_ww,picmitem[curitem]); break;
	case 1: wsprintf(ws,"<%d %t>",pic_hh,picmitem[curitem]); break;
	case 2: wsprintf(ws,"<%t>",pictype[pic_modd]); break;
  }
	//SetMenuItemIconArray(data,item,S_ICONS);
	SetMenuItemText(data,item,ws,curitem);
	//SetMenuItemIcon(data,curitem,0);
}

int picm_onkey(void *data, GUI_MSG *msg)
{
  if ((msg->keys==0x18)||(msg->keys==0x3D))
  {
	startt=0;
	pic_w=pic_ww;
	pic_h=pic_hh;
	pic_mod=pic_modd;
	if(!start) {mfree(premap); mfree(picmap);}
	else start=1;
	crpic();
    return(1);
  }
  if (msg->gbsmsg->msg==KEY_DOWN)
  {
	switch(msg->gbsmsg->submess)
	{
		case '6':
		#ifdef NEWSGOLD
		case RIGHT_BUTTON:
		#endif
			switch(GetCurMenuItem(data))
			{
				case 0:
					pic_ww++;
					RefreshGUI();
					return(-1);
				case 1:
					pic_hh++;
					RefreshGUI();
					return(-1);
				case 2:
					if(pic_modd==2) pic_modd=0;
					else pic_modd++;
					RefreshGUI();
					return(-1);
			}
		case '4':
		#ifdef NEWSGOLD
		case LEFT_BUTTON:
		#endif
			switch(GetCurMenuItem(data))
			{
				case 0:
					pic_ww--;
					RefreshGUI();
					return(-1);
				case 1:
					pic_hh--;
					RefreshGUI();
					return(-1);
				case 2:
					if(pic_modd==0) pic_modd=2;
					else pic_modd--;
					RefreshGUI();
					return(-1);
			}
  }}
  if (msg->gbsmsg->msg==LONG_PRESS)
  {
	switch(msg->gbsmsg->submess)
	{
		case '6':
		#ifdef NEWSGOLD
		case RIGHT_BUTTON:
		#endif
			switch(GetCurMenuItem(data))
			{
				case 0:
					pic_ww+=5;
					RefreshGUI();
					return(-1);
				case 1:
					pic_hh+=5;
					RefreshGUI();
					return(-1);
				case 2:
					if(pic_modd==2) pic_modd=0;
					else pic_modd++;
					RefreshGUI();
					return(-1);
			}
		case '4':
		#ifdef NEWSGOLD
		case LEFT_BUTTON:
		#endif
			switch(GetCurMenuItem(data))
			{
				case 0:
					pic_ww-=5;
					RefreshGUI();
					return(-1);
				case 1:
					pic_hh-=5;
					RefreshGUI();
					return(-1);
				case 2:
					if(pic_modd==0) pic_modd=2;
					else pic_modd--;
					RefreshGUI();
					return(-1);
			}
  }}
  if(startt) if(msg->keys==0x01)  { MsgBoxYesNo(1,(int)"�����?",ExitProc);return(-1);}
  return(0);
}

MENU_DESC picm=
{
  8,picm_onkey,menu_ghook,NULL,
  menusoftkeys,
  &save_skt,
  0x10,		//0x11
  picm_iconhndl,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};

int create_picm()
{
	pic_ww=pic_w;
	pic_hh=pic_h;
	pic_modd=pic_mod;
	patch_header(&picmhdr);
	return(CreateMenu(0,0,&picm,&picmhdr,0,picmcnt,0,0));
}



// ���� ������������:
const char *instmitem[]={"��������","�����","�������������", "������"};
const char instmcnt=4;

HEADER_DESC instmhdr={0,0,131,21,NULL,(int)"�����������",LGP_NULL};

void instm_iconhndl(void *data, int curitem, void *unk)
{
  void *item=AllocMenuItem(data);
  WSHDR *ws=AllocMenuWS(data,30);
  wsprintf(ws,perc_t,instmitem[curitem]);
  SetMenuItemText(data,item,ws,curitem);
}

int instm_onkey(void *data, GUI_MSG *msg)
{
  if ((msg->keys==0x18)||(msg->keys==0x3D))
  {
	inst_type=GetCurMenuItem(data);
	return(1);
  }
  return(0);
}

MENU_DESC instm=
{
  8,instm_onkey,menu_ghook,NULL,
  menusoftkeys,
  &menu_skt,
  0x10,		//0x11
  instm_iconhndl,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};

int create_instm()
{
	patch_header(&instmhdr);
	return(CreateMenu(0,0,&instm,&instmhdr,0,instmcnt,0,0));
}






// ������� ����:
const char *mmitem[]={"�����","��������","�����������","���������","� �����","�����"};
const char mmcnt=6;

HEADER_DESC mmhdr={0,0,131,21,NULL,(int)"������� ����",LGP_NULL};

void mm_iconhndl(void *data, int curitem, void *unk)
{
  void *item=AllocMenuItem(data);
  WSHDR *ws=AllocMenuWS(data,30);
  wsprintf(ws,perc_t,mmitem[curitem]);
  //SetMenuItemIconArray(data,item,S_ICONS);
  SetMenuItemText(data,item,ws,curitem);
  //SetMenuItemIcon(data,curitem,0);
}

int mm_onkey(void *data, GUI_MSG *msg)
{
  if ((msg->keys==0x18)||(msg->keys==0x3D))
  {
	int iw=GetCurMenuItem(data);
	switch(iw)
	{
		case 0: create_colm();//ShowMSG(1,(int)"Color menu :)");
			break;
		case 1: create_picm();//ShowMSG(1,(int)mmitem[iw]);
			break;
		case 2: create_instm();//ShowMSG(1,(int)mmitem[iw]);
			break;
		case 3: saveBMP();//ShowMSG(1,(int)mmitem[iw]);
			break;
		case 4: ShowMSG(1,(int)"http://titron.h2m.ru");
			break;
		case 5: MsgBoxYesNo(1,(int)"�����?",ExitProc);
			break;
	}
    return(-1);
  }
  return(0);
}

MENU_DESC mm=
{
  8,mm_onkey,menu_ghook,NULL,
  menusoftkeys,
  &menu_skt,
  0x10,		//0x11
  mm_iconhndl,
  NULL,   //Items
  NULL,   //Procs
  0   //n
};

int create_mm()
{
	patch_header(&mmhdr);
	return(CreateMenu(0,0,&mm,&mmhdr,0,mmcnt,0,0));
}
