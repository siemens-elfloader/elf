#include "image.h"
#include <math.h>


void do_rect()
{
	int i,j;
	char a=0,s=0;
	unsigned short q;
	if(cur_x<cur_x1)
	{
		q=cur_x;
		cur_x=cur_x1;
		cur_x1=q;
		a=1;
	}
	if(cur_y<cur_y1)
	{
		q=cur_y;
		cur_y=cur_y1;
		cur_y1=q;
		s=1;
	}
	for(i=0;i<cur_y-cur_y1+1;i++)
	{
		for(j=0;j<cur_x-cur_x1+1;j++)
		{
			if((i==0)||(i==cur_y-cur_y1))
			{
				memcpy(premap+(cur_y1+i)*pic_w*4+(cur_x1+j)*4, &COL[0][2], 1);
				memcpy(premap+(cur_y1+i)*pic_w*4+(cur_x1+j)*4+1, &COL[0][1], 1);
				memcpy(premap+(cur_y1+i)*pic_w*4+(cur_x1+j)*4+2, &COL[0][0], 1);
				memcpy(premap+(cur_y1+i)*pic_w*4+(cur_x1+j)*4+3, &COL[0][3], 1);
			}
			else
			{
				if((j==0)||(j==cur_x-cur_x1))
				{
					memcpy(premap+(cur_y1+i)*pic_w*4+(cur_x1+j)*4, &COL[0][2], 1);
					memcpy(premap+(cur_y1+i)*pic_w*4+(cur_x1+j)*4+1, &COL[0][1], 1);
					memcpy(premap+(cur_y1+i)*pic_w*4+(cur_x1+j)*4+2, &COL[0][0], 1);
					memcpy(premap+(cur_y1+i)*pic_w*4+(cur_x1+j)*4+3, &COL[0][3], 1);
				}
				else
				{
					memcpy(premap+(cur_y1+i)*pic_w*4+(cur_x1+j)*4, &COL[1][2], 1);
					memcpy(premap+(cur_y1+i)*pic_w*4+(cur_x1+j)*4+1, &COL[1][1], 1);
					memcpy(premap+(cur_y1+i)*pic_w*4+(cur_x1+j)*4+2, &COL[1][0], 1);
					memcpy(premap+(cur_y1+i)*pic_w*4+(cur_x1+j)*4+3, &COL[1][3], 1);
				}
			}
		}
	}
	if(a)
	{
		q=cur_x;
		cur_x=cur_x1;
		cur_x1=q;
	}
	if(s)
	{
		q=cur_y;
		cur_y=cur_y1;
		cur_y1=q;
	}
}

void do_arc()
{
	int i,j;
	char a=0,s=0;
	unsigned short q,w;
	if(cur_x<cur_x1)
	{
		q=cur_x;
		cur_x=cur_x1;
		cur_x1=q;
		a=1;
	}
	if(cur_y<cur_y1)
	{
		q=cur_y;
		cur_y=cur_y1;
		cur_y1=q;
		s=1;
	}
	for(i=0;i<cur_y-cur_y1+1;i++)
	{
		for(j=0;j<cur_x-cur_x1+1;j++)
		{
			//w=sqrt((i-(cur_x-cur_x1)/2)*(i-(cur_x-cur_x1)/2)+(j-(cur_x-cur_x1)/2)*(j-(cur_x-cur_x1)/2));
			w=((j-(cur_x-cur_x1)/2)*(j-(cur_x-cur_x1)/2)*100)/(((cur_x-cur_x1)/2)*((cur_x-cur_x1)/2))+((i-(cur_y-cur_y1)/2)*(i-(cur_y-cur_y1)/2)*100)/(((cur_y-cur_y1)/2)*((cur_y-cur_y1)/2));
			if(w<=100)
			{
				premap[(cur_y1+i)*pic_w*4+(cur_x1+j)*4]=COL[0][2];
				premap[(cur_y1+i)*pic_w*4+(cur_x1+j)*4+1]=COL[0][1];
				premap[(cur_y1+i)*pic_w*4+(cur_x1+j)*4+2]=COL[0][0];
				premap[(cur_y1+i)*pic_w*4+(cur_x1+j)*4+3]=COL[0][3];
			}
		}
	}
	for(i=0;i<cur_y-cur_y1+1;i++)
	{
		for(j=0;j<cur_x-cur_x1+1;j++)
		{
			w=((j-(cur_x-cur_x1-2)/2)*(j-(cur_x-cur_x1-2)/2)*100)/(((cur_x-cur_x1-2)/2)*((cur_x-cur_x1-2)/2))+((i-(cur_y-cur_y1-2)/2)*(i-(cur_y-cur_y1-2)/2)*100)/(((cur_y-cur_y1-2)/2)*((cur_y-cur_y1-2)/2));
			if(w<100)
			{
				premap[(cur_y1+1+i)*pic_w*4+(cur_x1+1+j)*4]=COL[1][2];
				premap[(cur_y1+1+i)*pic_w*4+(cur_x1+1+j)*4+1]=COL[1][1];
				premap[(cur_y1+1+i)*pic_w*4+(cur_x1+1+j)*4+2]=COL[1][0];
				premap[(cur_y1+1+i)*pic_w*4+(cur_x1+1+j)*4+3]=COL[1][3];
			}
		}
	}
	if(a)
	{
		q=cur_x;
		cur_x=cur_x1;
		cur_x1=q;
	}
	if(s)
	{
		q=cur_y;
		cur_y=cur_y1;
		cur_y1=q;
	}
}

void do_inst()
{
	switch(inst_type)
	{
		case 1:
			memcpy(premap+cur_y*pic_w*4+cur_x*4, &COL[0][2], 1);
			memcpy(premap+cur_y*pic_w*4+cur_x*4+1, &COL[0][1], 1);
			memcpy(premap+cur_y*pic_w*4+cur_x*4+2, &COL[0][0], 1);
			memcpy(premap+cur_y*pic_w*4+cur_x*4+3, &COL[0][3], 1);
			break;
		case 2:
			DrawRectangle(11+(zoom_mod+1)*cur_x1,YDISP+ots_h+(zoom_mod+1)*cur_y1,12+(zoom_mod+1)*cur_x,1+YDISP+ots_h+(zoom_mod+1)*cur_y,1,dop_col[0],dop_col[1]);
			break;
		case 3:
			drawArc(11+(zoom_mod+1)*cur_x1,YDISP+ots_h+(zoom_mod+1)*cur_y1,12+(zoom_mod+1)*cur_x,1+YDISP+ots_h+(zoom_mod+1)*cur_y,0,360,1,dop_col[0],dop_col[1]);
			break;
	}
}

void set_point()
{
	switch(inst_type)
	{
		case 0:
			memcpy(premap+cur_y*pic_w*4+cur_x*4, &COL[0][2], 1);
			memcpy(premap+cur_y*pic_w*4+cur_x*4+1, &COL[0][1], 1);
			memcpy(premap+cur_y*pic_w*4+cur_x*4+2, &COL[0][0], 1);
			memcpy(premap+cur_y*pic_w*4+cur_x*4+3, &COL[0][3], 1);
			break;
		case 1:
			if(inst_mod) inst_mod=0;
			else inst_mod=1;
			break;
		case 2:
			if(inst_mod==0)
			{
				inst_mod=2;
				cur_x1=cur_x;
				cur_y1=cur_y;
			}
			else
			{
				inst_mod=0;
				do_rect();
			}
			break;
		case 3:
			if(inst_mod==0)
			{
				inst_mod=2;
				cur_x1=cur_x;
				cur_y1=cur_y;
			}
			else
			{
				inst_mod=0;
				do_arc();
			}
			break;
	}
}

void cangecol()
{
	char dop_cl[4]={COL[0][0],COL[0][1],COL[0][2]};
	COL[0][0]=COL[1][0];
	COL[0][1]=COL[1][1];
	COL[0][2]=COL[1][2];
	COL[1][0]=dop_cl[0];
	COL[1][1]=dop_cl[1];
	COL[1][2]=dop_cl[2];
		dop_col0[0][0]=COL[0][0];
		dop_col0[0][1]=COL[0][1];
		dop_col0[0][2]=COL[0][2];
		dop_col[0][0]=COL[0][0];
		dop_col[0][1]=COL[0][1];
		dop_col[0][2]=COL[0][2];
		dop_col[1][0]=COL[1][0];
		dop_col[1][1]=COL[1][1];
		dop_col[1][2]=COL[1][2];
}

void cangefon()
{
	int i;
	for (i=0;i<msz/4;i++)
	{
		if(premap[i*4]==COL[3][2])
		if(premap[i*4+1]==COL[3][1])
		if(premap[i*4+2]==COL[3][0])
		{
			memcpy(premap+i*4, &COL[2][2], 1);
			memcpy(premap+i*4+1, &COL[2][1], 1);
			memcpy(premap+i*4+2, &COL[2][0], 1);
			memcpy(premap+i*4+3, &COL[2][3], 1);
		}
	}
}

void colset()
{
	COL[ednm][0]=edcl[0];
	COL[ednm][1]=edcl[1];
	COL[ednm][2]=edcl[2];
	if(ednm<2)
	{
		dop_col0[0][0]=COL[0][0];
		dop_col0[0][1]=COL[0][1];
		dop_col0[0][2]=COL[0][2];
		dop_col[ednm][0]=COL[ednm][0];
		dop_col[ednm][1]=COL[ednm][1];
		dop_col[ednm][2]=COL[ednm][2];
	}
	else cangefon();
}

void dopicmod()
{
	unsigned int i,j,c16;
	unsigned char c8;
	if(pic_mod!=2)
	{
		if(zoom_mod==0)
			for(i=0;i<premsz/4;i++)
			{
				switch(pic_mod)
				{
					case 0:
						c8=(premap[i*4+2] & 0xE0);
						c8|=((premap[i*4+1]>>3)&0x1C);
						c8|=((premap[i*4+0]>>6)&0x3);
						picmap[i]=c8;
						break;
					 case 1:
						c16=((premap[i*4+2]<<8)&0xF800);
						c16|=((premap[i*4+1]<<3)&0x7E0);
						c16|=((premap[i*4+0]>>3)&0x1F);
						memcpy(picmap+i*2, &c16, 2);
						break;
				}
			}
		else
			for(i=0; i<pic_h; i++)
				for(j=0; j<pic_w; j++)
				{
					switch(pic_mod)
					{
						case 0:
							c8=(premap[i*4*pic_w+j*4+2] & 0xE0);
							c8|=((premap[i*4*pic_w+j*4+1]>>3)&0x1C);
							c8|=((premap[i*4*pic_w+j*4+0]>>6)&0x3);			
							picmap[i*pic_w*4+j*2]=c8;
							picmap[i*pic_w*4+j*2+1]=c8;
							picmap[i*pic_w*4+pic_w*2+j*2]=c8;
							picmap[i*pic_w*4+pic_w*2+j*2+1]=c8;
							break;
						case 1:
							c16=((premap[i*4*pic_w+j*4+2]<<8)&0xF800);
							c16|=((premap[i*4*pic_w+j*4+1]<<3)&0x7E0);
							c16|=((premap[i*4*pic_w+j*4+0]>>3)&0x1F);
							memcpy(picmap+i*pic_w*8+j*4, &c16, 2);
							memcpy(picmap+i*pic_w*8+j*4+2, &c16, 2);
							memcpy(picmap+i*pic_w*8+pic_w*4+j*4, &c16, 2);
							memcpy(picmap+i*pic_w*8+pic_w*4+j*4+2, &c16, 2); 
							break;
					}
				}
	}
	else
	{
		if(zoom_mod==0) memcpy(picmap, premap, premsz);
		else 
			for(i=0; i<pic_h; i++)
				for(j=0; j<pic_w; j++)
				{
					memcpy(picmap+i*pic_w*16+j*8, premap+i*pic_w*4+j*4, 4);
					memcpy(picmap+i*pic_w*16+j*8+4, premap+i*pic_w*4+j*4, 4);
					memcpy(picmap+i*pic_w*16+pic_w*8+j*8, premap+i*pic_w*4+j*4, 4);
					memcpy(picmap+i*pic_w*16+pic_w*8+j*8+4, premap+i*pic_w*4+j*4, 4);
				}
	}
}

void crpic()
{
	int i;
	msz=pic_w*pic_h*map_mod[pic_mod+3];
	if(zoom_mod) picmap=malloc(msz*4);
	else picmap=malloc(msz);
	if(!open)
	{
		premsz=pic_w*pic_h*4;
		premap=malloc(premsz);
		for (i=0;i<premsz/4;i++)
		{
			memcpy(premap+i*4, &COL[2][2], 1);
			memcpy(premap+i*4+1, &COL[2][1], 1);
			memcpy(premap+i*4+2, &COL[2][0], 1);
			memcpy(premap+i*4+3, &COL[2][3], 1);
		}
	}
				pic1.w=pic_w*(zoom_mod+1);
				pic1.h=pic_h*(zoom_mod+1);
				pic1.bpnum=map_mod[pic_mod];
	/* R=0;G=255;B=0;
	col=((B>31?31:B)+((G>63?63:G)<<5)+((R>31?31:R)<<11));
	for (i=800;i<1200;i++) memcpy(pic1map+i*2, &col, 2);
	R=255;G=0;B=0;
	col=((B>31?31:B)+((G>63?63:G)<<5)+((R>31?31:R)<<11));
	for (i=1200;i<1600;i++) memcpy(pic1map+i*2, &col, 2); */
	//pic1->bitmap=pic1map;
}


BMP_HDR rBMP;

int readBMP(const char *fname)
{
	int f, i;
	unsigned short isbmp;
	//char *rpicmap;
	unsigned int ul;
	if ((f=fopen(fname,A_ReadOnly+A_BIN,P_READ,&ul))!=-1)
	{
		fread(f,&isbmp,2,&ul);
		if(isbmp!=BMP_id) {fclose(f,&ul); return(2);}
		fread(f,&rBMP,52,&ul);
		if(rBMP.biBitCount!=32) {fclose(f,&ul); return(3);}
		premsz=rBMP.size-54;
		pic_w=rBMP.Width;
		pic_h=rBMP.Height;
		//rpicmap=malloc(premsz);
		premap=malloc(premsz);
		for(i=0; i<pic_h; i++) fread(f,premap+premsz-(i+1)*pic_w*4, pic_w*4,&ul);
		fclose(f,&ul);
	}
	else return(1);
	return(0);
}

/* void crBMP()
{
	
} */
BMP_HDR wrBMP;

void saveBMP()
{
	int i;
	char *wrpicmap=malloc(premsz);
	for(i=0; i<pic_h; i++) memcpy(wrpicmap+i*pic_w*4, premap+premsz-(i+1)*pic_w*4, pic_w*4);
	wrBMP.size=premsz+54;
	wrBMP.zero_res=0;
	wrBMP.offbits=54;
	wrBMP.biSize=40;
	wrBMP.Width=pic_w;
	wrBMP.Height=pic_h;
	wrBMP.biPlanes=1;
	wrBMP.biBitCount=32;
	wrBMP.biCompression=0;
	wrBMP.biSizeImage=0;
	wrBMP.biXPelsPerMeter=0xB40;
	wrBMP.biYPelsPerMeter=0xB40;
	wrBMP.biClrUsed=0;
	wrBMP.biClrImportant=0;

	TDate date;
	TTime time; 
	GetDateTime(&date,&time);
	char w[32];
	char fname[256];
	
	
	sprintf( w, "%02i%02i-%i%02i%02i", date.month,date.day, time.hour,time.min,time.sec );
	strcpy(fname,SAVE_PATH);
	i=strlen(fname);
	sprintf( fname+i, "pic_%s.bmp", w );

	int f;
	unsigned int ul;
	unlink(fname,&ul);
	if ((f=fopen(fname,A_ReadWrite+A_Create+A_Truncate,P_READ+P_WRITE,&ul))!=-1)
    {
      fwrite(f,&BMP_id,2,&ul);
      fwrite(f,&wrBMP,52,&ul);
	  fwrite(f,wrpicmap,premsz,&ul);
      fclose(f,&ul);
	  ShowMSG(1, (int)"���������");
    }
	else MsgBoxError(0, (int)"������ ������ �����!!!");
	mfree(wrpicmap);
}
