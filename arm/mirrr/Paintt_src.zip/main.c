#include "../inc/swilib.h"
#include "conf_loader.h"
#include "version.h"
#include "image.c"
#include "menu.c"

extern void kill_data(void *p, void (*func_p)(void *));
const int minus11=-11;

GBSTMR drcur;

typedef struct
{
  CSM_RAM csm;
  int view_id;
}MAIN_CSM;


//===============================================================================================
typedef struct
{
  GUI gui;
}VIEW_GUI;

void DrwImg(IMGHDR *img, int x, int y, char *pen, char *brush)
{
  RECT rc;
  DRWOBJ drwobj;
  StoreXYWHtoRECT(&rc,x,y,img->w,img->h);
  SetPropTo_Obj5(&drwobj,&rc,0,img);
  SetColor(&drwobj,pen,brush);
  DrawObject(&drwobj);
}

void DrawCur()
{
	if (gst==2)
	{
		crp++;
		if(crp>2) crp=0;
		/* DrawRectangle(11+(zoom_mod+1)*(cur_x-2),YDISP+ots_h+(zoom_mod+1)*cur_y,
				11+(zoom_mod+1)*(cur_x-2)+1,YDISP+ots_h+(zoom_mod+1)*cur_y+1,
				5,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(0));
		DrawRectangle(11+(zoom_mod+1)*(cur_x+2),YDISP+ots_h+(zoom_mod+1)*cur_y,
				11+(zoom_mod+1)*(cur_x+2)+1,YDISP+ots_h+(zoom_mod+1)*cur_y+1,
				5,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(0));
		DrawRectangle(11+(zoom_mod+1)*cur_x,YDISP+ots_h+(zoom_mod+1)*(cur_y-2),
				11+(zoom_mod+1)*cur_x+1,YDISP+ots_h+(zoom_mod+1)*(cur_y-2)+1,
				5,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(0));
		DrawRectangle(11+(zoom_mod+1)*cur_x,YDISP+ots_h+(zoom_mod+1)*(cur_y+2),
				11+(zoom_mod+1)*cur_x+1,YDISP+ots_h+(zoom_mod+1)*(cur_y+2)+1,
				5,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(0)); */
		DrawRectangle(11+(zoom_mod+1)*cur_x, YDISP+ots_h+(zoom_mod+1)*cur_y,
				11+(zoom_mod+1)*cur_x+zoom_mod, YDISP+ots_h+(zoom_mod+1)*cur_y+zoom_mod,
				1,dop_col0[crp],dop_col0[crp]);
		GBS_StartTimerProc(&drcur, TMR_SECOND/3, DrawCur);
	}
} 

 //Redraw
static void _GUIRedraw(VIEW_GUI *data) //Redraw
{
	if (data->gui.state==2)
	{
		DrawRectangle(0,YDISP, scr_w,scr_h, 0,GetPaletteAdrByColorIndex(1),GetPaletteAdrByColorIndex(1));
		dopicmod();
		pic1.bitmap=(char *)picmap;
		
		DrawRectangle(10,YDISP+ots_h-1,11+(zoom_mod+1)*(pic_w),YDISP+ots_h+(zoom_mod+1)*(pic_h),3,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(3));
		DrwImg((IMGHDR *)&pic1, 11, YDISP+ots_h, GetPaletteAdrByColorIndex(0), GetPaletteAdrByColorIndex(1));
		if(inst_mod>0) do_inst();
		DrawCur();
		
		DrawRectangle(scr_w-40,scr_h-20,scr_w-4,scr_h-2,0,COL[2],COL[2]);
		DrawRectangle(scr_w-20,scr_h-11,scr_w-5,scr_h-3,0,COL[1],COL[1]);
		DrawRectangle(scr_w-39,scr_h-19,scr_w-18,scr_h-8,0,COL[0],COL[0]);

		WSHDR *ws=AllocWS(256);
		wsprintf(ws,"%d - %d",cur_x,cur_y);
		DrawString(ws,3,scr_h-2*ots_h,scr_w,scr_h,FONT_SMALL,1,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
		wsprintf(ws,"%d,%t",inst_mod,instmitem[inst_type]);
		DrawString(ws,3,YDISP,scr_w,YDISP+ots_h,FONT_SMALL,1,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
		wsprintf(ws,perc_t,"����");
		DrawString(ws,3,scr_h-ots_h,scr_w/2,scr_h,FONT_SMALL,1,GetPaletteAdrByColorIndex(0),GetPaletteAdrByColorIndex(23));
		FreeWS(ws);
	}
}

 //Create
static void _GUICreate(VIEW_GUI *data,void *(*malloc_adr)(int)) //Create
{
	scr_w=ScreenW()-1;
	scr_h=ScreenH()-1;
	sk_h=SoftkeyH()-1;
	pic_mod=DEF_PICT_MOD;
	zoom_mod=DEF_ZOOM_MOD;
	if(open) {startt=0; start=1; crpic();}
	else create_picm();
	ots_h=GetFontYSIZE(FONT_SMALL)+2;
	cur_x=0;
	cur_y=0;
	data->gui.state=1;
	gst=1;
}

 //Close
static void _GUIClose(VIEW_GUI *data,void (*mfree_adr)(void *))
{
	mfree(premap);
	mfree(picmap);
	data->gui.state=0;
	gst=0;
}

 //Focus
static void _GUIFocus(VIEW_GUI *data,void *(*malloc_adr)(int),void (*mfree_adr)(void *))
{
	DisableIDLETMR();
	data->gui.state=2;
	gst=2;
}

 //Unfocus
static void _GUIUnfocus(VIEW_GUI *data,void (*mfree_adr)(void *))
{
  if (data->gui.state!=2)
    return;
  data->gui.state=1;
	gst=1;
}

 //OnKey
static int _GUIOnKey(VIEW_GUI *data,GUI_MSG *msg)
{
	if (Quit) return(1);
  int m=msg->gbsmsg->msg;
  if (m==KEY_DOWN)
  {
	switch(msg->gbsmsg->submess)
	{
	case UP_BUTTON:
	case '2':
		if(cur_y<=0) cur_y=pic_h-1;
		else cur_y--;
      break;
    case DOWN_BUTTON:
	case '8':
		if(cur_y>=pic_h-1) cur_y=0;
		else cur_y++;
      break;
    case LEFT_BUTTON:
	case '4':
		if(cur_x<=0) cur_x=pic_w-1;
		else cur_x--;
      break;
    case RIGHT_BUTTON:
	case '6':
		if(cur_x>=pic_w-1) cur_x=0;
		else cur_x++;
      break;
	case '1':
		if(cur_y<=0) cur_y=pic_h-1;
		else cur_y--;
		if(cur_x<=0) cur_x=pic_w-1;
		else cur_x--;
	  break;
	case '3':
		if(cur_y<=0) cur_y=pic_h-1;
		else cur_y--;
		if(cur_x>=pic_w-1) cur_x=0;
		else cur_x++;
		break;
	case '7':
		if(cur_y>=pic_h-1) cur_y=0;
		else cur_y++;
		if(cur_x<=0) cur_x=pic_w-1;
		else cur_x--;
		break;
	case '9':
		if(cur_y>=pic_h-1) cur_y=0;
		else cur_y++;
		if(cur_x>=pic_w-1) cur_x=0;
		else cur_x++;
		break;
    case LEFT_SOFT:
		inst_mod=0;
		create_mm();
      break;
	case ENTER_BUTTON:
	case '5':
		set_point();
	  break;
    case GREEN_BUTTON:
			////
      break;
    case RIGHT_SOFT:
		cangecol();
      break;
    case RED_BUTTON:
		inst_mod=0;
		MsgBoxYesNo(1,(int)"�����?",ExitProc);
		break;
	case '0':
		switch(zoom_mod)
		{
			case 0:
				pic1.w=pic_w*2;
				pic1.h=pic_h*2;
				//pic1.bpnum=map_mod[pic_mod];
				zoom_mod=1;
				mfree(picmap);
				picmap=malloc(msz*4);
				break;
			case 1:
				pic1.w=pic_w;
				pic1.h=pic_h;
				//pic1.bpnum=map_mod[pic_mod];
				zoom_mod=0;
				mfree(picmap);
				picmap=malloc(msz);
				break;
		}
		break;
	case '*':
		inst_mod=0;
		create_colm();
		break;
	case '#':
		inst_mod=0;
		create_instm();
		break;
      //return(1); //���������� ����� GeneralFunc ��� ���. GUI -> �������� GUI
    }
  }
  if(m==LONG_PRESS)
  {
	if(inst_mod==1)
	{
		switch(msg->gbsmsg->submess)
		{
			case UP_BUTTON:
			case '2':
				if(cur_y<=0) cur_y=pic_h-1;
				else cur_y--;
		      break;
		    case DOWN_BUTTON:
			case '8':
				if(cur_y>=pic_h-1) cur_y=0;
				else cur_y++;
		      break;
		    case LEFT_BUTTON:
			case '4':
				if(cur_x<=0) cur_x=pic_w-1;
				else cur_x--;
		      break;
		    case RIGHT_BUTTON:
			case '6':
				if(cur_x>=pic_w-1) cur_x=0;
				else cur_x++;
		      break;
			case '1':
				if(cur_y<=0) cur_y=pic_h-1;
				else cur_y--;
				if(cur_x<=0) cur_x=pic_w-1;
				else cur_x--;
			  break;
			case '3':
				if(cur_y<=0) cur_y=pic_h-1;
				else cur_y--;
				if(cur_x>=pic_w-1) cur_x=0;
				else cur_x++;
				break;
			case '7':
				if(cur_y>=pic_h-1) cur_y=0;
				else cur_y++;
				if(cur_x<=0) cur_x=pic_w-1;
				else cur_x--;
				break;
			case '9':
				if(cur_y>=pic_h-1) cur_y=0;
				else cur_y++;
				if(cur_x>=pic_w-1) cur_x=0;
				else cur_x++;
				break;
		}
	}
	else
	{
		switch(msg->gbsmsg->submess)
		{
		case UP_BUTTON:
		case '2':
			if(cur_y<=5) cur_y=pic_h-1;
			else cur_y-=5;
	      break;
	    case DOWN_BUTTON:
		case '8':
			if(cur_y>=pic_h-6) cur_y=0;
			else cur_y+=5;
	      break;
	    case LEFT_BUTTON:
		case '4':
			if(cur_x<=5) cur_x=pic_w-1;
			else cur_x-=5;
	      break;
	    case RIGHT_BUTTON:
		case '6':
			if(cur_x>=pic_w-6) cur_x=0;
			else cur_x+=5;
	      break;
		case '1':
			if(cur_y<=0) cur_y=pic_h-1;
			else cur_y-=5;
			if(cur_x<=0) cur_x=pic_w-1;
			else cur_x-=5;
		  break;
		case '3':
			if(cur_y<=0) cur_y=pic_h-1;
			else cur_y-=5;
			if(cur_x>=pic_w-1) cur_x=0;
			else cur_x+=5;
			break;
		case '7':
			if(cur_y>=pic_h-1) cur_y=0;
			else cur_y+=5;
			if(cur_x<=0) cur_x=pic_w-1;
			else cur_x-=5;
			break;
		case '9':
			if(cur_y>=pic_h-1) cur_y=0;
			else cur_y+=5;
			if(cur_x>=pic_w-1) cur_x=0;
			else cur_x+=5;
			break;
		}
	}
  }
  DirectRedrawGUI();
  return(0);
}

static int method8(void){return(0);}

static int method9(void){return(0);}

static const void * const gui_methods[11]={
  (void *)_GUIRedraw,
  (void *)_GUICreate,
  (void *)_GUIClose,
  (void *)_GUIFocus,
  (void *)_GUIUnfocus,
  (void *)_GUIOnKey,
  0,
  (void *)kill_data, //method7, //Destroy
  (void *)method8,
  (void *)method9,
  0
};

static void maincsm_oncreate(CSM_RAM *data)
{
  static const RECT Canvas={0,0,0,0};
  MAIN_CSM *csm=(MAIN_CSM*)data;
  VIEW_GUI *view_gui=malloc(sizeof(VIEW_GUI));
  zeromem(view_gui,sizeof(VIEW_GUI));
  patch_rect((RECT*)&Canvas,0,0,ScreenW()-1,ScreenH()-1);
  view_gui->gui.canvas=(void *)(&Canvas);
//  view_gui->gui.flag30=2;
  view_gui->gui.methods=(void *)gui_methods;
  view_gui->gui.item_ll.data_mfree=(void (*)(void *))mfree_adr();
  csm->csm.state=0;
  csm->csm.unk1=0;
  csm->view_id=CreateGUI(view_gui);
}

static void Killer(void)
{
  extern void *ELF_BEGIN;
  kill_data(&ELF_BEGIN,(void (*)(void *))mfree_adr());
}

static void maincsm_onclose(CSM_RAM *csm)
{
  SUBPROC((void *)Killer);
}

static int maincsm_onmessage(CSM_RAM *data, GBS_MSG *msg)
{
  MAIN_CSM *csm=(MAIN_CSM*)data;
  if (msg->msg==MSG_GUI_DESTROYED)
  {
    if ((int)msg->data0==csm->view_id)
    {
		csm->csm.state=-3;
    }
  }
	if (Quit)
    {
		csm->csm.state=-3;
    }
  return(1);
}

static unsigned short maincsm_name_body[140];

static const struct
{
  CSM_DESC maincsm;
  WSHDR maincsm_name;
}MAINCSM =
{
  {
  maincsm_onmessage,
  maincsm_oncreate,
#ifdef NEWSGOLD
  0,
  0,
  0,
  0,
#endif
  maincsm_onclose,
  sizeof(MAIN_CSM),
  1,
  &minus11
  },
  {
    maincsm_name_body,
    NAMECSM_MAGIC1,
    NAMECSM_MAGIC2,
    0x0,
    139
  }
};

static void UpdateCSMname(void)
{
  WSHDR *ws=AllocWS(256);
  wsprintf((WSHDR *)(&MAINCSM.maincsm_name),"Paintt v%t",ver);
  FreeWS(ws);
}

int main(const char *exename, const char *filename)
{
	if(*(filename+1)==':')
	{
		open=1;
		int p=readBMP(filename);
		if(p>0)
		{
			switch(p)
			{
				case 1:
					LockSched();
				    ShowMSG(1,(int)"�� �����������!!!");
				    UnlockSched();
					break;
				case 2:
					LockSched();
				    ShowMSG(1,(int)"��� �� BMP!!!");
				    UnlockSched();
					break;
				case 3:
					LockSched();
				    ShowMSG(1,(int)"���������������� ������!!!");
				    UnlockSched();
					break;
			}
			SUBPROC((void *)Killer);
			return 0;
		}
		char dummy[sizeof(MAIN_CSM)];
		InitConfig();
		UpdateCSMname();
		LockSched();
		CreateCSM(&MAINCSM.maincsm,dummy,0);
		UnlockSched();
		return 0;
	}
	else
	{
		open=0;
		char dummy[sizeof(MAIN_CSM)];
		InitConfig();
	    UpdateCSMname();
	    LockSched();
	    CreateCSM(&MAINCSM.maincsm,dummy,0);
	    UnlockSched();
	}
  return 0;
}
