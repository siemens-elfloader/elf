#ifndef _MAINMENU_H_
  #define _MAINMENU_H_

int CreateMenuFindPlaylist();
void StopRewind();
void StartRewind();
void Play_PauseResume();
void TogglePlayback();
void PlayNext();
void PlayPrevious();
void VolumeDown();
void VolumeUp();
void VolumeMute();
#endif
