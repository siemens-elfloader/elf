#include "..\inc\cfg_items.h"
#include "language.h"
#include "..\inc\swilib.h"

__root const CFG_HDR cfghdr_m11={CFG_LEVEL,"AudioBuffer",1,0};

__root const CFG_HDR ch1={CFG_UINT,"RAM AudBufOffset",0x00000000,0xFFFFFFFF};
__root const unsigned int audcfg=0xA8F59C3C;

__root const CFG_HDR cfghdr_m10={CFG_LEVEL,"",0,0};
