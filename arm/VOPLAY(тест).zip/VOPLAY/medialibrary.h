#ifndef _MAINMENU_H_
  #define _MAINMENU_H_

int CreateMediaLibrary(char *foldeer);
void BEER(char *foldeer);


#endif
