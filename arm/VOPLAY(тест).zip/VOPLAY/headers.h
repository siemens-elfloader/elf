void GetBit(char *fname);
int GetTime(char *fname);
