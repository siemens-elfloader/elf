#define ipc_extraplay "IVOPLAY_PLUGIN"
#define IPC_MY_NAME "IVOPLAY"
//ExtraPlay
#define CMD_NEXT 1 //short
#define CMD_PREV 2 //short
#define CMD_PLAY_PAUSE 3 //short
#define CMD_VOLUP 4 //short
#define CMD_VOLDOWN 5 //short
#define CMD_MUTE 6 //short
#define CMD_STOP 7 //short
#define CMD_KILL 25 //integer

//Xtask
//#define PLAYER_IDLE 15
//#define PLAYER_SHOW 16
#define PLAYER_PAUSE 17
#define PLAYER_RUN 21
#define PLAYER_CLOSE 22
