void write_total();
