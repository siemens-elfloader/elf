
//short ParseOneFrameBits( Word16* serial, AMRStruct* AmrStruct, short nChannel ) ;

//short CombineOneFrameBits(	Word16* serial,	AMRStruct* AmrStruct,	enum TXFrameType tx_type,	enum Mode mode,	short nChannel );
