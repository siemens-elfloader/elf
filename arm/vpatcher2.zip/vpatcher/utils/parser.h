

int ReadPatchLines(char *fname,int type);
int ReadLine(char *str,int type);

