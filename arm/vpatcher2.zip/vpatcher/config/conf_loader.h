
#ifndef _CONFLOADER_H_
#define _CONFLOADER_H_
void InitConfig();
void OpenConfig();
#endif
