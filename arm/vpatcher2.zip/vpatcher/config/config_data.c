

#include "..\..\inc\cfg_items.h"
#include "..\..\inc\swilib.h"



__root const CFG_HDR cfghdr_0={CFG_STR_UTF8,"����� VKP",1, 255};
__root const char patcher_folder[256]="0:\\Zbin\\Patches\\vkp\\";

