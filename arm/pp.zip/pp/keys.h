void left_but()
{
    if (status==menu)
    {
        if (cur_y==53){if(sp==2){sp=1;}}
        if (cur_y==93){ if(saveload==1){saveload=2; }}
        if (cur_y==133){ if(mode==1){mode=0; lives1=0;raz=0;sp=1;}}
        RedrawScreen();
    }
        if (status==settings_igra)
    {
        if (cur_ys==73){ if(diff==1){diff=0; } if(diff==2){diff=1;}}
        if (cur_ys==133){ if(sk==1){sk=0;} if(sk==2){sk=1;} if(sk==3){sk=2;}   }
        if (cur_ys==193&mode==0) { lives1--;if (lives1<1)lives1=99;}
        RedrawScreen();
    }
        if (status==music)
    {
        if (cur_ym==113){if(on_off_sound==0){on_off_sound=1;}}
        if (cur_ym==153){if(chek==1){chek=0;}}
        if (cur_ym==233) { def_vol--;if (def_vol<0)def_vol=6; }
        RedrawScreen();
    }
    if (status==game)
	{
        if (user[x]!=1){user[dx]=1;}
        else {user[dx]=0;}
	}
    
}
void right_but()
{
      if (status==menu)
    {
       if (cur_y==53){if(sp==1){sp=2;}}
       if (cur_y==93){ if(saveload==2){saveload=1; }}
       if (cur_y==133){if(mode==0){mode=1;lives1=7;raz=0;sp=1;}}
       RedrawScreen();
    }
       if (status==settings_igra)
    {
       if (cur_ys==73){ if(diff==1){diff=2; } if(diff==0){diff=1;}}
       if (cur_ys==133){ if(sk==2){sk=3;} if(sk==1){sk=2;} if(sk==0){sk=1;}   }
       if (cur_ys==193&mode==0) { lives1++; if (lives1>99)lives1=1;}
       RedrawScreen();
    }
       if (status==music)
    {
       if (cur_ym==113){if(on_off_sound==1){on_off_sound=0;}}
       if (cur_ym==153){if(chek==0){chek=1;}}
       if (cur_ym==233) { def_vol++; if (def_vol>6)def_vol=0;}
       RedrawScreen();
    }
       if (status==game)
    {
       if (user[x]!=max_width-user[width]-1){user[dx]=2;}
       else {user[dx]=0;}
    }
}
void up_but()
{
        if(isloadlang==1)
    {
        lang_y=lang_y-40; if (lang_y<113){lang_y=153;}
        if(lang_y==113){switchlang=0;}
        if(lang_y==153){switchlang=1;}
        loading();
    }
        if (status==menu)
    {
        cur_y=cur_y-40; if (cur_y<53){cur_y=253;}
        RedrawScreen();
    }
        if (status==settings)
    {
        cur_ys1=cur_ys1-60; if (cur_ys1<73){cur_ys1=133;}
        RedrawScreen();
    }
        if (status==settings_igra)
    {
        cur_ys=cur_ys-60; if (cur_ys<73){cur_ys=193;}
        if (cur_ys==193&mode==0){cur_ys=133;}
        RedrawScreen();
    }
       if (status==music)
    {
       cur_ym=cur_ym-40; if (cur_ym<113){cur_ym=233;}
       if (on_off_sound==0){cur_ym=113;}
       if (cur_ym==193){cur_ym=153;}
       RedrawScreen();
    }
}
void down_but()
{
        if(isloadlang==1)
     {
        lang_y=lang_y+40; if (lang_y>153){lang_y=113;}
        if(lang_y==113){switchlang=0;}
        if(lang_y==153){switchlang=1;}
        loading();
     }
         if (status==menu)
    {
        cur_y=cur_y+40; if (cur_y>253){cur_y=53;}
        RedrawScreen();
    }
        if (status==settings)
    {
        cur_ys1=cur_ys1+60; if(cur_ys1>133){cur_ys1=73;}
        RedrawScreen();
    }
        if (status==settings_igra)
    {
        cur_ys=cur_ys+60; if(cur_ys>193){cur_ys=73;}
        if (cur_ys==193&mode==0){cur_ys=73;}
        RedrawScreen();
    }
       if (status==music)
    {
         cur_ym=cur_ym+40; if (cur_ym>233){cur_ym=113;}
         if (on_off_sound==0){cur_ym=113;}
         if (cur_ym==193){cur_ym=233;}
         RedrawScreen();
    }
}
void test2()
{
  SUBPROC((void *)create_connect,SEND);
}
void enter_but()
{
          if(isloadlang==1)
      {
         if(lang_y==113){langenru=0;}
         if(lang_y==153){langenru=1;} 
         lan=1; lgpInitLangPack();savelang();loadNastr(); isloadlang=0;  T_Load_IMG();IsLoadGraph=1;
         loading();
      }
          if (status==menu)
    {
        if(cur_y==53){test2();startcont();}
        if (cur_y==253)exit();
        if (cur_y==93){if (saveload==1){saveSettings();}if (saveload==2){loadSettings();sp=2;}}
        if (cur_y==173){saveNastr();loadNastr();  status=rec;}
        if(cur_y==213&&nad==0){status=settings;nad=1;}
        RedrawScreen();
    }
        if (status==settings)
    {
      if(cur_ys1==73&&nad==1){status=settings_igra;}   
      if(cur_ys1==133&&nad==1){status=music;}
      RedrawScreen();
    }
}
void left_soft()
{
         if (status==load)
       {
         openconf();
       }
         if (status==game)
       {
        PlayMelody_PausePlayback(PLAY_ID);  status=menu;if(mode==0){saveNastr();}raz=1;  sp=2;
        RedrawScreen();
       }
}
void right_soft()
{
         if (status==load)
       {
         exit();
       }
           if (status==settings)
    {
       status=menu;nad=0; 
       RedrawScreen();
    }
        if (status==settings_igra)
    {
       status=settings; cur_ys=73;
       RedrawScreen();
    }
       if (status==music)
    {
      status=settings;
      RedrawScreen();
    }
       	if (status==game)
	{
          exit();
        }
           if (status==rec)
	{
          status=menu;
          RedrawScreen();
        }
}
void green_but()
{
     	if (status==game)
	{
           if (running==1) theme_tick=0;theme_time=0; game_time_m_sec=0;setgame(1); nado=0; 
        }
        if(status==rec)
        {
          pusto=1;  saveNastr(); ShowMSG(1,(int)lgpData[LGP_NASTR_RELOAD]); pusto=0;
          RedrawScreen();
        }
}
void five_but()
{
     	if (status==game)
	{
          if(tme==0){tme=1;}else{tme--;}
        }
}
void zero()
{
  setpause();  if (running==0){ PlayMelody_PausePlayback(PLAY_ID); } if (running==1) { PlayMelody_ResumePlayBack(PLAY_ID);}
}
