int f;
savec()
{
sprintf(save_folder,per_s,folder,"save\\savedata.temp");
 f = fopen(save_folder,A_WriteOnly+A_BIN+A_Create+A_Truncate,P_WRITE,&err);
{
fwrite(f,&user[x],4,&err);
fwrite(f,&user[lifetime],2,&err);
fwrite(f,&user[speed],2,&err);
fclose(f,&err);
}
}

loadc()
{
sprintf(save_folder,per_s,folder,"save\\savedata.temp");
 f = fopen(save_folder,A_ReadOnly+A_BIN,P_READ,&err);
{
fread(f,&cpu[x],4,&err);
fread(f,&cpu[lifetime],2,&err);
fread(f,&cpu[speed],2,&err);
fclose(f,&err);
}}
