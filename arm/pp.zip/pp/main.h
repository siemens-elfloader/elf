//��������� + ����
#include "C:\arm\inc\swilib.h"
typedef unsigned short byte;
byte status,gamemode,change,user[8],cpu[7],AI_line,all_lives,AI_lines,all_point;
int DNR_TRIES;
void create_connect();
void free_buffers();
int connect_state;
int receive_mode;
void send_req();
enum{SEND,RECV};
extern void resend();
char *end_answer;

//////////////////////////////////////////////////////
const int rndtable[64]={//������� �������
 0,  1,  6, -3,  7, -2,  5, -1,  3,  4,  2, -7, -5,  0,  4,  1,
 3, -4,  4,  6, -1,  2,  7, -3, -7, -5, -3,  0,  3,  0,  2,  4,
-7,  1,  5,  3,  0,  2, -5, -2,  5,  7, -1,  2, -5,  3,  1,  4,
-3, -7,  2,  6,  0, -2,  1,  3,  5, -4, -1,  2,  0, -3,  4, -6
};
int rndindex=0;
char bgcol2[16]={1,1,1,100};
volatile int running=0; // ���� ����������
const int CLR=0, PUSH=1;
enum {x=0,y=1,height,width,speed,lifetime,round,dx,dy}; //����� ��������� ��� ������ � ����
enum {load,menu,settings,settings_igra,music,game,game1,rec,LANG}; //��������� ��� ����
enum {lives,points,car}; // ������ ����
char bgcol5[4]={30,30,30,30};
int i1=0;
void exit();
void startcont();
int openconf();
int ex;
char logmsg[256];
////////////////////////////////////////////////////////////////
TTime time; //������������� �������
/////////////////////////////////////////////////////////////////
int max_height=320, max_width=240, cur_x=30, cur_y=53, cur_ys=73,cur_ys1=73, cur_yo=73,cur_yg=73, cur_ym=113, lang_y=113,key_y=73, ball[9];
int point_x=120, point_x2=50;
int car_lev=1;
static const RECT iconbar_bnet={200,5,235,17};
int timer_speed=7;
int main_y1=60, main_y2=100, main_y3=140, main_y4=180,main_y5=220,main_y6=260;
int set_y1=80,set_y2=140,set_y3=110;
int seti_y1=50,seti_y2=80,seti_y3=110,seti_y4=140,seti_y5=170,seti_y6=200;
int music_y1=80,music_y2=80+40,music_y3=80+80,music_y4=80+120,music_y5=80+160;
int ic_y=22,time_x=140;//time_x=100;
#define FONT 9//9 �����
extern char lang_file[];
int diff=0, lives1=7, mode=0, sk=0, pusto=0, gdy, recors=0;
int theme_tick=0, theme_time=0, game_time_m_sec=0,theme_time_chas=0, tme;
int point1, point2, point3, point4, point5;
int def_vol=0, on_off_sound=0, chek=0, PLAY_ID=0xFFF, soun,  saveload=1;
int IsLoadGraph=0,isloadlang=0, img_count;
int color_frame[8]={23,23,23,23,23,23,23,23};
int sp=1,langg=3;
int logot=1;
int IsMenu=1;
int nado=0;
int exit_ungraf=0;
int switchlang=0;
int lan=0;
int langenru;
int raz=0;
///////////////////////////////////////////////////////
//�� �������
extern const int bar;
extern const char ICONBAR_BNET_FRCOL[4];
extern const char ICONBAR_BNET_BGCOL[4];
extern const char ICONBAR_BNET_FILLCOL[4];
extern const char folder[128];
extern const char name[15];
char name2copy[15];
extern void InitConfig();
extern const char bgcol[4];
extern const char linecol[4];
extern const char linecol2[4];
extern const unsigned int bg;
/////////////////////////////////////////
int xxx;
const char perc_tdt[]="%d%t";
const char perc_tdtdt[]="%d%t%d%t";
const char perc_tdtdtd[]="%d%t%d%t%d%t";
const char perc_tt[]="%t%t";
const char times[]="%d:%02d";
const char perc_t[]="%t";
const char per_s[]="%s%s";
/////////////////////////////////
char name1[15], name2[15], name3[15], name4[15], name5[15], nameA[15],name_user2[15];
char icon_folder[128],  nastr_folder[128], sound_folder[128], save_folder[128];
char USER[128], CPU[128], BALL[128], fon[128], logo[128], cur[128];
///////////////////////////////////////////////////////////////
GBSTMR tmr2;//�������
GBSTMR load_img;
GBSTMR tmr;
GBSTMR bt;

int pbuf;
void get_data();
////////////////////////////
extern int _done[8];
extern int error_count;
/////////////////////////////
void drawbox(int x0, int y0, int height, int width, int color);
void move_block();
void shift_block();
void move_ball();
void AI();
void win();
void setgame(byte newgame);
void setpause();
void outtextxy(int x, int y, char* str,int font,int color);
void gameover();
void nextlev(int lev);
void stop();
void stop1();
void OnRedraw();
void DrawBG();
void UpdateCSMname();
void DisableIconbar();
void Play();
void DrawIconbar();
void loading();
int nad=0;
void RedrawScreen();
int DRE(int x, int color);
void TimeGame();
void next();

extern void Load_IMG(int flag);
//////////////////////////////
unsigned err;//������ ���.

void spr()//��� ����...
 {
  sprintf(logo,"%s%s",folder,"img\\logo.png");
  sprintf(cur,"%s%s",folder,"img\\cursor.png");
  sprintf(fon,"%s%s",folder,"img\\fon.png");
  sprintf(CPU,"%s%s",folder,"img\\user2.png");
  sprintf(USER,"%s%s",folder,"img\\user1.png");
  sprintf(BALL,"%s%s",folder,"img\\ball.png");
  user[width]=GetImgWidth((int)USER);
  user[height]=GetImgHeight((int)USER);
  cpu[width]=GetImgWidth((int)CPU);
  cpu[height]=GetImgHeight((int)CPU);
 }

int get_path_from_url(char *dest, const char *source)
{
  
  char *s1;
  int c;
  int len=0;
  const char *s2=source;
  while((s1=strchr(s2, '/')))
  {
    s2=s1;
    if (*(s2+1)!='/') break;
    s2+=2;
  }   
  while((c=*s2++))
  {
    *dest++=c;
    len++;
  }
  *dest=0;
  return (len);   
}

int get_host_from_url(char *dest, const char *source)
{
  char *s1;
  int len=0;
  int c;
  const char *s2=source;
  if ((s1=strchr(s2, ':')))
  {
    if (*(s1+1)=='/' && *(s1+2)=='/')
    {
      s2=s1+3;
    }
  }
  while((c=*s2++))
  {
    if (c=='/' || c==':') break;
    *dest++=c;
    len++;
  }
  *dest=0;
  return (len); 
}
