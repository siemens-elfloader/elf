void T_Load_IMG()//�������� � ������
{
  
  WSHDR *ws_load = AllocWS(128);
  #ifdef ELKA//���� ����,�� ��������� �������
 DisableIconBar(1);
 #endif
  img_count++;
  Load_IMG(img_count);
  loading();
  if(img_count==6)
  {
    IsLoadGraph=0;
    isloadlang=0;
    if(error_count==0)
    {
    GBS_DelTimer(&load_img);
    status=menu;
    RedrawScreen();
   
   
    if(langg==1||langg==2){langg=0;}
   

  
    }
 
  }
  else{
    GBS_StartTimerProc(&load_img, 216/8, T_Load_IMG);}
  
  
  FreeWS(ws_load);
}

void Menu()
{
WSHDR *ws_menu = AllocWS(128);

if(sp==1&&raz==1)wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NEWGAME]);
if(sp==1&&raz==0)wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NEWGAME2]);
if(sp==2)wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_CONT]);

DrawString(ws_menu,0,main_y1,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

if (saveload==1) {wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_SAVE]);}  
if (saveload==2) {wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_LOAD]);} 
DrawString(ws_menu,2,main_y2,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

if (mode==1) wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_LIVES]);  
if (mode==0) wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_POINTS]); 
DrawString(ws_menu,2,main_y3,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_RECORD]);
DrawString(ws_menu,0,main_y4,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR]);
DrawString(ws_menu,0,main_y5,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_EXIT]);
DrawString(ws_menu,0,main_y6,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

}









void Game()
{
   
   
  if (bg==0){DrawImg(0,0,(int)fon);}
  if (bg==1){DrawRoundedFrame(0,0,ScreenW(),ScreenH(),0,0,0,NULL,bgcol);}
  DrawIconbar();
  char s[8]; 
  TDate date; TTime time; 
  GetDateTime(&date,&time);
  sprintf(s,"%d:%02d",time.hour,time.min);  
  WSHDR *ws_time = AllocWS(64);
 if(theme_time_chas>60)
{
  wsprintf(ws_time,perc_tdtdtd,theme_time_chas," � ",theme_time," �",game_time_m_sec," �");
}
if(theme_time>60)
{
  wsprintf(ws_time,perc_tdtdt,theme_time," � ",game_time_m_sec," �");
}
else
{
 wsprintf(ws_time,perc_tdt,game_time_m_sec," �");
}
  if(tme==1){DrawString(ws_time,time_x-10, 1 ,199,1+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));}FreeWS(ws_time);
  if(tme==0){outtextxy(time_x,1,s,FONT,6);}
  DrawImg(cpu[x],cpu[y],(int)CPU);
  DrawImg(user[x],user[y],(int)USER);
  DrawImg(ball[x],ball[y],(int)BALL);
  user[width]=GetImgWidth((int)USER);
  user[height]=GetImgHeight((int)USER);
  cpu[width]=GetImgWidth((int)CPU);
  cpu[height]=GetImgHeight((int)CPU);
  DrawLine(1,((max_height-cpu[height]-user[height]-cpu[y])/2)+cpu[y],max_width-1,((max_height-cpu[height]-user[height]-cpu[y])/2)+cpu[y],0,linecol2);
  DrawLine(0,22,max_width,22,0,linecol);         
  DrawLine(0,1,max_width,1,0,linecol);
  DrawLine(1,0,1,max_height,0,linecol);
  DrawLine(max_width-1,0,max_width-1,max_height,0,linecol);
  DrawLine(0,max_height-1,max_width,max_height-1,0,linecol);
  move_ball();
  if (running==1) {if(user[dx]){move_block();}}
   
}

void RedrawScreen()//���������� ������� ����������� �������� ����
{
  if(ex){GeneralFuncF1(1);}
  if(langg==0)
  spr();
  WSHDR *ws_menu = AllocWS(128);
  WSHDR *ws = AllocWS(128);
  TDate date; TTime time; 
  GetDateTime(&date,&time);
  wsprintf(ws,"%d:%02d",time.hour,time.min);
  int xxx=(208-Get_WS_width(ws,FONT))/2;
  
 if (status==menu)
 {
DrawImg(0,0,(int)logo);
DrawString(ws,xxx,1,xxx+Get_WS_width(ws,FONT),1+GetFontYSIZE(FONT),FONT,TEXT_ALIGNLEFT,GetPaletteAdrByColorIndex(9),NULL);
DrawImg(cur_x,cur_y,(int)cur);
Menu();
}
if (status==settings)
{
DrawImg(0,0,(int)logo);
DrawString(ws,xxx,1,xxx+Get_WS_width(ws,FONT),1+GetFontYSIZE(FONT),FONT,TEXT_ALIGNLEFT,GetPaletteAdrByColorIndex(9),NULL);
DrawImg(cur_x,cur_ys1,(int)cur);
wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_IGRA]);
DrawString(ws_menu,0,set_y1,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SOUNDS]);
DrawString(ws_menu,0,set_y2,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
}

if (status==settings_igra)
{
  DrawImg(0,0,(int)logo);
  DrawString(ws,xxx,1,xxx+Get_WS_width(ws,FONT),1+GetFontYSIZE(FONT),FONT,TEXT_ALIGNLEFT,GetPaletteAdrByColorIndex(9),NULL);
  DrawImg(cur_x,cur_ys,(int)cur);
wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SLOJ]);
DrawString(ws_menu,0,seti_y1,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));

if (diff==0) {wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SLOJ_EASY]);}  
if (diff==1) {wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SLOJ_NORMAL]);} 
if (diff==2) {wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SLOJ_HARD]);}
DrawString(ws_menu,2,seti_y2,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SPEED]);
DrawString(ws_menu,0,seti_y3,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
if (sk==0) {wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SPEED_SLOW]);}  
if (sk==1) {wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SPEED_NORMAL]);} 
if (sk==2) {wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SPEED_FAST]);}
if (sk==3) {wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SPEED_VERYFAST]);}
DrawString(ws_menu,2,seti_y4,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_LIVES]);
DrawString(ws_menu,0,seti_y5 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));

if (mode==1)wsprintf(ws_menu,"%d",lives1); 
if (mode==0)wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_OBLOM]);
DrawString(ws_menu,0,seti_y6,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

 if (mode==1)wsprintf(ws_menu,perc_t,"<     >");
DrawString(ws_menu,0,seti_y6,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

}

if(status==music)
{
DrawImg(0,0,(int)logo);
  DrawImg(cur_x,cur_ym,(int)cur);
DrawString(ws,xxx,1,xxx+Get_WS_width(ws,FONT),1+GetFontYSIZE(FONT),FONT,TEXT_ALIGNLEFT,GetPaletteAdrByColorIndex(9),NULL);
wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SOUNDS_YESNO]);
DrawString(ws_menu,0,music_y1,max_width,max_width,FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
if (on_off_sound==0)wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SOUNDS_NO]); 
if (on_off_sound==1)wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SOUNDS_YES]);
DrawString(ws_menu,0,music_y2,max_width,max_width,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
if (chek==0)wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SOUNDS_SOUND]); 
if (chek==1)wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SOUNDS_MUSIC]);
DrawString(ws_menu,0,music_y3,max_width,max_width,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_SOUNDS_VOLUME]);
DrawString(ws_menu,0,music_y4,max_width,max_width,FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,"%d",def_vol);
DrawString(ws_menu,0,music_y5,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));

wsprintf(ws_menu,perc_t,"<     >");
DrawString(ws_menu,0,music_y5,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
}
if (status==rec){
  DrawImg(0,0,(int)logo);
  DrawString(ws,xxx,1,xxx+Get_WS_width(ws,FONT),1+GetFontYSIZE(FONT),FONT,TEXT_ALIGNLEFT,GetPaletteAdrByColorIndex(9),NULL);
    WSHDR *ws_menu = AllocWS(128);
  wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_RECODS]);
DrawString(ws_menu,0,17,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,"1.");
DrawString(ws_menu,35,37,35+Get_WS_width(ws_menu,FONT),37+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,"2.");
DrawString(ws_menu,35,67,35+Get_WS_width(ws_menu,FONT),67+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,"3.");
DrawString(ws_menu,35,97,35+Get_WS_width(ws_menu,FONT),97+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,"4.");
DrawString(ws_menu,35,127,35+Get_WS_width(ws_menu,FONT),127+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,"5.");
DrawString(ws_menu,35,157,35+Get_WS_width(ws_menu,FONT),157+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));
if (point1>0){
wsprintf(ws_menu,"%d",point1);
DrawString(ws_menu,point_x,37,point_x+Get_WS_width(ws_menu,FONT),37+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,name1);
DrawString(ws_menu,50,37 ,50+Get_WS_width(ws_menu,FONT),37+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));}
if(point1==0){
wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_RECODS_EMPTY]);
DrawString(ws_menu,point_x2,37,point_x2+Get_WS_width(ws_menu,FONT),37+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));}
if (point2>0){
wsprintf(ws_menu,"%d",point2);
DrawString(ws_menu,point_x,67,point_x+Get_WS_width(ws_menu,FONT),67+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,name2);
DrawString(ws_menu,50,67 ,50+Get_WS_width(ws_menu,FONT),67+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));}
if(point2==0){
wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_RECODS_EMPTY]);
DrawString(ws_menu,point_x2,67,point_x2+Get_WS_width(ws_menu,FONT),67+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));}
if (point3>0){
wsprintf(ws_menu,"%d",point3);
DrawString(ws_menu,point_x,97,point_x+Get_WS_width(ws_menu,FONT),97+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,name3);
DrawString(ws_menu,50,97 ,50+Get_WS_width(ws_menu,FONT),97+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));}
if(point3==0){
wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_RECODS_EMPTY]);
DrawString(ws_menu,point_x2,97,point_x2+Get_WS_width(ws_menu,FONT),97+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));}
if (point4>0){
wsprintf(ws_menu,"%d",point4);
DrawString(ws_menu,point_x,127,point_x+Get_WS_width(ws_menu,FONT),127+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,name4);
DrawString(ws_menu,50,127 ,50+Get_WS_width(ws_menu,FONT),127+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));}
if(point4==0){
wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_RECODS_EMPTY]);
DrawString(ws_menu,point_x2,127,point_x2+Get_WS_width(ws_menu,FONT),127+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));}
if (point5>0){
wsprintf(ws_menu,"%d",point5);
DrawString(ws_menu,point_x,157,point_x+Get_WS_width(ws_menu,FONT),157+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
wsprintf(ws_menu,perc_t,name5);
DrawString(ws_menu,50,157 ,50+Get_WS_width(ws_menu,FONT),157+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(3),GetPaletteAdrByColorIndex(23));}
if(point5==0){
wsprintf(ws_menu,perc_t,lgpData[LGP_MENU_NASTR_RECODS_EMPTY]);
DrawString(ws_menu,point_x2,157,point_x2+Get_WS_width(ws_menu,FONT),157+GetFontYSIZE(FONT),FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));}
 }

FreeWS(ws_menu);
FreeWS(ws);

   
  if(status==game){Game();
  if (running==1) {GBS_StartTimerProc(&tmr,timer_speed,RedrawScreen);}}
}
char bgcol3[4] = {30,30,30,100};
void loading()
{
  WSHDR *ws_menu = AllocWS(128);
spr();
  if(isloadlang==1){
DrawRoundedFrame(0,0,max_width,max_height,0,0,0,NULL,bgcol3);
DrawRoundedFrame(cur_x,lang_y,210,lang_y+30,0,0,0,NULL,bgcol2);
if(switchlang==0){wsprintf(ws_menu,perc_t,LGP_MENU_LANG1);}
if(switchlang==1){wsprintf(ws_menu,perc_t,LGP_MENU_LANG2);}
DrawString(ws_menu,0,max_height/4 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23)); 
wsprintf(ws_menu,perc_t,LGP_LANG_RU);
DrawString(ws_menu,0,max_height/4+40,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23)); 
wsprintf(ws_menu,perc_t,LGP_LANG_EN);
DrawString(ws_menu,0,max_height/4+80,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
 
  
  
  }
  
  if(IsLoadGraph==1)
{
  
  WSHDR *ws_load = AllocWS(128);
  int dlina=29*img_count;
  DrawRoundedFrame(0,0,max_width,max_height,0,0,0,NULL,bgcol);
 DrawRectangle(3,max_height/3+80,max_width-3,max_height/3+92,0,
		   GetPaletteAdrByColorIndex(2),
		   GetPaletteAdrByColorIndex(23));
 DrawRectangle(5,max_height/3+82,32+dlina,max_height/3+90,0,
		   GetPaletteAdrByColorIndex(2),
		   GetPaletteAdrByColorIndex(22));
  
   DRE(33,color_frame[1]);
   DRE(63,color_frame[2]);
   DRE(93,color_frame[3]);
   DRE(123,color_frame[4]);
   DRE(153,color_frame[5]);
   DRE(183,color_frame[6]);
   wsprintf(ws_load,perc_t,lgpData[LGP_NAME_GAME]);
   DrawString(ws_load,0, max_height/5 ,max_width,max_height,2,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
   switch(img_count)
   {
    case 1:
       wsprintf(ws_load,perc_t,lgpData[LGP_LOADING_1]);
   DrawString(ws_load,0, max_height/3 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
          if(_done[1]==1)
      {
    
        
     wsprintf(ws_load,perc_tt,"15%\nuser1.png :",lgpData[LGP_LOADING_YES]);  
     color_frame[1]=4;
      }
      if(_done[1]==0)
        {
          error_count++;
       color_frame[1]=2;
       wsprintf(ws_load,perc_tt,"15%\nuser1.png :",lgpData[LGP_LOADING_NO]);  
      }
   
    break;
    case 2:
      wsprintf(ws_load,perc_t,lgpData[LGP_LOADING_2]);
   DrawString(ws_load,0, max_height/3 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
      if(_done[2]==1)
      {
      color_frame[2]=4;  
      
      
   
      wsprintf(ws_load,perc_tt,"30%\nuser2.png :",lgpData[LGP_LOADING_YES]); 
      }
      else
      {
        error_count++;
      color_frame[2]=2;
      wsprintf(ws_load,perc_tt,"30%\nuser2.png :",lgpData[LGP_LOADING_NO]); 
      }
  
    break;
    case 3:
      wsprintf(ws_load,perc_t,lgpData[LGP_LOADING_3]);
   DrawString(ws_load,0, max_height/3 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
            if(_done[3]==1)
      {
        
      color_frame[3]=4;  
       
      
    wsprintf(ws_load,perc_tt,"50%\nball.png :",lgpData[LGP_LOADING_YES]);
      }
      else
      {
        error_count++;
     color_frame[3]=2;  
    wsprintf(ws_load,perc_tt,"50%\nball.png :",lgpData[LGP_LOADING_NO]);
      }
    
    break;
    case 4:
       wsprintf(ws_load,perc_t,lgpData[LGP_LOADING_4]);
   DrawString(ws_load,0, max_height/3 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
               if(_done[4]==1)
      {
      color_frame[4]=4;  
      
      
      
      wsprintf(ws_load,perc_tt,"70%\ncursor.png :",lgpData[LGP_LOADING_YES]);  
      }
      else
      {
        error_count++;
        color_frame[4]=2;  
      wsprintf(ws_load,perc_tt,"70%\ncursor.png :",lgpData[LGP_LOADING_NO]);
      }
   
    break;
    case 5:
      
       wsprintf(ws_load,perc_t,lgpData[LGP_LOADING_1]);
   DrawString(ws_load,0, max_height/3 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
      if(_done[5]==1)
      {
      color_frame[5]=4;  
      
      
      
      wsprintf(ws_load,perc_tt,"85%\nlogo.png :",lgpData[LGP_LOADING_YES]);    
      }
      else
      {
        error_count++;
      color_frame[5]=2;  
      wsprintf(ws_load,perc_tt,"85%\nlogo.png :",lgpData[LGP_LOADING_YES]);    
      }
    break;
    case 6:
      
       wsprintf(ws_load,perc_t,lgpData[LGP_LOADING_2]);
   DrawString(ws_load,0, max_height/3 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
     if(_done[6]==1)
      {
      color_frame[6]=4;  
      wsprintf(ws_load,perc_tt,"100%\nfon.png :",lgpData[LGP_LOADING_YES]);  
      }
     else
     {
       error_count++;
       color_frame[6]=2;  
      wsprintf(ws_load,perc_tt,"100%\nfon.png :",lgpData[LGP_LOADING_NO]);
     }
   
    break;
   
    default:
      if(error_count>=1)
      {
        wsprintf(ws_load,perc_t,lgpData[LGP_LOADING_0]); 
      }
      else
      {
      wsprintf(ws_load,perc_t,lgpData[LGP_LOADING_1_1]);
      
  
     
      
      
      }
}
   DrawString(ws_load,0, 123 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
   FreeWS(ws_load);

}
else
{
  if(error_count==0){
 
   
  }
  if(error_count!=0){ 
  
   

{
   DrawRoundedFrame(0,0,max_width,max_height,0,0,0,NULL,bgcol);
   WSHDR *ws_err = AllocWS(128);
   
   sprintf(icon_folder,"%s%s",folder,"img\\");
  wsprintf(ws_err,perc_tt,lgpData[LGP_LOADING_0_TEXT],icon_folder); 
  
  DrawString(ws_err,0, 30 ,max_width,max_height,FONT,2,GetPaletteAdrByColorIndex(2),GetPaletteAdrByColorIndex(23));
  
  
  
  
   FreeWS(ws_err);
   
}
}
}
}
