//��� ���������� � ��������
#include "C:\arm\pp\lang.h" 
void saveNastr()
{
sprintf(nameA,"Cpu");//nameA=Cpu
sprintf(nastr_folder,per_s,folder,"data.sys");//����� ����
int f = fopen(nastr_folder,A_WriteOnly+A_BIN+A_Create+A_Truncate,P_WRITE,&err);
if(f!=-1)
{
fwrite(f,&langg,4,&err);
fwrite(f,&langenru,4,&err);
fwrite(f,&saveload,4,&err);
fwrite(f,&mode,4,&err);
fwrite(f,&on_off_sound,4,&err);
fwrite(f,&chek,4,&err);
fwrite(f,&diff,4,&err);
fwrite(f,&sk,4,&err);
fwrite(f,&lives1,4,&err);
fwrite(f,&def_vol,4,&err);
if (pusto==0){

if(user[lifetime]>cpu[lifetime]&&user[lifetime]>point1){//1 �����
fwrite(f,&user[lifetime],4,&err);
fwrite(f,&name,15,&err);
fwrite(f,&point1,4,&err);
fwrite(f,&name1,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);
}

if(cpu[lifetime]>user[lifetime]&&cpu[lifetime]>point1){//1
fwrite(f,&cpu[lifetime],4,&err); 
fwrite(f,&nameA,15,&err);
fwrite(f,&point1,4,&err);
fwrite(f,&name1,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);
}

if(user[lifetime]<point1&&user[lifetime]>point2){//2
fwrite(f,&point1,4,&err);
fwrite(f,&name1,15,&err);
fwrite(f,&user[lifetime],4,&err);
fwrite(f,&name,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);
}

if(cpu[lifetime]<point1&&cpu[lifetime]>point2){//2
fwrite(f,&point1,4,&err);
fwrite(f,&name1,15,&err);
fwrite(f,&cpu[lifetime],4,&err);
fwrite(f,&nameA,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);
}

if(user[lifetime]<point2&&user[lifetime]>point3){//3
fwrite(f,&point1,4,&err);
fwrite(f,&name1,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err);
fwrite(f,&user[lifetime],4,&err);
fwrite(f,&name,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);
}

if(cpu[lifetime]<point2&&cpu[lifetime]>point3){//3
fwrite(f,&point1,4,&err);
fwrite(f,&name1,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err); 
fwrite(f,&cpu[lifetime],4,&err);
fwrite(f,&nameA,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);
}

if(user[lifetime]<point3&&user[lifetime]>point4){//4
fwrite(f,&point1,4,&err);
fwrite(f,&name1,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&user[lifetime],4,&err);
fwrite(f,&name,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);

}



if(cpu[lifetime]<point3&&cpu[lifetime]>point4){//4
fwrite(f,&point1,4,&err);
fwrite(f,&name1,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&cpu[lifetime],4,&err);
fwrite(f,&nameA,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);
}

if(user[lifetime]<point4&&user[lifetime]>point5){//5
fwrite(f,&point1,4,&err);
fwrite(f,&name1,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);
fwrite(f,&user[lifetime],4,&err);
fwrite(f,&name,15,&err);}

if(cpu[lifetime]<point4&&cpu[lifetime]>point5){//5
fwrite(f,&point1,4,&err);
fwrite(f,&name1,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);
fwrite(f,&cpu[lifetime],4,&err);
fwrite(f,&nameA,15,&err);}




  }
if (pusto==1){
point1=point2=point3=point4=point5=0;
fwrite(f,&point1,4,&err);
fwrite(f,&name,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);
fwrite(f,&point5,4,&err);
fwrite(f,&name5,15,&err);
}
fclose(f,&err);
}

else 
{
//ShowMSG(1,(int)LGP_GAME_SAVEDATA_0);
}
}



void saveNastr1()//��� ������
{
  sprintf(nastr_folder,per_s,folder,"data.sys");
int f = fopen(nastr_folder,A_WriteOnly+A_BIN+A_Create+A_Truncate,P_WRITE,&err);
if(f!=-1)
{
fwrite(f,&langg,4,&err);
fwrite(f,&langenru,4,&err);
fwrite(f,&saveload,4,&err);
fwrite(f,&mode,4,&err);
fwrite(f,&on_off_sound,4,&err);
fwrite(f,&chek,4,&err);
fwrite(f,&diff,4,&err);
fwrite(f,&sk,4,&err);
fwrite(f,&lives1,4,&err);
fwrite(f,&def_vol,4,&err);
fwrite(f,&point1,4,&err);
fwrite(f,&name1,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);
fwrite(f,&point5,4,&err);
fwrite(f,&name5,15,&err);
fclose(f,&err);
}


}


void loadNastr()//��� ��������
{
sprintf(nastr_folder,per_s,folder,"data.sys");
int f = fopen(nastr_folder,A_ReadOnly+A_BIN,P_READ,&err);
if(f!=-1){
lan=1;
fread(f,&langg,4,&err);
fread(f,&langenru,4,&err);
fread(f,&saveload,4,&err);
fread(f,&mode,4,&err);
fread(f,&on_off_sound,4,&err);
fread(f,&chek,4,&err);
fread(f,&diff,4,&err);
fread(f,&sk,4,&err);
fread(f,&lives1,4,&err);
fread(f,&def_vol,4,&err);
fread(f,&point1,4,&err);
fread(f,&name1,15,&err);
fread(f,&point2,4,&err);
fread(f,&name2,15,&err);
fread(f,&point3,4,&err);
fread(f,&name3,15,&err);
fread(f,&point4,4,&err);
fread(f,&name4,15,&err);
fread(f,&point5,4,&err);
fread(f,&name5,15,&err);
fclose(f,&err);
}

else 
{
//ShowMSG(1,(int)LGP_GAME_LOADDATA_0 );
}
}


void saveSettings()//��������� ��������
{
  sprintf(save_folder,per_s,folder,"save\\savedata.pp");
int f = fopen(save_folder,A_WriteOnly+A_BIN+A_Create+A_Truncate,P_WRITE,&err);
if(f!=-1)
{
fwrite(f,&raz,4,&err);
fwrite(f,&user[lifetime],2,&err);
fwrite(f,&cpu[lifetime],2,&err);
fwrite(f,&cpu[speed],2,&err);
fwrite(f,&user[speed],2,&err);
fwrite(f,&user[x],2,&err);
fwrite(f,&user[y],2,&err);
fwrite(f,&ball[y],2,&err);
fwrite(f,&ball[x],2,&err);
fwrite(f,&ball[dx],2,&err);
fwrite(f,&ball[dy],2,&err);
fwrite(f,&cpu[x],2,&err);
fwrite(f,&cpu[y],2,&err);
fwrite(f,&cpu[speed],2,&err);
fwrite(f,&saveload,4,&err);
fwrite(f,&mode,4,&err);
fwrite(f,&on_off_sound,4,&err);
fwrite(f,&chek,4,&err);
fwrite(f,&AI_line,1,&err);
fwrite(f,&AI_lines,4,&err);
fwrite(f,&theme_tick,4,&err);
fwrite(f,&theme_time,4,&err);
fwrite(f,&game_time_m_sec,4,&err);
fwrite(f,&theme_time_chas,4,&err);
fwrite(f,&car_lev,4,&err);
ShowMSG(1,(int)lgpData[LGP_GAME_SAVEGAME_1]);
fclose(f,&err);
}

else 
{
  
ShowMSG(1,(int)lgpData[LGP_GAME_SAVEGAME_0]);
}
}
void loadSettings()//��������� ��������
{
 sprintf(save_folder,per_s,folder,"save\\savedata.pp");
int f = fopen(save_folder,A_ReadOnly+A_BIN,P_READ,&err);
if(f!=-1){
fread(f,&raz,4,&err);
fread(f,&user[lifetime],2,&err);
fread(f,&cpu[lifetime],2,&err);
fread(f,&cpu[speed],2,&err);
fread(f,&user[speed],2,&err);
fread(f,&user[x],2,&err);
fread(f,&user[y],2,&err);
fread(f,&ball[y],2,&err);
fread(f,&ball[x],2,&err);
fread(f,&ball[dx],2,&err);
fread(f,&ball[dy],2,&err);
fread(f,&cpu[x],2,&err);
fread(f,&cpu[y],2,&err);
fread(f,&cpu[speed],2,&err);
fread(f,&saveload,4,&err);
fread(f,&mode,4,&err);
fread(f,&on_off_sound,4,&err);
fread(f,&chek,4,&err);
fread(f,&AI_line,1,&err);
fread(f,&AI_lines,4,&err);
fread(f,&theme_tick,4,&err);
fread(f,&theme_time,4,&err);
fread(f,&game_time_m_sec,4,&err);
fread(f,&theme_time_chas,4,&err);
fread(f,&car_lev,4,&err);
ShowMSG(1,(int)lgpData[LGP_GAME_LOADGAME_1]);

fclose(f,&err);
}

else 
{
ShowMSG(1,(int)lgpData[LGP_GAME_LOADGAME_0]);
}
}



void savelang()
{
langg=1;
sprintf(nastr_folder,per_s,folder,"data.sys");//����� ����
int f = fopen(nastr_folder,A_WriteOnly+A_BIN+A_Create+A_Truncate,P_WRITE,&err);
point1=point2=point3=point4=point5=0;
fwrite(f,&langg,4,&err);
fwrite(f,&langenru,4,&err);
fwrite(f,&saveload,4,&err);
fwrite(f,&mode,4,&err);
fwrite(f,&on_off_sound,4,&err);
fwrite(f,&chek,4,&err);
fwrite(f,&diff,4,&err);
fwrite(f,&sk,4,&err);
fwrite(f,&lives1,4,&err);
fwrite(f,&def_vol,4,&err);
fwrite(f,&point1,4,&err);
fwrite(f,&name1,15,&err);
fwrite(f,&point2,4,&err);
fwrite(f,&name2,15,&err);
fwrite(f,&point3,4,&err);
fwrite(f,&name3,15,&err);
fwrite(f,&point4,4,&err);
fwrite(f,&name4,15,&err);
fwrite(f,&point5,4,&err);
fwrite(f,&name5,15,&err);
fclose(f,&err);
}














