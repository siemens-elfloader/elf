#include "..\inc\swilib.h"
int sock;
int is_gprs_online;
int DNR_ID;
int ALLTOTALRECEIVED;
int ALLTOTALSENDED;
char URL[128];
char load_url[128];
char host[64], get_path[64];
void adres(int mode)
{
  sprintf(URL,"http://pp.elfs.hdd1.ru/index.php?ux=%d&bx=%d&by=%d&name=%s",user[x],ball[x],ball[y],name);
  strcpy(load_url, URL);
  get_path_from_url(get_path, load_url);
  get_host_from_url(host, load_url);
}
void create_connect(int mode)
{
  adres(mode);
  DNR_TRIES=3;
  unsigned int port=80;
  int ***p_res=NULL;
  SOCK_ADDR sa;
  connect_state = 0;
  *socklasterr()=0;
  async_gethostbyname(host,&p_res,&DNR_ID);
  strcpy(logmsg,"DNR ok!");
  sa.ip=p_res[3][0][0];
  sock=socket(1,1,0);
  if (sock!=-1)
      {
	sa.family=1;
	sa.port=htons(port);
        connect(sock,&sa,sizeof(sa));
      }
  
}


char *recv_buf=NULL;
int recv_buf_len=0;

char *send_buf=NULL;
int send_buf_len=0;


void free_recv_buf(void)
{
  char *p=recv_buf;
  recv_buf_len=0;
  recv_buf=NULL;
  mfree(p);
}


void get_answer()
{
  char buf[2048];
  int j;
  j=recv(sock,buf,sizeof(buf),0);
  if (j>0)
  {
    ALLTOTALRECEIVED+=j;
   
    if (receive_mode)
    {
    
    }
    else
    {
      char *end_answer;
      recv_buf=realloc(recv_buf, recv_buf_len+j+1);
      recv_buf[recv_buf_len+j]=0;
      memcpy(recv_buf+recv_buf_len, buf, j);
      recv_buf_len+=j;
      if (!(end_answer=strstr(recv_buf, "\r\n\r\n"))) return;
      receive_mode=1; //��������� ����������� ��������
      end_answer+=4;
      j=recv_buf_len-(end_answer-recv_buf);
    
      if (!j) return; //��� ������, ������ ��������
    
      //free_recv_buf();
    }
  }
}

void free_send_buf(void)
{
  char *p=send_buf;
  send_buf_len=0;
  send_buf=NULL;
  mfree(p);
#ifdef SEND_TIMER
  GBS_DelTimer(&send_tmr);
#endif
}


void send_answer(char *buf, int len)
{
  int i, j;
  char *p;
  if (buf)
  {
    if (send_buf)
    {
      send_buf=realloc(send_buf,send_buf_len+len);
      memcpy(send_buf+send_buf_len, buf, len);
      send_buf_len+=len;
      mfree(buf);
      return;
    }
    send_buf=buf;
    send_buf_len=len;
  }
  while((i=send_buf_len)!=0)
  {
    if (i>0x400) i=0x400;
    j=send(sock,send_buf,i,0);
    if (j<0)
    {
      j=*socklasterr();
      if ((j==0xC9)||(j==0xD6))
      {
	return; //������, ���� ����� ��������� ENIP_BUFFER_FREE
      }
      else
      {
	return;
      }
    }
    ALLTOTALSENDED+=j;
    send_buf_len-=j;
   
    memcpy(send_buf,send_buf+j,send_buf_len); //������� ����������
    if (j<i)
    {
      //�������� ������ ��� ����������

     

      return; //���� ��������� ENIP_BUFFER_FREE1
    }
  }
  p=send_buf;
  send_buf=NULL;
  mfree(p);
}



static void free_buffers(void)
{
  free_recv_buf();
  free_send_buf();
}

static void free_socket(void)
{
  sock=-1;
  connect_state=0;
  free_buffers();
  REDRAW();
}

void send_req()//��� ��� ����.
{
  adres(SEND);
  char *p;
  int len;
  char req_buf[256];
  len=snprintf(req_buf,255,"GET %s"" HTTP/1.0\r\nHost: %s\r\n\r\n",get_path,host);
  p=malloc(len+1);
  strcpy(p, req_buf);
  send_answer(p, len);
}
