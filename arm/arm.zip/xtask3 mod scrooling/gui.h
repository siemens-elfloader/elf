int GetNumberOfDialogs(void);
void ClearNL(void);

